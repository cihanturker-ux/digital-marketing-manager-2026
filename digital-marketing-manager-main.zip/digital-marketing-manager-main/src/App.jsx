import React, { useState } from 'react'
import { useGameStore } from './store/gameStore'
import { Canvas } from '@react-three/fiber'
import { ManagerCreation } from './components/Onboarding/ManagerCreation'
import { ContractOffer } from './components/Onboarding/ContractOffer'
import { Sidebar } from './components/Layout/Sidebar'
import { Header } from './components/Layout/Header'
import { Dashboard } from './components/Dashboard'
import { AdsManager } from './components/Modules/AdsManager'
import { SeoCenter } from './components/Modules/SeoCenter'
import { SocialStudio } from './components/Modules/SocialStudio'
import { Inbox } from './components/Modules/Inbox'
import { Team } from './components/Modules/Team'
import { BoardMeeting } from './components/Modules/BoardMeeting'
import { NewsFeed } from './components/Modules/NewsFeed'
import { Finances } from './components/Modules/Finances'
import { StrategyHub } from './components/Modules/StrategyHub'
import { Opportunities } from './components/Modules/Opportunities'
import { Recruitment } from './components/Modules/Recruitment'
import { StaffDevelopment } from './components/Modules/StaffDevelopment'
import { DataHub } from './components/Modules/DataHub'
import { Dynamics } from './components/Modules/Dynamics'
import { ScoutingNetwork } from './components/Modules/ScoutingNetwork'
import { GameOverModal } from './components/Modals/GameOverModal'
import { VictoryModal } from './components/Modals/VictoryModal'
import { TaskNotification } from './components/Modals/TaskNotification'
import { SeasonEndModal } from './components/Modals/SeasonEndModal'
import { BoardVision } from './components/Modules/BoardVision'
import { Settings } from './components/Modules/Settings'
import { TaskManager } from './components/Modules/TaskManager'
import { PressConference } from './components/Modules/PressConference'
import { StaffMorale } from './components/Modules/StaffMorale'
import { RivalAnalysis } from './components/Modules/RivalAnalysis'

const GameLoop = () => {
    const [currentView, setCurrentView] = useState('DASHBOARD')
    const [showMeeting, setShowMeeting] = useState(false)
    const date = useGameStore(state => state.date)
    const history = useGameStore(state => state.history)
    const gameOver = useGameStore(state => state.gameOver)
    const victory = useGameStore(state => state.victory)
    const pendingNotifications = useGameStore(state => state.pendingNotifications)
    const clearPendingNotifications = useGameStore(state => state.clearPendingNotifications)
    const showSeasonEnd = useGameStore(state => state.showSeasonEnd)
    const updatePlayTime = useGameStore(state => state.updatePlayTime)

    const [currentTaskNotification, setCurrentTaskNotification] = useState(null)

    const isPlaying = useGameStore(state => state.isPlaying)
    const gameSpeed = useGameStore(state => state.gameSpeed)
    const advanceTime = useGameStore(state => state.advanceTime)

    // ============ AUTO ADVANCE TIME ============
    React.useEffect(() => {
        if (!isPlaying) return;

        const delay = gameSpeed === 1 ? 5000 : gameSpeed === 2 ? 2000 : 500;

        const interval = setInterval(() => {
            advanceTime(1);
        }, delay);

        return () => clearInterval(interval);
    }, [isPlaying, gameSpeed, advanceTime]);

    // ============ PLAY TIME TRACKING ============
    React.useEffect(() => {
        const interval = setInterval(() => {
            // Update play time every second (1000ms)
            updatePlayTime(1000);
        }, 1000);

        return () => clearInterval(interval);
    }, [updatePlayTime]);

    // Show task notifications when new tasks are assigned
    React.useEffect(() => {
        if (pendingNotifications && pendingNotifications.length > 0) {
            setCurrentTaskNotification(pendingNotifications[0])
            useGameStore.getState().setIsPlaying(false) // Pause game when new task appears
        }
    }, [pendingNotifications])

    const handleCloseTaskNotification = () => {
        setCurrentTaskNotification(null)
        clearPendingNotifications()
    }

    // Trigger meeting on day 30 (Simplified)
    React.useEffect(() => {
        const currentDate = date instanceof Date ? date : new Date(date);
        if (currentDate.getDate() === 30) { // Every 30th of the month roughly
            setShowMeeting(true)
        }
    }, [date])

    const renderContent = () => {
        switch (currentView) {
            case 'DASHBOARD': return <Dashboard />
            case 'BOARD_VISION': return <BoardVision />
            case 'TASKS': return <TaskManager />
            case 'INBOX': return <Inbox />
            case 'PRESS': return <PressConference />
            case 'TEAM': return <Team />
            case 'MORALE': return <StaffMorale />
            case 'DEVELOPMENT': return <StaffDevelopment />
            case 'RECRUITMENT': return <Recruitment />
            case 'DYNAMICS': return <Dynamics />
            case 'SCOUTING': return <ScoutingNetwork />
            case 'DATA_HUB': return <DataHub />
            case 'FINANCES': return <Finances />
            case 'STRATEGY': return <StrategyHub />
            case 'RIVALS': return <RivalAnalysis />
            case 'NEWS': return <NewsFeed />
            case 'ADS': return <AdsManager />
            case 'SEO': return <SeoCenter />
            case 'SOCIAL': return <SocialStudio />
            case 'OPPORTUNITIES': return <Opportunities />
            case 'SETTINGS': return <Settings />
            default: return <Dashboard />
        }
    }

    return (
        <div className="full-screen" style={{ display: 'flex', background: 'var(--color-bg-primary)' }}>
            <Sidebar currentView={currentView} onViewChange={setCurrentView} />

            <div style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
                <Header />
                {renderContent()}
            </div>

            {showMeeting && <BoardMeeting onClose={() => setShowMeeting(false)} performance={history[history.length - 1] || { revenue: 0 }} />}
            {currentTaskNotification && <TaskNotification task={currentTaskNotification} onClose={handleCloseTaskNotification} />}
            {showSeasonEnd && <SeasonEndModal />}
            {gameOver && <GameOverModal />}
            {victory && <VictoryModal />}
        </div>
    )
}

function App() {
    const gamePhase = useGameStore((state) => state.gamePhase)

    return (
        <>
            {gamePhase === 'ONBOARDING' && <ManagerCreation />}
            {gamePhase === 'CONTRACT' && <ContractOffer />}
            {gamePhase === 'GAMEPLAY' && <GameLoop />}
        </>
    )
}

export default App
