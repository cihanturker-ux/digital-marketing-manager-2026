// Enhanced simulation engine - FM25-style Success Coefficient Algorithm
// Formula: Conversion = Creative Quality * Budget * Targeting Accuracy * Market Events * Chance

export const calculateDailyResults = (state) => {
    const { campaigns = [], keywords = [], siteHealth = { technical: 50 }, activeEvents = [] } = state;

    // 1. Calculate Market Multipliers (The Algorithm Update)
    let marketMultipliers = {
        conversion: 1.0,
        cpc: 1.0,
        traffic: 1.0,
        seo: 1.0,
        social: 1.0
    };

    activeEvents.forEach(event => {
        if (event.effects) {
            Object.keys(event.effects).forEach(key => {
                marketMultipliers[key] *= event.effects[key];
            });
        }
    });

    // 2. Campaign Simulation (The Real-Time Auction & Success Coefficient)
    let totalCampaignRevenue = 0;
    let totalClicks = 0;

    const updatedCampaigns = campaigns.map(campaign => {
        if (campaign.status !== 'ACTIVE') return campaign;

        // Variables for the algorithm
        const creativeQuality = campaign.creativeQuality || 5; // 1-10
        const targetingAccuracy = campaign.targetingAccuracy || 0.7; // 0.1-1.0
        const budget = campaign.budget;

        // AI Competitor Logic (Simplified: Random bid pressure)
        const competitorPressure = campaign.competitorPressure || (Math.random() * 0.5 + 0.8); // 0.8 to 1.3
        const auctionEfficiency = 1 / competitorPressure;

        // THE SUCCESS COEFFICIENT ALGORITHM
        // Base impressions scaled by budget and auction efficiency
        const impressions = Math.floor(budget * 10 * auctionEfficiency * marketMultipliers.traffic);

        // CTR based on creative quality and targeting
        const baseCTR = 0.02; // 2%
        const ctr = baseCTR * (creativeQuality / 5) * targetingAccuracy;
        const clicks = Math.floor(impressions * ctr);

        // CONVERSION CALCULATION
        // Conversion = Creative * Targeting * Market * Luck (15% chaos)
        const luckFactor = 0.85 + Math.random() * 0.3; // 0.85 to 1.15
        const baseConvRate = 0.05; // 5%
        const convRate = baseConvRate * (creativeQuality / 7) * targetingAccuracy * marketMultipliers.conversion * luckFactor;
        const conversions = Math.floor(clicks * convRate);

        // Revenue: Each conversion is worth $50 (hypothetical)
        const revenue = conversions * 50;
        totalCampaignRevenue += revenue;
        totalClicks += clicks;

        return {
            ...campaign,
            dailyResults: {
                impressions,
                clicks,
                conversions,
                revenue
            }
        };
    });

    // 3. SEO & Social Logic
    const seoRevenue = keywords.reduce((total, k) => {
        const rankScore = Math.max(0, 100 - k.rank);
        return total + rankScore * 3 * marketMultipliers.seo;
    }, 0);

    const socialRevenue = (state.posts || []).slice(0, 5).reduce((total, post) => {
        const engagement = (post.likes || 0) + (post.comments || 0) * 2;
        return total + engagement * 0.5 * marketMultipliers.social;
    }, 0);

    const healthBonus = (siteHealth.technical || 50) * 0.5;

    // Total Results
    const baseRevenue = Math.round(state.company?.budget ? state.company.budget * 0.005 : 100);
    const finalRevenue = Math.round((totalCampaignRevenue + seoRevenue + socialRevenue + healthBonus + baseRevenue));

    return {
        revenue: finalRevenue,
        traffic: Math.round(totalClicks * 1.5 + (seoRevenue / 10)), // Simple traffic proxy
        campaignResults: updatedCampaigns.map(c => ({ id: c.id, ...c.dailyResults })),
        activeEvents: activeEvents.map(e => e.name),
        sources: {
            campaigns: Math.round(totalCampaignRevenue),
            social: Math.round(socialRevenue),
            seo: Math.round(seoRevenue),
            base: baseRevenue
        }
    };
};

