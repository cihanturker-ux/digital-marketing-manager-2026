```javascript
import * as THREE from 'three'

export const generateShape = (type, count = 2000) => {
  const points = []
  
  for (let i = 0; i < count; i++) {
    let p = new THREE.Vector3()
    
    if (type === 'ROCKET') {
      // Scaled down Rocket
      const h = (Math.random() - 0.5) * 2.0 // Height 2.0
      let r = 0.35
      if (h > 0.4) r *= (1.0 - h) / 0.6 
      if (h < -0.6) r *= 1.4 
      
      const angle = Math.random() * Math.PI * 2
      const rFill = Math.sqrt(Math.random()) * r
      p.set(rFill * Math.cos(angle), h, rFill * Math.sin(angle))

      if (h < -0.6 && Math.random() < 0.3) {
         const finAngle = (Math.floor(Math.random() * 3) / 3) * Math.PI * 2
         const finR = 0.35 + Math.random() * 0.5
         p.set(finR * Math.cos(finAngle), h, finR * Math.sin(finAngle))
      }
    } 
    else if (type === 'MEDIA') {
      // Scaled down Media
      const w = 2.0
      const h = 1.6
      
      const x = (Math.random() - 0.5) * w
      const y = (Math.random() - 0.5) * h
      
      const mountainHeight = -0.4 + Math.cos(x * 2.5) * 0.4
      
      if (y < mountainHeight) {
         p.set(x, y, (Math.random() - 0.5) * 0.15)
      } else if (Math.random() < 0.1) {
         p.set(x, y, (Math.random() - 0.5) * 0.15)
      } else {
         const sunDist = Math.sqrt(Math.pow(x - 0.5, 2) + Math.pow(y - 0.4, 2))
         if (sunDist < 0.3) {
            p.set(x, y, (Math.random() - 0.5) * 0.15)
         } else {
             i--
             continue
         }
      }
    }
    else if (type === 'TOOLS') {
      // Scaled down Tools
      const angle = Math.random() * Math.PI * 2
      const rBase = 0.6
      const rTeeth = 0.9
      
      const isTooth = Math.sin(angle * 8) > 0.5
      const rMax = isTooth ? rTeeth : rBase
      const r = Math.sqrt(Math.random()) * rMax
      
      if (r < 0.25) {
         i--
         continue
      }
      
      p.set(r * Math.cos(angle), r * Math.sin(angle), (Math.random() - 0.5) * 0.15)
    }
    else if (type === 'GRAPH') {
      // Scaled down Graph
      const x = (Math.random() - 0.5) * 2.4
      const z = (Math.random() - 0.5) * 2.4
      
      const yMax = Math.sin(x * 2.5) * Math.cos(z * 2.5) * 0.4 + 0.15
      const y = (Math.random() - 0.5) * 1.6
      
      if (y < yMax && y > -0.8) {
         p.set(x, y, z)
      } else {
         i-- 
         continue
      }
    }

    points.push(p)
  }
  
  return points
}
```
