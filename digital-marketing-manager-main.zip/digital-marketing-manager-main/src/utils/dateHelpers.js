// Date utility functions for consistent date handling across the app

/**
 * Ensures we always work with a valid Date object
 * @param {Date|string|number} dateInput - The date to normalize
 * @returns {Date} A valid Date object
 */
export const normalizeDate = (dateInput) => {
    if (dateInput instanceof Date) return dateInput;
    return new Date(dateInput);
};

/**
 * Calculate days between two dates
 * @param {Date|string} date1 - Start date
 * @param {Date|string} date2 - End date
 * @returns {number} Number of days between dates
 */
export const daysBetween = (date1, date2) => {
    const d1 = normalizeDate(date1);
    const d2 = normalizeDate(date2);
    const diffTime = Math.abs(d2 - d1);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

/**
 * Format date for display
 * @param {Date|string} date - Date to format
 * @param {string} format - 'short', 'long', or 'relative'
 * @returns {string} Formatted date string
 */
export const formatDate = (date, format = 'short') => {
    const d = normalizeDate(date);

    if (format === 'short') {
        return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }

    if (format === 'long') {
        return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    }

    if (format === 'relative') {
        const now = new Date();
        const days = daysBetween(d, now);

        if (days === 0) return 'Today';
        if (days === 1) return 'Yesterday';
        if (days < 7) return `${days} days ago`;
        if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
        if (days < 365) return `${Math.floor(days / 30)} months ago`;
        return `${Math.floor(days / 365)} years ago`;
    }

    return d.toLocaleDateString();
};

/**
 * Add days to a date
 * @param {Date|string} date - Starting date
 * @param {number} days - Number of days to add
 * @returns {Date} New date
 */
export const addDays = (date, days) => {
    const d = normalizeDate(date);
    const result = new Date(d);
    result.setDate(result.getDate() + days);
    return result;
};

/**
 * Format time duration in hours and minutes
 * @param {number} milliseconds - Time in milliseconds
 * @returns {string} Formatted string like "5h 30m"
 */
export const formatPlayTime = (milliseconds) => {
    const hours = Math.floor(milliseconds / (1000 * 60 * 60));
    const minutes = Math.floor((milliseconds % (1000 * 60 * 60)) / (1000 * 60));

    if (hours === 0) return `${minutes}m`;
    return `${hours}h ${minutes}m`;
};
