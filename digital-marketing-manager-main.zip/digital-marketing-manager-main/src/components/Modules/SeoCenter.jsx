import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Search, TrendingUp, AlertCircle, CheckCircle, BarChart2, Globe, Activity, Zap, RefreshCw, Plus } from 'lucide-react'

const HealthCard = ({ label, score, issues, onFix, type, cost }) => {
    return (
        <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    {type === 'technical' && <Zap size={18} color="var(--color-accent)" />}
                    {type === 'content' && <Globe size={18} color="var(--color-success)" />}
                    {type === 'backlink' && <Activity size={18} color="var(--color-warning)" />}
                    <span style={{ fontWeight: '600' }}>{label}</span>
                </div>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: score > 70 ? 'var(--color-success)' : score > 40 ? 'var(--color-warning)' : 'var(--color-error)' }}>
                    {score}/100
                </div>
            </div>

            <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px', marginBottom: '1.5rem' }}>
                <div style={{ width: `${score}%`, height: '100%', background: score > 70 ? 'var(--color-success)' : score > 40 ? 'var(--color-warning)' : 'var(--color-error)', borderRadius: '4px', transition: 'width 0.5s ease' }}></div>
            </div>

            <div style={{ marginTop: 'auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.5rem', color: 'var(--color-text-secondary)' }}>
                    <span>Kalan Sorunlar</span>
                    <span>{issues}</span>
                </div>
                <button
                    onClick={() => onFix(type)}
                    disabled={score >= 100}
                    style={{
                        width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-sm)', border: 'none',
                        background: score >= 100 ? 'var(--color-bg-tertiary)' : 'var(--color-bg-secondary)',
                        color: score >= 100 ? 'var(--color-text-secondary)' : 'var(--color-text-primary)',
                        cursor: score >= 100 ? 'default' : 'pointer', fontWeight: '600',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                        transition: 'background 0.2s'
                    }}
                >
                    {score >= 100 ? <CheckCircle size={16} /> : <RefreshCw size={16} />}
                    {score >= 100 ? 'Tamamlandı' : `Optimize Et ($${cost})`}
                </button>
            </div>
        </div>
    )
}

const KeywordRow = ({ keyword }) => (
    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', padding: '1rem', borderBottom: '1px solid rgba(0,0,0,0.05)', alignItems: 'center' }}>
        <div style={{ fontWeight: '500' }}>{keyword.term}</div>
        <div style={{ textAlign: 'center' }}>
            <span style={{
                padding: '0.25rem 0.5rem', borderRadius: '1rem', fontSize: '0.8rem', fontWeight: '600',
                background: keyword.rank <= 3 ? 'var(--color-success-light)' : keyword.rank <= 10 ? 'var(--color-warning-light)' : 'var(--color-bg-tertiary)',
                color: keyword.rank <= 3 ? 'var(--color-success)' : keyword.rank <= 10 ? 'var(--color-warning)' : 'var(--color-text-secondary)'
            }}>
                #{keyword.rank}
            </span>
        </div>
        <div style={{ textAlign: 'center', fontSize: '0.9rem' }}>{keyword.volume.toLocaleString()}</div>
        <div style={{ textAlign: 'center', fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>{keyword.difficulty}/100</div>
    </div>
)

const ResearchModal = ({ onClose }) => {
    const addKeyword = useGameStore(state => state.addKeyword)
    const [searchTerm, setSearchTerm] = useState('')
    const [results, setResults] = useState([])
    const [searching, setSearching] = useState(false)

    const handleSearch = () => {
        setSearching(true)
        // Simulate API call delay
        setTimeout(() => {
            const dummyResults = [
                { term: searchTerm + " strateji", volume: "2.4k", difficulty: 45 },
                { term: "en iyi " + searchTerm, volume: "12k", difficulty: 85 },
                { term: searchTerm + " ipuçları", volume: "800", difficulty: 20 },
                { term: "nasıl yapılır " + searchTerm, volume: "5.6k", difficulty: 60 },
            ]
            setResults(dummyResults)
            setSearching(false)
        }, 1000)
    }

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100,
            backdropFilter: 'blur(4px)'
        }}>
            <div className="glass-card" style={{ width: '600px', padding: '2rem', background: 'white', height: '500px', display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Anahtar Kelime Araştırması</h2>
                    <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><Plus size={24} style={{ transform: 'rotate(45deg)' }} /></button>
                </div>

                <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem' }}>
                    <input
                        type="text"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        placeholder="Bir konu girin (örn: pazarlama)"
                        style={{ flex: 1, padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid #ddd' }}
                    />
                    <button
                        onClick={handleSearch}
                        disabled={!searchTerm || searching}
                        style={{ padding: '0.75rem 1.5rem', background: 'var(--color-accent)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', cursor: 'pointer' }}
                    >
                        {searching ? 'Aranıyor...' : 'Keşfet'}
                    </button>
                </div>

                <div style={{ flex: 1, overflowY: 'auto' }}>
                    {results.length > 0 ? (
                        <div style={{ display: 'grid', gap: '0.5rem' }}>
                            {results.map((r, i) => (
                                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                                    <div>
                                        <div style={{ fontWeight: '600' }}>{r.term}</div>
                                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Hacim: {r.volume} • Zorluk: {r.difficulty}</div>
                                    </div>
                                    <button
                                        onClick={() => { addKeyword(r); onClose(); }}
                                        style={{ padding: '0.5rem 1rem', background: 'white', border: '1px solid #ddd', borderRadius: 'var(--radius-sm)', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}
                                    >
                                        Takip Et
                                    </button>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div style={{ textAlign: 'center', color: 'var(--color-text-secondary)', marginTop: '3rem' }}>
                            Yeni fırsatlar bulmak için bir konu girin.
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

export const SeoCenter = () => {
    const siteHealth = useGameStore(state => state.siteHealth)
    const keywords = useGameStore(state => state.keywords)
    const fixSiteIssue = useGameStore(state => state.fixSiteIssue)
    const [showModal, setShowModal] = useState(false)

    const handleFix = (type) => {
        fixSiteIssue(type)
    }

    // Dynamic Issue Generarion (in Turkish)
    const technicalIssues = Math.max(0, Math.ceil((100 - siteHealth.technical) / 5));
    const contentIssues = Math.max(0, Math.ceil((100 - siteHealth.content) / 3));
    const backlinkIssues = Math.max(0, Math.ceil((100 - siteHealth.backlinks) / 8));

    const criticalIssuesList = [
        { id: 1, text: "Eksik Meta Açıklamaları", count: contentIssues, severity: 'high' },
        { id: 2, text: "Yavaş Sayfa Yükleme Hızı", count: Math.ceil(technicalIssues * 0.6), severity: 'high' },
        { id: 3, text: "Kırık Bağlantılar (404)", count: Math.ceil(technicalIssues * 0.4), severity: 'medium' },
        { id: 4, text: "Düşük Kaliteli Backlinkler", count: backlinkIssues, severity: 'medium' },
        { id: 5, text: "Anahtar Kelime Yamyamlığı", count: Math.ceil(contentIssues * 0.3), severity: 'low' },
    ].filter(i => i.count > 0);


    return (
        <div style={{ height: '100%', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ marginBottom: '2rem' }}>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>SEO Merkezi</h2>
                    <p style={{ color: 'var(--color-text-secondary' }}>Organik görünürlüğü ve site sağlığını artırın.</p>
                </div>

                {/* Health Cards */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem', marginBottom: '2rem' }}>
                    <HealthCard label="Teknik Altyapı" score={siteHealth.technical} issues={technicalIssues} onFix={handleFix} type="technical" cost={50} />
                    <HealthCard label="İçerik Kalitesi" score={siteHealth.content} issues={contentIssues} onFix={handleFix} type="content" cost={30} />
                    <HealthCard label="Backlink Profili" score={siteHealth.backlinks} issues={backlinkIssues} onFix={handleFix} type="backlink" cost={100} />
                </div>

                {/* Keywords Ranking */}
                <div className="glass-card" style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '0', overflow: 'hidden' }}>
                    <div style={{ padding: '1rem 1.5rem', borderBottom: '1px solid rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h3 style={{ fontSize: '1.1rem' }}>Anahtar Kelime Sıralamaları</h3>
                        <button onClick={() => setShowModal(true)} style={{ background: 'none', border: 'none', color: 'var(--color-accent)', fontWeight: '600', cursor: 'pointer', fontSize: '0.9rem' }}>+ Kelime Ekle</button>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', padding: '0.75rem 1rem', background: 'var(--color-bg-tertiary)', fontSize: '0.8rem', fontWeight: '600', color: 'var(--color-text-secondary)' }}>
                        <div>ANAHTAR KELİME</div>
                        <div style={{ textAlign: 'center' }}>SIRA</div>
                        <div style={{ textAlign: 'center' }}>HACİM</div>
                        <div style={{ textAlign: 'center' }}>ZORLUK</div>
                    </div>

                    <div style={{ overflowY: 'auto' }}>
                        {keywords.map(kw => (
                            <KeywordRow key={kw.id} keyword={kw} />
                        ))}
                        {keywords.length === 0 && (
                            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-secondary)' }}>
                                Takip edilen anahtar kelime yok.
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Right Column: Insights */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <AlertCircle size={18} color="var(--color-error)" /> Kritik Sorunlar
                    </h3>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                        {criticalIssuesList.length > 0 ? criticalIssuesList.map(issue => (
                            <div key={issue.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                                <span style={{ fontSize: '0.9rem' }}>{issue.text}</span>
                                <span style={{
                                    padding: '0.25rem 0.5rem', borderRadius: '1rem', fontSize: '0.75rem', fontWeight: '700',
                                    background: 'white', color: 'var(--color-error)'
                                }}>
                                    {issue.count} sorun
                                </span>
                            </div>
                        )) : (
                            <div style={{ padding: '1rem', textAlign: 'center', color: 'var(--color-success)', background: 'var(--color-success-light)', borderRadius: 'var(--radius-sm)' }}>
                                <CheckCircle size={24} style={{ marginBottom: '0.5rem' }} />
                                <div>Harika! Tüm kritik sorunlar çözüldü.</div>
                            </div>
                        )}
                    </div>
                </div>

                <div className="glass-card" style={{ padding: '1.5rem', flex: 1 }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <BarChart2 size={18} color="var(--color-accent)" /> Trafik Kaynakları
                    </h3>
                    {/* Placeholder for Traffic Chart */}
                    <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-secondary)', border: '2px dashed #ddd', borderRadius: 'var(--radius-sm)' }}>
                        Trafik Grafiği Burada
                    </div>
                </div>
            </div>
            {showModal && <ResearchModal onClose={() => setShowModal(false)} />}
        </div>
    )
}
