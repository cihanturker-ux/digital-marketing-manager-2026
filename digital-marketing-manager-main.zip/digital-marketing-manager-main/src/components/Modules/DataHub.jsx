import React, { useState } from 'react'
import { PieChart, BarChart, LineChart, ArrowUp, ArrowDown, FileText, Download, RefreshCw } from 'lucide-react'

const ReportCard = ({ title, type, children }) => (
    <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem', height: '100%' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                {type === 'PIE' && <PieChart size={16} />}
                {type === 'BAR' && <BarChart size={16} />}
                {type === 'LINE' && <LineChart size={16} />}
                {title}
            </h3>
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-secondary)' }}>
                <Download size={14} />
            </button>
        </div>
        <div style={{ flex: 1 }}>
            {children}
        </div>
    </div>
)

import { useGameStore } from '../../store/gameStore'

export const DataHub = () => {
    const [activeTab, setActiveTab] = useState('GENEL BAKIŞ')
    const history = useGameStore(state => state.history) || []
    const company = useGameStore(state => state.company)

    // Helper to calculate metrics
    const last7Days = history.slice(-7)
    const totalRevenue = last7Days.reduce((acc, h) => acc + (h.revenue || 0), 0)
    const totalSpend = last7Days.reduce((acc, h) => acc + (h.spend || 0), 0) // Assuming spend is tracked or approximate it
    // Approximate spend if not explicitly in daily results (for now assume 30% of revenue is cost or similar simulation)
    // Actually, calculateDailyResults returns revenue, assume spend is budget diff?
    // Let's use a simple approximation for now if spend isn't in history explicitly.
    // Looking at calculateDailyResults, it returns revenue.
    // Let's create a derived spend metric for visualization: Spend ~ Revenue * 0.4 (randomized in game) or just use budget diff if we had it.
    // Better: history doesn't seem to have 'spend'. I'll simulate it for the chart based on revenue for now to visuals work.

    const chartData = history.slice(-14).map(h => ({
        date: new Date(h.date).getDate(),
        revenue: h.revenue || 0,
        spend: (h.revenue || 0) * 0.4 // Simulated spend
    }))

    const maxVal = Math.max(...chartData.map(d => Math.max(d.revenue, d.spend)), 100)

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Veri Merkezi</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Ajansınızın performans metriklerini derinlemesine inceleyin.</p>
                </div>
                <div style={{ display: 'flex', gap: '1rem' }}>
                    <button className="glass-card" style={{ padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                        <RefreshCw size={16} /> Veriyi Yenile
                    </button>
                    <button className="glass-card" style={{ padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'var(--color-accent)', color: 'white', border: 'none' }}>
                        <FileText size={16} /> Rapor Oluştur
                    </button>
                </div>
            </div>

            {/* Tabs */}
            <div style={{ display: 'flex', gap: '2rem', borderBottom: '1px solid rgba(0,0,0,0.1)', paddingBottom: '0.5rem' }}>
                {['GENEL BAKIŞ', 'KAMPANYALAR', 'KİTLE', 'FİNANSAL'].map(tab => (
                    <div
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        style={{
                            cursor: 'pointer', fontWeight: '600', fontSize: '0.9rem',
                            color: activeTab === tab ? 'var(--color-accent)' : 'var(--color-text-secondary)',
                            paddingBottom: '0.5rem',
                            borderBottom: activeTab === tab ? '2px solid var(--color-accent)' : 'none'
                        }}
                    >
                        {tab}
                    </div>
                ))}
            </div>

            {/* Dashboard Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem', flex: 1 }}>

                {/* Main Chart Area */}
                <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: '1.5rem' }}>
                    <ReportCard title="Gelir vs Harcama (Son 14 Gün)" type="LINE">
                        <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'flex-end', gap: '1rem', padding: '1rem 0' }}>
                            {chartData.length > 0 ? chartData.map((d, i) => (
                                <div key={i} style={{ flex: 1, display: 'flex', alignItems: 'flex-end', gap: '4px', height: '100%' }}>
                                    <div style={{ width: '50%', height: `${(d.revenue / maxVal) * 100}%`, background: 'var(--color-success)', borderRadius: '2px 2px 0 0', opacity: 0.8 }}></div>
                                    <div style={{ width: '50%', height: `${(d.spend / maxVal) * 100}%`, background: 'var(--color-warning)', borderRadius: '2px 2px 0 0', opacity: 0.8 }}></div>
                                </div>
                            )) : <div style={{ width: '100%', textAlign: 'center' }}>Veri Yok</div>}
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'center', gap: '2rem', fontSize: '0.8rem', marginTop: '0.5rem' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><div style={{ width: '10px', height: '10px', background: 'var(--color-success)' }}></div> Gelir</div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><div style={{ width: '10px', height: '10px', background: 'var(--color-warning)' }}></div> Tahmini Gider</div>
                        </div>
                    </ReportCard>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                        <ReportCard title="Kanal Dağılımı" type="PIE">
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                                <div style={{
                                    width: '120px', height: '120px', borderRadius: '50%',
                                    background: 'conic-gradient(var(--color-accent) 0% 40%, var(--color-success) 40% 70%, var(--color-warning) 70% 100%)'
                                }}></div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-around', fontSize: '0.75rem', marginTop: '1rem' }}>
                                <span>%40 Ücretli</span>
                                <span>%30 Organik</span>
                                <span>%30 Sosyal</span>
                            </div>
                        </ReportCard>

                        <ReportCard title="Cihaza Göre Dönüşüm" type="BAR">
                            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '1rem', height: '100%' }}>
                                <div>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.25rem' }}>
                                        <span>Masaüstü</span>
                                        <span>%3.2</span>
                                    </div>
                                    <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                        <div style={{ width: '75%', height: '100%', background: 'var(--color-accent)', borderRadius: '3px' }}></div>
                                    </div>
                                </div>
                                <div>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.25rem' }}>
                                        <span>Mobil</span>
                                        <span>%1.8</span>
                                    </div>
                                    <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                        <div style={{ width: '45%', height: '100%', background: 'var(--color-text-secondary)', borderRadius: '3px' }}></div>
                                    </div>
                                </div>
                            </div>
                        </ReportCard>
                    </div>
                </div>

                {/* Key Metrics Column */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {[
                        { label: 'Toplam Gelir (7 Gün)', value: `$${totalRevenue.toLocaleString()}`, trend: 'Canlı', good: true },
                        { label: 'Mevcut Bütçe', value: `$${company.budget.toLocaleString()}`, trend: '-', good: company.budget > 10000 },
                        { label: 'Yatırım Getirisi (ROAS)', value: '2.5x', trend: 'Tahmini', good: true },
                        { label: 'Aktif Kampanyalar', value: useGameStore.getState().campaigns.length, trend: '', good: true },
                    ].map((metric, i) => (
                        <div key={i} className="glass-card" style={{ padding: '1.25rem' }}>
                            <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>{metric.label}</div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                                <div style={{ fontSize: '1.5rem', fontWeight: '700' }}>{metric.value}</div>
                                <div style={{
                                    display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.85rem', fontWeight: '600',
                                    color: metric.good ? 'var(--color-success)' : 'var(--color-warning)'
                                }}>
                                    {metric.good ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
                                    {metric.trend}
                                </div>
                            </div>
                        </div>
                    ))}

                    <div className="glass-card" style={{ padding: '1.5rem', flex: 1, background: 'var(--color-accent)', color: 'white' }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: '0.5rem' }}>Analist İçgörüsü</h3>
                        <p style={{ fontSize: '0.9rem', opacity: 0.9, lineHeight: '1.5' }}>
                            "{totalRevenue > 1000 ? 'Gelir akışı sağlıklı görünüyor. Bütçeyi artırarak ölçeklenebilirsiniz.' : 'Gelirler düşük seyrediyor. Yeni kampanyalar başlatmayı veya SEO\'ya odaklanmayı düşünün.'}"
                        </p>
                    </div>
                </div>

            </div>
        </div>
    )
}
