import React, { useState } from 'react'
import { Target, Crosshair, Zap, Shield, Activity } from 'lucide-react'
import { useGameStore } from '../../store/gameStore'

const StrategyCard = ({ title, description, active, onClick, icon: Icon }) => (
    <div
        onClick={onClick}
        className="glass-card"
        style={{
            padding: '1.5rem', cursor: 'pointer',
            border: active ? '2px solid var(--color-accent)' : '1px solid rgba(255,255,255,0.1)',
            background: active ? 'rgba(59, 130, 246, 0.1)' : 'rgba(255,255,255,0.5)',
            transition: 'all 0.2s ease'
        }}
    >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
            <div style={{
                width: '40px', height: '40px', borderRadius: '50%',
                background: active ? 'var(--color-accent)' : 'var(--color-bg-tertiary)',
                color: active ? 'white' : 'var(--color-text-secondary)',
                display: 'flex', alignItems: 'center', justifyContent: 'center'
            }}>
                <Icon size={20} />
            </div>
            <h3 style={{ fontSize: '1.1rem', fontWeight: '600' }}>{title}</h3>
        </div>
        <p style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)', lineHeight: '1.5' }}>
            {description}
        </p>
    </div>
)

export const StrategyHub = () => {
    const [activeArchetype, setActiveArchetype] = useState('GROWTH')

    const archetypes = [
        { id: 'GROWTH', title: 'Agresif Büyüme', icon: Zap, desc: 'Hızlı kullanıcı kazanımına odaklanma. Yüksek reklam harcaması, riskli kampanyalar. Startup\'lar için ideal.' },
        { id: 'BRAND', title: 'Marka İnşası', icon: Shield, desc: 'İtibar ve uzun vadeli değere odaklanma. Yüksek içerik kalitesi, düşük hacim. Köklü firmalar için.' },
        { id: 'BALANCED', title: 'Dengeli Yaklaşım', icon: Activity, desc: 'Performans pazarlaması ve marka bilinirliğinin karışımı. Orta risk ve istikrarlı büyüme.' }
    ]

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Strateji Merkezi</h2>
                <p style={{ color: 'var(--color-text-secondary)' }}>Ajansınızın pazarlama felsefesini belirleyin.</p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1.5rem' }}>
                {archetypes.map(arch => (
                    <StrategyCard
                        key={arch.id}
                        title={arch.title}
                        description={arch.desc}
                        icon={arch.icon}
                        active={activeArchetype === arch.id}
                        onClick={() => setActiveArchetype(arch.id)}
                    />
                ))}
            </div>

            <div className="glass-card" style={{ padding: '2rem', flex: 1 }}>
                <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Crosshair size={20} />
                    Stratejik Odak Alanları
                </h3>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
                    <div>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '600' }}>Bütçe Dağılımı</label>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.5rem', color: 'var(--color-text-secondary)' }}>
                            <span>Reklam (%60)</span>
                            <span>İçerik (%40)</span>
                        </div>
                        <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px', overflow: 'hidden' }}>
                            <div style={{ width: '60%', height: '100%', background: 'var(--color-accent)' }}></div>
                        </div>
                    </div>

                    <div>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '600' }}>Hedef Kitle</label>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <span style={{ padding: '0.25rem 0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: '1rem', fontSize: '0.85rem' }}>Z Kuşağı</span>
                            <span style={{ padding: '0.25rem 0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: '1rem', fontSize: '0.85rem' }}>Teknoloji Sever</span>
                            <span style={{ padding: '0.25rem 0.75rem', background: 'var(--color-accent)', color: 'white', borderRadius: '1rem', fontSize: '0.85rem' }}>B2B</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
