import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Mic, MessageSquare, TrendingUp, AlertCircle, CheckCircle, X } from 'lucide-react'

const PressQuestionCard = ({ question, onAnswer }) => {
    const [selectedAnswer, setSelectedAnswer] = useState(null)

    const handleAnswer = (answer) => {
        setSelectedAnswer(answer)
        setTimeout(() => {
            onAnswer(answer)
            setSelectedAnswer(null)
        }, 800)
    }

    return (
        <div className="glass-card" style={{
            padding: '2rem',
            marginBottom: '1.5rem',
            border: selectedAnswer ? `2px solid ${selectedAnswer.impact > 0 ? 'var(--color-success)' : '#ef4444'}` : 'none',
            transition: 'all 0.3s ease'
        }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '1rem', marginBottom: '1.5rem' }}>
                <div style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '50%',
                    background: 'var(--color-bg-tertiary)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
                    <MessageSquare size={24} color="var(--color-text-secondary)" />
                </div>
                <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>
                        {question.reporter}
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '600', lineHeight: '1.6' }}>
                        {question.text}
                    </div>
                </div>
            </div>

            <div style={{ display: 'grid', gap: '1rem' }}>
                {question.answers.map((answer, idx) => (
                    <button
                        key={idx}
                        onClick={() => handleAnswer(answer)}
                        disabled={selectedAnswer !== null}
                        style={{
                            padding: '1rem 1.25rem',
                            background: selectedAnswer === answer
                                ? (answer.impact > 0 ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)')
                                : 'var(--color-bg-secondary)',
                            border: selectedAnswer === answer
                                ? `2px solid ${answer.impact > 0 ? 'var(--color-success)' : '#ef4444'}`
                                : '1px solid var(--color-bg-tertiary)',
                            borderRadius: 'var(--radius-md)',
                            textAlign: 'left',
                            cursor: selectedAnswer ? 'default' : 'pointer',
                            transition: 'all 0.2s ease',
                            opacity: selectedAnswer && selectedAnswer !== answer ? 0.4 : 1
                        }}
                    >
                        <div style={{ fontSize: '0.95rem', marginBottom: '0.5rem' }}>{answer.text}</div>
                        {selectedAnswer === answer && (
                            <div style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem',
                                fontSize: '0.85rem',
                                color: answer.impact > 0 ? 'var(--color-success)' : '#ef4444',
                                marginTop: '0.5rem',
                                fontWeight: '600'
                            }}>
                                {answer.impact > 0 ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
                                {answer.feedback}
                            </div>
                        )}
                    </button>
                ))}
            </div>
        </div>
    )
}

export const PressConference = () => {
    const boardTrust = useGameStore(state => state.boardTrust)
    const company = useGameStore(state => state.company)
    const campaigns = useGameStore(state => state.campaigns)
    const addXP = useGameStore(state => state.addXP)
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
    const [totalImpact, setTotalImpact] = useState(0)
    const [isComplete, setIsComplete] = useState(false)

    // Generate questions based on game state
    const questions = [
        {
            reporter: "Teknoloji Gazetesi",
            text: `${company.name} son zamanlarda ${campaigns.length > 3 ? 'önemli' : 'mütevazı'} kampanya aktiviteleri gösterdi. Stratejinizin yenilikten yoksun olduğunu söyleyen eleştirmenlere ne dersiniz?`,
            answers: [
                {
                    text: "Veriye dayalı kararlara odaklanıyoruz ve sonuçlar ortada.",
                    impact: 3,
                    feedback: "Yönetim kurulu güveninizi takdir etti. +3 Güven"
                },
                {
                    text: "İnovasyon zaman alır. Trendleri kovalamak yerine sürdürülebilir büyüme inşa ediyoruz.",
                    impact: 5,
                    feedback: "Mükemmel diplomatik cevap! +5 Güven"
                },
                {
                    text: "Eleştirmenlerimiz modern pazarlamadan anlamıyor.",
                    impact: -2,
                    feedback: "Çok savunmacı. Yönetim alçakgönüllülüğü tercih eder. -2 Güven"
                }
            ]
        },
        {
            reporter: "İş Dünyası Dergisi",
            text: `Yönetim kurulu güveni şu anda %${boardTrust}. Paydaş güvenini artırmak için planınız nedir?`,
            answers: [
                {
                    text: "Yeni KPI takibi ve aylık raporlama sistemleri uyguluyoruz.",
                    impact: 4,
                    feedback: "Yönetim şeffaflığa değer veriyor. +4 Güven"
                },
                {
                    text: "Gelir hedeflerimize ulaştığımızda güven artacaktır.",
                    impact: 1,
                    feedback: "Adil ama beklenen bir cevap. +1 Güven"
                },
                {
                    text: "Yönetim kurulunun beklentilerinin yeniden ayarlanması gerektiğine inanıyorum.",
                    impact: -5,
                    feedback: "Çok riskli bir ifade! Yönetim rahatsız oldu. -5 Güven"
                }
            ]
        },
        {
            reporter: "Pazarlama Haftası",
            text: "Pazarlama yaklaşımınızı sektördeki rakiplerden ayıran nedir?",
            answers: [
                {
                    text: "Yaratıcı hikaye anlatımını titiz A/B testleri ve analizlerle birleştiriyoruz.",
                    impact: 6,
                    feedback: "Sanat ve bilimin mükemmel karışımı! +6 Güven"
                },
                {
                    text: "Rakiplerimizden daha verimli harcama yapıyoruz.",
                    impact: 2,
                    feedback: "Pratik ama ilham verici değil. +2 Güven"
                },
                {
                    text: "Rakiplerimiz bizim yıllar önce ustalaştığımız şeyleri hala çözmeye çalışıyor.",
                    impact: -3,
                    feedback: "Kibir iyi karşılanmaz. -3 Güven"
                }
            ]
        },
        {
            reporter: "Finans Gündemi",
            text: `Bütçe kullanımınız ve ROI hedefleriniz hakkında endişeler var. ${company.budget < 20000 ? 'Bütçeniz kritik seviyede.' : 'Yatırımcılar daha yüksek getiri bekliyor.'} Ne söylemek istersiniz?`,
            answers: [
                {
                    text: "Uzun vadeli marka değerine yatırım yapıyoruz, kısa vadeli kârlar ikinci planda.",
                    impact: -1,
                    feedback: "Riskli bir duruş. Yatırımcılar nakit akışı ister. -1 Güven"
                },
                {
                    text: "Önümüzdeki çeyrekte verimliliği artırmak için agresif optimizasyonlar planlıyoruz.",
                    impact: 5,
                    feedback: "Yatırımcıların duymak istediği tam olarak bu. +5 Güven"
                },
                {
                    text: "Piyasa koşulları zorlu, herkes bu sorunları yaşıyor.",
                    impact: -4,
                    feedback: "Bahane üretmek liderlik değildir. -4 Güven"
                }
            ]
        },
        {
            reporter: "Sosyal Medya Trendleri",
            text: "Viral trendleri yakalamakta yavaş kaldığınız düşünülüyor. İçerik stratejiniz çok mu kurumsal?",
            answers: [
                {
                    text: "Marka güvenliğimiz her şeyden önce gelir. Her akıma atlamıyoruz.",
                    impact: 4,
                    feedback: "Güvenli ve olgun bir cevap. Kurumsal itibar için iyi. +4 Güven"
                },
                {
                    text: "Daha agile bir içerik ekibi kuruyoruz.",
                    impact: 2,
                    feedback: "İyi niyetli ama eylem gerekiyor. +2 Güven"
                },
                {
                    text: "TikTok dansı mı yapmamızı bekliyorsunuz? Biz profesyonel bir şirketiz.",
                    impact: -3,
                    feedback: "Değişime dirençli ve elitist göründünüz. -3 Güven"
                }
            ]
        }
    ]

    const handleAnswer = (answer) => {
        setTotalImpact(prev => prev + answer.impact)

        // Update game state based on answer impact
        const currentTrust = boardTrust + answer.impact
        useGameStore.setState({ boardTrust: Math.min(100, Math.max(0, currentTrust)) })

        // Move to next question or complete
        if (currentQuestionIndex < questions.length - 1) {
            setTimeout(() => {
                setCurrentQuestionIndex(prev => prev + 1)
            }, 1200)
        } else {
            setTimeout(() => {
                setIsComplete(true)
                // Reward XP for completing press conference
                addXP(totalImpact > 5 ? 300 : totalImpact > 0 ? 150 : 50)
            }, 1200)
        }
    }

    if (isComplete) {
        return (
            <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div className="glass-card" style={{ maxWidth: '500px', padding: '3rem', textAlign: 'center' }}>
                    <div style={{
                        width: '80px',
                        height: '80px',
                        borderRadius: '50%',
                        background: totalImpact > 5 ? 'rgba(16, 185, 129, 0.2)' : totalImpact > 0 ? 'rgba(59, 130, 246, 0.2)' : 'rgba(239, 68, 68, 0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 1.5rem'
                    }}>
                        {totalImpact > 5 ? <CheckCircle size={40} color="var(--color-success)" /> :
                            totalImpact > 0 ? <TrendingUp size={40} color="var(--color-accent)" /> :
                                <AlertCircle size={40} color="#ef4444" />}
                    </div>
                    <h2 style={{ fontSize: '1.8rem', fontWeight: '700', marginBottom: '1rem' }}>
                        Basın Toplantısı Tamamlandı
                    </h2>
                    <p style={{ fontSize: '1.1rem', color: 'var(--color-text-secondary)', marginBottom: '2rem' }}>
                        {totalImpact > 5 && "Olağanüstü performans! Medya çok etkilendi."}
                        {totalImpact > 0 && totalImpact <= 5 && "Soruları makul bir şekilde yönettiniz."}
                        {totalImpact <= 0 && "Daha iyi olabilirdi. Bir dahaki sefere kelimelerinizi daha dikkatli seçin."}
                    </p>
                    <div style={{
                        padding: '1.5rem',
                        background: 'var(--color-bg-tertiary)',
                        borderRadius: 'var(--radius-md)',
                        marginBottom: '2rem'
                    }}>
                        <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>
                            Toplam Etki
                        </div>
                        <div style={{ fontSize: '2.5rem', fontWeight: '900', color: totalImpact > 0 ? 'var(--color-success)' : '#ef4444' }}>
                            {totalImpact > 0 ? '+' : ''}{totalImpact} Güven
                        </div>
                    </div>
                    <button
                        onClick={() => window.location.reload()}
                        style={{
                            width: '100%',
                            padding: '1rem',
                            background: 'var(--color-accent)',
                            color: 'white',
                            border: 'none',
                            borderRadius: 'var(--radius-md)',
                            fontSize: '1rem',
                            fontWeight: '700',
                            cursor: 'pointer'
                        }}
                    >
                        Ofise Dön
                    </button>
                </div>
            </div>
        )
    }

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Mic size={28} />
                        Basın Toplantısı
                    </h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>
                        Soruları dikkatli cevaplayın - tepkileriniz yönetim kurulu güvenini etkiler
                    </p>
                </div>
                <div className="glass-card" style={{ padding: '0.75rem 1.25rem' }}>
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>İlerleme</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: '700' }}>
                        {currentQuestionIndex + 1} / {questions.length}
                    </div>
                </div>
            </div>

            {/* Progress Bar */}
            <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px' }}>
                <div style={{
                    width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`,
                    height: '100%',
                    background: 'linear-gradient(90deg, var(--color-accent), #60a5fa)',
                    borderRadius: '4px',
                    transition: 'width 0.5s ease'
                }}></div>
            </div>

            {/* Current Question */}
            <div style={{ flex: 1, overflowY: 'auto' }}>
                <PressQuestionCard
                    key={currentQuestionIndex}
                    question={questions[currentQuestionIndex]}
                    onAnswer={handleAnswer}
                />
            </div>

            {/* Impact Tracker */}
            <div className="glass-card" style={{
                padding: '1rem 1.5rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                background: totalImpact > 0 ? 'rgba(16, 185, 129, 0.05)' : totalImpact < 0 ? 'rgba(239, 68, 68, 0.05)' : 'var(--color-bg-secondary)'
            }}>
                <span style={{ fontWeight: '600' }}>Mevcut Oturum Etkisi:</span>
                <span style={{
                    fontSize: '1.25rem',
                    fontWeight: '700',
                    color: totalImpact > 0 ? 'var(--color-success)' : totalImpact < 0 ? '#ef4444' : 'var(--color-text-primary)'
                }}>
                    {totalImpact > 0 ? '+' : ''}{totalImpact} Güven
                </span>
            </div>
        </div>
    )
}
