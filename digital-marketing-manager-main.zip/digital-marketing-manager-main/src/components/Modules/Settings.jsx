import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Save, RotateCcw, Volume2, Moon, Monitor, Shield } from 'lucide-react'

const SettingRow = ({ icon: Icon, label, description, action }) => (
    <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '1.5rem', borderBottom: '1px solid rgba(0,0,0,0.05)'
    }}>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <div style={{
                width: '40px', height: '40px', borderRadius: '8px',
                background: 'var(--color-bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--color-text-secondary)'
            }}>
                <Icon size={20} />
            </div>
            <div>
                <div style={{ fontWeight: '600' }}>{label}</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{description}</div>
            </div>
        </div>
        <div>
            {action}
        </div>
    </div>
)

export const Settings = () => {
    const resetGame = useGameStore(state => state.resetGame)

    const handleReset = () => {
        if (window.confirm('Kariyerinizi sıfırlamak istediğinize emin misiniz? Tüm ilerleme kaybolacak.')) {
            resetGame()
            window.location.reload()
        }
    }

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Ayarlar</h2>
                <p style={{ color: 'var(--color-text-secondary)' }}>Oyun tercihlerinizi ve verilerinizi yönetin.</p>
            </div>

            <div className="glass-card" style={{ padding: '0' }}>
                <SettingRow
                    icon={Save}
                    label="Otomatik Kayıt"
                    description="Oyun her gün sonunda ilerlemenizi otomatik olarak kaydeder."
                    action={
                        <div style={{ color: 'var(--color-success)', fontWeight: '600', fontSize: '0.9rem' }}>Aktif</div>
                    }
                />
                <SettingRow
                    icon={Volume2}
                    label="Ses Efektleri"
                    description="Arayüz ve olay seslerini aç/kapat."
                    action={
                        <label className="switch">
                            <input type="checkbox" defaultChecked />
                            <span className="slider round"></span>
                        </label>
                    }
                />
                <SettingRow
                    icon={Moon}
                    label="Karanlık Mod"
                    description="Aydınlık ve karanlık tema arasında geçiş yap."
                    action={
                        <label className="switch">
                            <input type="checkbox" />
                            <span className="slider round"></span>
                        </label>
                    }
                />
                <SettingRow
                    icon={Monitor}
                    label="Grafik Kalitesi"
                    description="Performans için görsel efektleri ayarla."
                    action={
                        <select style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ddd' }}>
                            <option>Yüksek</option>
                            <option>Orta</option>
                            <option>Düşük</option>
                        </select>
                    }
                />
            </div>

            <div className="glass-card" style={{ padding: '0', border: '1px solid #fee2e2' }}>
                <SettingRow
                    icon={RotateCcw}
                    label="Kariyeri Sıfırla"
                    description="Kayıt dosyasını kalıcı olarak sil ve baştan başla."
                    action={
                        <button
                            onClick={handleReset}
                            style={{
                                padding: '0.5rem 1rem', background: '#fee2e2', color: '#ef4444',
                                border: 'none', borderRadius: 'var(--radius-sm)', fontWeight: '600', cursor: 'pointer'
                            }}
                        >
                            Verileri Sıfırla
                        </button>
                    }
                />
            </div>

            <div style={{ textAlign: 'center', marginTop: 'auto', color: 'var(--color-text-secondary)', fontSize: '0.8rem' }}>
                <p>Digital Marketing Manager 2025 • v0.8.2 Beta</p>
                <p>Created with React & Three.js</p>
            </div>
        </div>
    )
}
