import React from 'react'
import { DollarSign, TrendingUp, TrendingDown, PieChart } from 'lucide-react'
import { useGameStore } from '../../store/gameStore'

const TransactionRow = ({ description, amount, date, type }) => (
    <div style={{
        display: 'flex', justifyContent: 'space-between', padding: '1rem',
        borderBottom: '1px solid rgba(0,0,0,0.05)', alignItems: 'center'
    }}>
        <div>
            <div style={{ fontWeight: '600' }}>{description}</div>
            <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{date}</div>
        </div>
        <div style={{
            fontWeight: '700',
            color: type === 'INCOME' ? 'var(--color-success)' : 'var(--color-warning)'
        }}>
            {type === 'INCOME' ? '+' : '-'}${amount.toLocaleString()}
        </div>
    </div>
)

export const Finances = () => {
    const company = useGameStore(state => state.company)

    const transactions = [
        { id: 1, description: "Reklam Geliri (Google)", amount: 12500, date: "15 Oca", type: "INCOME" },
        { id: 2, description: "Personel Maaşları", amount: 16250, date: "15 Oca", type: "EXPENSE" },
        { id: 3, description: "Reklam Harcaması (Meta)", amount: 4500, date: "14 Oca", type: "EXPENSE" },
        { id: 4, description: "Müşteri Ödemesi", amount: 8000, date: "10 Oca", type: "INCOME" },
    ]

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Finans</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Gelir, gider ve karlılığı takip edin.</p>
                </div>
                <div className="glass-card" style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <DollarSign size={18} />
                    <span style={{ fontWeight: '700', fontSize: '1.1rem' }}>${company?.budget?.toLocaleString()}</span>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '2rem' }}>
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <TrendingUp size={20} color="var(--color-success)" /> Gelir
                    </h3>
                    <div style={{ fontSize: '2rem', fontWeight: '700' }}>$20,500</div>
                    <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>Bu Ay</div>
                </div>
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <TrendingDown size={20} color="var(--color-warning)" /> Gider
                    </h3>
                    <div style={{ fontSize: '2rem', fontWeight: '700' }}>$20,750</div>
                    <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>Bu Ay</div>
                </div>
            </div>

            <div className="glass-card" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                <div style={{ padding: '1rem', borderBottom: '1px solid rgba(0,0,0,0.05)', fontWeight: '600', color: 'var(--color-text-secondary)' }}>
                    Son İşlemler
                </div>
                <div style={{ overflowY: 'auto', flex: 1 }}>
                    {transactions.map(t => (
                        <TransactionRow key={t.id} {...t} />
                    ))}
                </div>
            </div>
        </div>
    )
}
