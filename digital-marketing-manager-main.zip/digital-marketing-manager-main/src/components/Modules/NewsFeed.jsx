import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Newspaper, TrendingUp, AlertTriangle, Zap } from 'lucide-react'

const NewsItem = ({ title, source, date, type }) => (
    <div className="glass-card" style={{
        padding: '1rem',
        marginBottom: '1rem',
        display: 'flex',
        gap: '1rem',
        borderLeft: type === 'EVENT' ? '4px solid var(--color-error)' : 'none'
    }}>
        <div style={{
            width: '50px', height: '50px', borderRadius: '8px',
            background: type === 'RUMOR' ? '#fef3c7' : type === 'EVENT' ? '#fee2e2' : '#e0f2fe',
            color: type === 'RUMOR' ? '#d97706' : type === 'EVENT' ? '#ef4444' : '#0284c7',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
            {type === 'RUMOR' ? <AlertTriangle size={24} /> : type === 'EVENT' ? <Zap size={24} /> : <TrendingUp size={24} />}
        </div>
        <div>
            <h4 style={{ fontSize: '1rem', marginBottom: '0.25rem' }}>{title}</h4>
            <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                {source} • {date}
            </div>
        </div>
    </div>
)

export const NewsFeed = () => {
    const activeEvents = useGameStore(state => state.activeEvents || [])

    const staticNews = [
        { id: 1, title: "Google Büyük Çekirdek Güncellemesini Duyurdu", source: "SearchEngineLand", date: "5 Oca", type: "NEWS" },
        { id: 2, title: "Söylenti: TikTok gelecek ay yeni reklam formatı başlatıyor", source: "AdWeek", date: "8 Oca", type: "RUMOR" },
    ]

    const eventNews = activeEvents.map(event => ({
        id: event.id,
        title: `ALGORİTMA ALARMI: ${event.name}`,
        source: "Sistem Uyarısı",
        date: new Date(event.startDate).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }),
        type: "EVENT"
    }))

    const allNews = [...eventNews, ...staticNews]

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Sektör Haberleri</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>En son trendler ve söylentilerden haberdar olun.</p>
                </div>
            </div>

            <div style={{ flex: 1, overflowY: 'auto' }}>
                {allNews.map(item => (
                    <NewsItem key={item.id} {...item} />
                ))}
            </div>
        </div>
    )
}

