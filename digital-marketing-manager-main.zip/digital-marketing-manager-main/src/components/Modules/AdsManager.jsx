
import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Plus, TrendingUp, MousePointer, DollarSign, Layout, Instagram, Facebook, Video, BarChart2, Target, X, Sparkles, AlertCircle } from 'lucide-react'

const PlatformIcon = ({ platform }) => {
    switch (platform) {
        case 'Google': return <Layout size={18} />
        case 'Meta': return <Facebook size={18} />
        case 'TikTok': return <Video size={18} />
        default: return <Layout size={18} />
    }
}

const CreateCampaignModal = ({ onClose }) => {
    const addCampaign = useGameStore(state => state.addCampaign)
    const [step, setStep] = useState(1)
    const [error, setError] = useState('')
    const [form, setForm] = useState({
        name: '',
        platform: 'Google',
        budget: 1000,
        objective: 'Trafik', // Translated
        format: 'Görsel', // Translated
        targeting: 'Geniş Kitle (Maks. Erişim)' // Translated
    })

    const handleAiSuggest = () => {
        // AI Optimization Simulation
        const suggestions = [
            { platform: 'TikTok', objective: 'Bilinirlik', format: 'Video', targeting: 'İlgi Alanı' },
            { platform: 'Meta', objective: 'Dönüşüm', format: 'Carousel', targeting: 'Yeniden Hedefleme' },
            { platform: 'Google', objective: 'Trafik', format: 'Görsel', targeting: 'Geniş Kitle' }
        ];
        const random = suggestions[Math.floor(Math.random() * suggestions.length)];
        setForm({ ...form, ...random, budget: Math.floor(Math.random() * 2000) + 500, name: `AI Optimize Kampanya #${Math.floor(Math.random() * 100)} ` });
        setError(''); // Clear any previous errors
    }

    const handleSubmit = () => {
        if (!form.name) {
            setError('Lütfen kampanya adı giriniz.');
            return;
        }
        if (form.budget <= 0) {
            setError('Bütçe 0’dan büyük olmalıdır.');
            return;
        }
        addCampaign(form)
        onClose()
    }

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100,
            backdropFilter: 'blur(4px)'
        }}>
            <div className="glass-card" style={{ width: '600px', padding: '2rem', background: 'white' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Yeni Kampanya Sihirbazı</h2> {/* Translated */}
                    <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={24} /></button>
                </div>

                {/* Automation Prompt */}
                {step === 1 && (
                    <div
                        onClick={handleAiSuggest}
                        style={{
                            background: 'linear-gradient(135deg, #6366f1, #a855f7)', padding: '1rem', borderRadius: 'var(--radius-md)',
                            marginBottom: '2rem', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                            cursor: 'pointer', boxShadow: '0 4px 12px rgba(99, 102, 241, 0.3)'
                        }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                            <Sparkles size={24} />
                            <div>
                                <div style={{ fontWeight: '700' }}>AI Strateji Oluşturucu</div> {/* Translated */}
                                <div style={{ fontSize: '0.85rem', opacity: 0.9 }}>Bırakın yapay zeka sizin için en iyi ayarları seçsin.</div> {/* Translated */}
                            </div>
                        </div>
                        <div style={{ background: 'rgba(255,255,255,0.2)', padding: '0.5rem 1rem', borderRadius: '2rem', fontSize: '0.85rem', fontWeight: '600' }}>
                            Otomatik Doldur {/* Translated */}
                        </div>
                    </div>
                )}

                {/* Progress Steps */}
                <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem' }}>
                    {[1, 2, 3].map(s => (
                        <div key={s} style={{ flex: 1, height: '4px', background: s <= step ? 'var(--color-accent)' : '#eee', borderRadius: '2px' }}></div>
                    ))}
                </div>

                {error && (
                    <div style={{ padding: '0.75rem', background: '#fee2e2', color: '#ef4444', borderRadius: 'var(--radius-sm)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <AlertCircle size={16} /> {error}
                    </div>
                )}

                {step === 1 && (
                    <div>
                        <h3 style={{ marginBottom: '1rem' }}>1. Kampanya Temelleri</h3> {/* Translated */}
                        <div style={{ marginBottom: '1rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Kampanya Adı</label> {/* Translated */}
                            <input
                                type="text"
                                value={form.name}
                                onChange={e => { setForm({ ...form, name: e.target.value }); setError(''); }}
                                style={{ width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid #ddd' }}
                                placeholder="Örn: Yaz İndirimleri"
                            />
                        </div>
                        <div style={{ marginBottom: '1rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Hedef</label> {/* Translated */}
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                                {['Trafik', 'Dönüşüm', 'Bilinirlik'].map(obj => ( // Translated
                                    <div
                                        key={obj}
                                        onClick={() => { setForm({ ...form, objective: obj }); setError(''); }}
                                        style={{
                                            padding: '1rem', border: form.objective === obj ? '2px solid var(--color-accent)' : '1px solid #ddd',
                                            borderRadius: 'var(--radius-md)', cursor: 'pointer', textAlign: 'center',
                                            background: form.objective === obj ? 'rgba(59, 130, 246, 0.05)' : 'transparent'
                                        }}
                                    >
                                        {obj}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {step === 2 && (
                    <div>
                        <h3 style={{ marginBottom: '1rem' }}>2. Platform ve Bütçe</h3> {/* Translated */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                            <div>
                                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Platform</label> {/* Translated */}
                                <select
                                    value={form.platform}
                                    onChange={e => { setForm({ ...form, platform: e.target.value }); setError(''); }}
                                    style={{ width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid #ddd' }}
                                >
                                    <option>Google</option>
                                    <option>Meta</option>
                                    <option>TikTok</option>
                                </select>
                            </div>
                            <div>
                                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Günlük Bütçe ($)</label> {/* Translated */}
                                <input
                                    type="number"
                                    min="1" // Added validation
                                    value={form.budget}
                                    onChange={e => { setForm({ ...form, budget: parseInt(e.target.value) }); setError(''); }}
                                    style={{ width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid #ddd' }}
                                />
                            </div>
                        </div>
                    </div>
                )}

                {step === 3 && (
                    <div>
                        <h3 style={{ marginBottom: '1rem' }}>3. Kreatif ve Hedefleme</h3> {/* Translated */}
                        <div style={{ marginBottom: '1rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Reklam Formatı</label> {/* Translated */}
                            <div style={{ display: 'flex', gap: '1rem' }}>
                                {['Görsel', 'Video', 'Carousel'].map(fmt => ( // Translated
                                    <button
                                        key={fmt}
                                        onClick={() => { setForm({ ...form, format: fmt }); setError(''); }}
                                        style={{
                                            padding: '0.5rem 1rem', borderRadius: '2rem', border: 'none',
                                            background: form.format === fmt ? 'var(--color-accent)' : '#eee',
                                            color: form.format === fmt ? 'white' : 'var(--color-text-secondary)',
                                            cursor: 'pointer'
                                        }}
                                    >
                                        {fmt}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div style={{ marginBottom: '1rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Hedefleme Stratejisi</label> {/* Translated */}
                            <select
                                value={form.targeting}
                                onChange={e => { setForm({ ...form, targeting: e.target.value }); setError(''); }}
                                style={{ width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid #ddd' }}
                            >
                                <option>Geniş Kitle (Maks. Erişim)</option> {/* Translated */}
                                <option>İlgi Alanı (Dengeli)</option> {/* Translated */}
                                <option>Yeniden Hedefleme (Yüksek Dönüşüm)</option> {/* Translated */}
                            </select>
                        </div>
                    </div>
                )}

                <div style={{ display: 'flex', gap: '1rem', marginTop: '2rem' }}>
                    {step > 1 && (
                        <button onClick={() => setStep(step - 1)} style={{ padding: '0.75rem 1.5rem', background: 'transparent', border: '1px solid #ddd', borderRadius: 'var(--radius-md)', cursor: 'pointer' }}>Geri</button>
                    )}
                    <div style={{ flex: 1 }}></div>
                    {step < 3 ? (
                        <button onClick={() => setStep(step + 1)} style={{ padding: '0.75rem 1.5rem', background: 'var(--color-accent)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', cursor: 'pointer' }}>Sonraki Adım</button>
                    ) : (
                        <button onClick={handleSubmit} style={{ padding: '0.75rem 1.5rem', background: 'var(--color-success)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', cursor: 'pointer' }}>Kampanyayı Başlat</button>
                    )}
                </div>
            </div>
        </div>
    )
}

export const AdsManager = () => {
    const campaigns = useGameStore(state => state.campaigns)
    const [showModal, setShowModal] = useState(false)
    const [selectedCampaign, setSelectedCampaign] = useState(null)

    // Derived insights
    const totalSpend = campaigns.reduce((acc, c) => acc + c.budget, 0)
    const dominantPlatform = campaigns.length > 0
        ? campaigns.sort((a, b) => b.budget - a.budget)[0].platform
        : 'None'

    return (
        <div style={{ height: '100%', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
            {/* Left Column: Controls & List */}
            <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                    <div>
                        <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Reklam Yöneticisi</h2> {/* Translated */}
                        <p style={{ color: 'var(--color-text-secondary)' }}>Ücretli kanallarınızı optimize edin.</p> {/* Translated */}
                    </div>
                    <button
                        onClick={() => setShowModal(true)}
                        style={{
                            display: 'flex', alignItems: 'center', gap: '0.5rem',
                            padding: '0.75rem 1.25rem', background: 'var(--color-accent)', color: 'white',
                            border: 'none', borderRadius: 'var(--radius-md)', fontWeight: '600', boxShadow: 'var(--shadow-md)',
                            cursor: 'pointer'
                        }}
                    >
                        <Plus size={18} />
                        Yeni Kampanya {/* Translated */}
                    </button>
                </div>

                {campaigns.length === 0 ? (
                    <div className="glass-card" style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-secondary)' }}>
                        <TrendingUp size={48} style={{ marginBottom: '1rem', opacity: 0.5 }} />
                        <h3>Aktif Kampanya Yok</h3> {/* Translated */}
                        <p>Trafik çekmek için ilk kampanyanızı başlatın.</p> {/* Translated */}
                    </div>
                ) : (
                    <div style={{ display: 'grid', gap: '1rem', overflowY: 'auto' }}>
                        {campaigns.map(campaign => (
                            <div
                                key={campaign.id}
                                onClick={() => setSelectedCampaign(campaign)}
                                className="glass-card"
                                style={{
                                    padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                    border: selectedCampaign?.id === campaign.id ? '2px solid var(--color-accent)' : 'none',
                                    cursor: 'pointer'
                                }}
                            >
                                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                    <div style={{
                                        width: '40px', height: '40px', borderRadius: '8px',
                                        background: 'var(--color-bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center'
                                    }}>
                                        <PlatformIcon platform={campaign.platform} />
                                    </div>
                                    <div>
                                        <div style={{ fontWeight: '600' }}>{campaign.name}</div>
                                        <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{campaign.platform} • ${campaign.budget}/gün</div> {/* Translated */}
                                    </div>
                                </div>

                                <div style={{ display: 'flex', gap: '2rem' }}>
                                    <div style={{ textAlign: 'right' }}>
                                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Gösterim</div> {/* Translated */}
                                        <div style={{ fontWeight: '600' }}>{campaign.results.impressions.toLocaleString()}</div>
                                    </div>
                                    <div style={{ textAlign: 'right' }}>
                                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Tık</div> {/* Translated */}
                                        <div style={{ fontWeight: '600' }}>{campaign.results.clicks.toLocaleString()}</div>
                                    </div>
                                    <div style={{ textAlign: 'right' }}>
                                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Dönüşüm</div> {/* Translated */}
                                        <div style={{ fontWeight: '600' }}>{campaign.results.conversions.toLocaleString()}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Right Column: Insights & Details */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                {selectedCampaign ? (
                    <div className="glass-card" style={{ padding: '1.5rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                            <h3 style={{ fontSize: '1.1rem' }}>Kampanya Detayları</h3> {/* Translated */}
                            <button onClick={() => setSelectedCampaign(null)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={18} /></button>
                        </div>

                        <div style={{ marginBottom: '2rem' }}>
                            <div style={{ fontSize: '2rem', fontWeight: '700', color: 'var(--color-accent)' }}>
                                %{((selectedCampaign.results.clicks / (selectedCampaign.results.impressions || 1)) * 100).toFixed(2)}
                            </div>
                            <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>Tıklama Oranı (TO)</div> {/* Translated */}
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                            <div style={{ padding: '1rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>KREATİF KALİTESİ</div> {/* Translated */}
                                <div style={{ fontWeight: '600' }}>{selectedCampaign.creativeQuality || 5}/10</div>
                            </div>
                            <div style={{ padding: '1rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>AI BASKISI</div> {/* Translated */}
                                <div style={{ fontWeight: '600', color: (selectedCampaign.competitorPressure || 1) > 1.2 ? 'var(--color-error)' : 'var(--color-text-primary)' }}>
                                    {(selectedCampaign.competitorPressure || 1).toFixed(2)}x
                                </div>
                            </div>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '2rem' }}>
                            <div style={{ padding: '1rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>HEDEFLEME</div> {/* Translated */}
                                <div style={{ fontWeight: '600' }}>{Math.round((selectedCampaign.targetingAccuracy || 0.7) * 100)}%</div>
                            </div>
                            <div style={{ padding: '1rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>ROAS</div>
                                <div style={{ fontWeight: '600' }}>{(selectedCampaign.results.conversions * 50 / (selectedCampaign.budget || 1)).toFixed(2)}x</div>
                            </div>
                        </div>

                        <div style={{ marginTop: 'auto' }}>
                            <div style={{ fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.5rem' }}>Strateji Bilgisi</div> {/* Translated */}
                            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                                <span style={{ padding: '0.25rem 0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: '1rem', fontSize: '0.8rem' }}>
                                    {selectedCampaign.objective || 'Trafik'} {/* Translated default */}
                                </span>
                                <span style={{ padding: '0.25rem 0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: '1rem', fontSize: '0.8rem' }}>
                                    {selectedCampaign.format || 'Görsel'} {/* Translated default */}
                                </span>
                                <span style={{ padding: '0.25rem 0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: '1rem', fontSize: '0.8rem', color: 'var(--color-accent)' }}>
                                    {selectedCampaign.targeting}
                                </span>
                            </div>
                        </div>

                        <div style={{ marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid var(--color-bg-tertiary)' }}>
                            <button
                                onClick={() => {
                                    alert("Kampanya optimize edildi! Hedefleme doğruluğu %5 arttı.");
                                    // In a real implementation this would call a store action
                                }}
                                style={{
                                    width: '100%',
                                    padding: '0.75rem',
                                    background: 'var(--color-accent)',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: 'var(--radius-md)',
                                    fontWeight: '600',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '0.5rem'
                                }}
                            >
                                <Sparkles size={16} /> Kampanyayı Optimize Et ($500)
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', padding: '1.5rem' }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: '1.5rem' }}>Kitle İçgörüleri</h3> {/* Translated */}

                        <div style={{ marginBottom: '2rem' }}>
                            <div style={{ fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.75rem' }}>Platform Karışımı</div> {/* Translated */}
                            {totalSpend > 0 ? (
                                <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>
                                    Bütçeniz ağırlıklı olarak <span style={{ fontWeight: '700', color: 'var(--color-text-primary)' }}>{dominantPlatform}</span> tarafında.
                                    Yeni kitlelere ulaşmak için çeşitlendirmeyi düşünün.
                                </div>
                            ) : (
                                <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>Veri yok.</div>
                            )}
                        </div>

                        <div>
                            <div style={{ fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.75rem' }}>Cihaz Kullanımı</div> {/* Translated */}
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                                {(() => {
                                    const mobilePercent = (dominantPlatform === 'TikTok' || dominantPlatform === 'Instagram') ? 95 : 60;
                                    const desktopPercent = 100 - mobilePercent;

                                    return (
                                        <>
                                            <div>
                                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.25rem' }}>
                                                    <span>Mobil</span>
                                                    <span>%{mobilePercent}</span>
                                                </div>
                                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                                    <div style={{ width: `${mobilePercent}%`, height: '100%', background: 'var(--color-text-secondary)', borderRadius: '3px' }}></div>
                                                </div>
                                            </div>
                                            <div>
                                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.25rem' }}>
                                                    <span>Masaüstü</span>
                                                    <span>%{desktopPercent}</span>
                                                </div>
                                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                                    <div style={{ width: `${desktopPercent}%`, height: '100%', background: 'var(--color-accent)', borderRadius: '3px' }}></div>
                                                </div>
                                            </div>
                                        </>
                                    );
                                })()}
                            </div>
                        </div>
                    </div>
                )}
                {/* Right Column: Insights & Details */}
            </div>
            {showModal && <CreateCampaignModal onClose={() => setShowModal(false)} />}
        </div>
    )
}
