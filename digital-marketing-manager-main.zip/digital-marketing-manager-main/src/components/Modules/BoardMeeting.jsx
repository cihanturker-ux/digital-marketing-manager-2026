import React from 'react'
import { Users, ThumbsUp, ThumbsDown, Target } from 'lucide-react'

export const BoardMeeting = ({ onClose, performance }) => {
    const isGoodPerformance = performance.revenue > 5000; // Simple threshold

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200
        }}>
            <div className="glass-card" style={{ width: '600px', padding: '0', background: 'white', overflow: 'hidden' }}>
                <div style={{ padding: '2rem', background: 'var(--color-text-primary)', color: 'white', textAlign: 'center' }}>
                    <Users size={48} style={{ marginBottom: '1rem' }} />
                    <h2>Aylık Yönetim Kurulu Toplantısı</h2>
                    <p style={{ opacity: 0.8 }}>Geçen ayın performansı değerlendiriliyor</p>
                </div>

                <div style={{ padding: '2rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem', padding: '1rem', background: isGoodPerformance ? '#d1fae5' : '#fee2e2', borderRadius: 'var(--radius-md)' }}>
                        {isGoodPerformance ? <ThumbsUp color="#10b981" /> : <ThumbsDown color="#ef4444" />}
                        <div>
                            <h4 style={{ color: isGoodPerformance ? '#065f46' : '#991b1b' }}>
                                {isGoodPerformance ? "Yönetim Memnun." : "Yönetim Endişeli."}
                            </h4>
                            <p style={{ fontSize: '0.9rem', color: isGoodPerformance ? '#064e3b' : '#7f1d1d' }}>
                                {isGoodPerformance
                                    ? "Gelir hedefleri tutturuldu. İyi iş çıkarmaya devam edin."
                                    : "Büyüme olmadan nakit tüketiyoruz. Bu durum değişmeli."}
                            </p>
                        </div>
                    </div>

                    <div style={{ marginBottom: '2rem' }}>
                        <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
                            <Target size={18} />
                            Gelecek Ayın Hedefleri
                        </h4>
                        <ul style={{ paddingLeft: '1.5rem', color: 'var(--color-text-secondary)' }}>
                            <li style={{ marginBottom: '0.5rem' }}>Organik trafiği %15 artır</li>
                            <li>Yeni bir TikTok kampanyası başlat</li>
                        </ul>
                    </div>

                    <button
                        onClick={onClose}
                        style={{
                            width: '100%', padding: '1rem', background: 'var(--color-accent)', color: 'white',
                            border: 'none', borderRadius: 'var(--radius-md)', fontWeight: '600'
                        }}
                    >
                        Onayla & Ofise Dön
                    </button>
                </div>
            </div>
        </div>
    )
}
