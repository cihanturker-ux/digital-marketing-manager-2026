import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Image, Send, Heart, MessageCircle, Share2, Instagram, Linkedin, Twitter, Users, TrendingUp, Zap } from 'lucide-react'

const CreatePostModal = ({ onClose, trends = [] }) => {
    const addPost = useGameStore(state => state.addPost)
    const [content, setContent] = useState('')
    const [platform, setPlatform] = useState('Instagram')
    const [viralPotential, setViralPotential] = useState(Math.floor(Math.random() * 60) + 20) // Base 20-80

    const handlePost = () => {
        if (content.trim()) {
            addPost({ content, platform, type: 'image', viralScore: viralPotential })
            onClose()
        }
    }

    // Smart Viral Logic
    React.useEffect(() => {
        let score = Math.floor(Math.random() * 40) + 30; // Base baseline
        if (content.length > 20) score += 10;

        // Trend Bonus
        const matchedTrend = trends.find(t => content.toLowerCase().includes(t.toLowerCase()));
        if (matchedTrend) score += 30;

        setViralPotential(Math.min(99, score));
    }, [content, trends])

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100,
            backdropFilter: 'blur(4px)'
        }}>
            <div className="glass-card" style={{ width: '500px', padding: '2rem', background: 'white' }}>
                <h2 style={{ marginBottom: '1.5rem' }}>Yeni Gönderi Oluştur</h2>

                <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
                    {['Instagram', 'LinkedIn', 'Twitter'].map(p => (
                        <button
                            key={p}
                            onClick={() => setPlatform(p)}
                            style={{
                                padding: '0.5rem 1rem',
                                borderRadius: '2rem',
                                border: platform === p ? '2px solid var(--color-accent)' : '1px solid #ddd',
                                background: platform === p ? 'var(--color-accent)' : 'transparent',
                                color: platform === p ? 'white' : 'var(--color-text-secondary)',
                                fontWeight: '600',
                                fontSize: '0.9rem',
                                cursor: 'pointer'
                            }}
                        >
                            {p}
                        </button>
                    ))}
                </div>

                <div style={{ marginBottom: '0.5rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <span style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Trendler:</span>
                    {trends.map(t => (
                        <span
                            key={t}
                            onClick={() => setContent(content + (content ? ' ' : '') + `#${t}`)}
                            style={{ fontSize: '0.75rem', padding: '0.1rem 0.5rem', background: 'var(--color-bg-tertiary)', borderRadius: '1rem', cursor: 'pointer', color: 'var(--color-accent)' }}
                        >
                            #{t}
                        </span>
                    ))}
                </div>

                <textarea
                    value={content}
                    onChange={e => setContent(e.target.value)}
                    placeholder="Başlığınızı buraya yazın..."
                    style={{
                        width: '100%', height: '120px', padding: '1rem',
                        borderRadius: 'var(--radius-md)', border: '1px solid #ddd', resize: 'none', marginBottom: '1rem',
                        fontFamily: 'inherit'
                    }}
                />

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', padding: '0.75rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.9rem', fontWeight: '600' }}>
                        <Zap size={16} color="#f59e0b" /> Viral Potansiyeli
                    </div>
                    <div style={{ fontWeight: '700', color: viralPotential > 70 ? 'var(--color-success)' : viralPotential > 40 ? 'var(--color-warning)' : 'var(--color-text-secondary)' }}>
                        %{viralPotential}
                    </div>
                </div>

                <div style={{
                    height: '100px', border: '2px dashed #ddd', borderRadius: 'var(--radius-md)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-secondary)',
                    marginBottom: '2rem', cursor: 'pointer'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Image size={20} />
                        <span>Görsel / Video Ekle</span>
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '1rem' }}>
                    <button onClick={onClose} style={{ flex: 1, padding: '0.75rem', background: 'transparent', border: '1px solid #ddd', borderRadius: 'var(--radius-md)', cursor: 'pointer' }}>İptal</button>
                    <button onClick={handlePost} style={{ flex: 1, padding: '0.75rem', background: 'var(--color-accent)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                        <Send size={16} /> Paylaş
                    </button>
                </div>
            </div>
        </div>
    )
}

const PostCard = ({ post }) => (
    <div className="glass-card" style={{ padding: '0', overflow: 'hidden' }}>
        <div style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '0.75rem', borderBottom: '1px solid rgba(0,0,0,0.05)' }}>
            <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: '#eee' }} />
            <div>
                <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>TechFlow Solutions</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)' }}>{post.platform}</div>
            </div>
        </div>

        <div style={{ height: '200px', background: '#f8f9fa', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#adb5bd' }}>
            <Image size={48} opacity={0.5} />
        </div>

        <div style={{ padding: '1rem' }}>
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '0.75rem' }}>
                <Heart size={20} />
                <MessageCircle size={20} />
                <Share2 size={20} />
            </div>
            <p style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
                <span style={{ fontWeight: '600' }}>TechFlow </span>
                {post.content}
            </p>
            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>
                {post.likes} beğeni • {post.comments} yorum
            </div>
        </div>
    </div>
)

const FollowerCount = ({ platform, count, icon: Icon, color }) => (
    <div className="glass-card" style={{ padding: '1.5rem', flex: 1, display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
            <Icon size={24} />
        </div>
        <div>
            <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{platform} Takipçisi</div>
            <div style={{ fontSize: '1.5rem', fontWeight: '700' }}>{count.toLocaleString()}</div>
        </div>
    </div>
)

export const SocialStudio = () => {
    const posts = useGameStore(state => state.posts)
    const followers = useGameStore(state => state.followers)
    const currentTrends = useGameStore(state => state.currentTrends) || []
    const [showModal, setShowModal] = useState(false)

    // Calculate sentiment based on likes/comments ratio of last 5 posts
    const recentPosts = posts.slice(0, 5);
    const totalEngagement = recentPosts.reduce((acc, p) => acc + p.likes + p.comments, 0);
    const sentimentScore = totalEngagement > 0 ? Math.min(95, 50 + (totalEngagement / 10)) : 50;

    return (
        <div style={{ height: '100%', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
            {/* Left Column */}
            <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                    <div>
                        <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Sosyal Stüdyo</h2>
                        <p style={{ color: 'var(--color-text-secondary)' }}>Marka varlığınızı yönetin.</p>
                    </div>
                    <button
                        onClick={() => setShowModal(true)}
                        style={{
                            display: 'flex', alignItems: 'center', gap: '0.5rem',
                            padding: '0.75rem 1.25rem', background: 'var(--color-accent)', color: 'white',
                            border: 'none', borderRadius: 'var(--radius-md)', fontWeight: '600', boxShadow: 'var(--shadow-md)',
                            cursor: 'pointer'
                        }}
                    >
                        <Send size={18} />
                        Gönderi Oluştur
                    </button>
                </div>

                <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '2rem' }}>
                    <FollowerCount platform="Instagram" count={followers.instagram} icon={Instagram} color="#E1306C" />
                    <FollowerCount platform="LinkedIn" count={followers.linkedin} icon={Linkedin} color="#0077B5" />
                    <FollowerCount platform="Twitter" count={followers.twitter} icon={Twitter} color="#1DA1F2" />
                </div>

                {posts.length === 0 ? (
                    <div className="glass-card" style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-secondary)' }}>
                        <MessageCircle size={48} style={{ marginBottom: '1rem', opacity: 0.5 }} />
                        <h3>Henüz Gönderi Yok</h3>
                        <p>Kitlenizle etkileşime geçmeye başlayın.</p>
                    </div>
                ) : (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem', overflowY: 'auto' }}>
                        {posts.map(post => (
                            <PostCard key={post.id} post={post} />
                        ))}
                    </div>
                )}
            </div>

            {/* Right Column: Sentiment Analysis */}
            <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', padding: '1.5rem' }}>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '1.5rem' }}>Marka Duyarlılığı</h3>

                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '2rem' }}>
                    <div style={{ width: '120px', height: '120px', borderRadius: '50%', border: `10px solid ${sentimentScore > 60 ? 'var(--color-success)' : 'var(--color-warning)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
                        <span style={{ fontSize: '1.5rem', fontWeight: '700' }}>%{Math.round(sentimentScore)}</span>
                        <span style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Pozitif</span>
                    </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                            <span>Pozitif</span>
                            <span>%{Math.round(sentimentScore)}</span>
                        </div>
                        <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                            <div style={{ width: `${sentimentScore}%`, height: '100%', background: 'var(--color-success)', borderRadius: '3px' }}></div>
                        </div>
                    </div>

                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                            <span>Nötr</span>
                            <span>%{Math.round((100 - sentimentScore) * 0.7)}</span>
                        </div>
                        <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                            <div style={{ width: `${(100 - sentimentScore) * 0.7}%`, height: '100%', background: 'var(--color-text-secondary)', borderRadius: '3px' }}></div>
                        </div>
                    </div>

                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                            <span>Negatif</span>
                            <span>%{Math.round((100 - sentimentScore) * 0.3)}</span>
                        </div>
                        <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                            <div style={{ width: `${(100 - sentimentScore) * 0.3}%`, height: '100%', background: 'var(--color-warning)', borderRadius: '3px' }}></div>
                        </div>
                    </div>
                </div>

                {/* Trend Module - Small Widget */}
                <div style={{ marginTop: '2rem' }}>
                    <h4 style={{ fontSize: '0.9rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <TrendingUp size={14} /> Gündem
                    </h4>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                        {currentTrends.slice(0, 3).map(t => (
                            <span key={t} style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', background: '#e0f2fe', color: '#0369a1', borderRadius: '1rem' }}>
                                #{t}
                            </span>
                        ))}
                    </div>
                </div>
            </div>
            {showModal && <CreatePostModal onClose={() => setShowModal(false)} trends={currentTrends} />}
        </div>
    )
}
