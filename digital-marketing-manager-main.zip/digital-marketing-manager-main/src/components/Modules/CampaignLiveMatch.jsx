import React, { useState, useEffect } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Play, TrendingUp, MousePointer, DollarSign, X, CheckCircle2, AlertCircle } from 'lucide-react'

export const CampaignLiveMatch = ({ onClose }) => {
    const lastMatchResults = useGameStore(state => state.lastMatchResults)
    const activeEvents = useGameStore(state => state.activeEvents)
    const [progress, setProgress] = useState(0)
    const [log, setLog] = useState([])
    const [isFinished, setIsFinished] = useState(false)

    useEffect(() => {
        if (!lastMatchResults) return;

        const duration = 5000; // 5 seconds match
        const interval = 50;
        const steps = duration / interval;
        let currentStep = 0;

        const timer = setInterval(() => {
            currentStep++;
            const newProgress = (currentStep / steps) * 100;
            setProgress(newProgress);

            // Periodically add match logs
            if (currentStep % 20 === 0) {
                const randomLog = generateLog(lastMatchResults, activeEvents);
                if (randomLog) setLog(prev => [randomLog, ...prev.slice(0, 5)]);
            }

            if (currentStep >= steps) {
                clearInterval(timer);
                setIsFinished(true);
            }
        }, interval);

        return () => clearInterval(timer);
    }, [lastMatchResults]);

    const generateLog = (results, events) => {
        const triggers = [
            "Kampanya X yayında...",
            "İlk 1000 gösterim gerçekleşti!",
            "Tıklama oranı (CTR) stabil.",
            "Reklamlar hedef kitleye gösteriliyor.",
            "Dönüşüm geliyor! $$$",
            "Hedefleme tam isabet.",
            "Kreatif yorgunluğu tespit edildi...",
            "ROAS dalgalanıyor!"
        ];

        if (events.length > 0 && Math.random() < 0.3) {
            return { text: `ALARM: ${events[0].name} performansı etkiliyor!`, type: 'event' };
        }

        const text = triggers[Math.floor(Math.random() * triggers.length)];
        return { text, type: 'info' };
    }

    if (!lastMatchResults) return null;

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(255, 255, 255, 0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
            backdropFilter: 'blur(12px)'
        }}>
            <div className="glass-card" style={{
                width: '800px',
                padding: '2.5rem',
                background: 'rgba(255, 255, 255, 0.95)',
                boxShadow: '0 20px 50px rgba(139, 92, 246, 0.2)'
            }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                    <div>
                        <h2 className="text-gradient" style={{ fontSize: '1.5rem', fontWeight: '800', textTransform: 'uppercase', letterSpacing: '1px' }}>GÜNLÜK AKIŞ</h2>
                        <p style={{ color: 'var(--color-text-secondary)', fontSize: '0.9rem' }}>Canlı Kampanya Performansı</p>
                    </div>
                    {isFinished && (
                        <button onClick={onClose} style={{
                            background: 'var(--color-accent)',
                            color: 'white',
                            border: 'none',
                            padding: '0.75rem 1.5rem',
                            borderRadius: '2rem',
                            cursor: 'pointer',
                            fontWeight: '600',
                            boxShadow: '0 4px 12px rgba(139, 92, 246, 0.3)'
                        }}>
                            KAPAT & ANALİZ ET
                        </button>
                    )}
                </div>

                {/* Match Scoreboard */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem', marginBottom: '2rem' }}>
                    <StatCard label="GÖSTERİM" value={Math.floor(lastMatchResults.traffic * 10 * (progress / 100))} icon={Play} color="var(--color-accent)" />
                    <StatCard label="TIKLAMA" value={Math.floor(lastMatchResults.traffic * (progress / 100))} icon={MousePointer} color="#10b981" />
                    <StatCard label="DÖNÜŞÜM" value={Math.floor((lastMatchResults.revenue / 50) * (progress / 100))} icon={CheckCircle2} color="#f59e0b" />
                    <StatCard label="GELİR" value={`$${Math.floor(lastMatchResults.revenue * (progress / 100)).toLocaleString()}`} icon={DollarSign} color="#ec4899" />
                </div>

                {/* Progress Bar */}
                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '10px', marginBottom: '2rem', overflow: 'hidden' }}>
                    <div style={{ width: `${progress}%`, height: '100%', background: 'linear-gradient(90deg, var(--color-accent), #c084fc)', transition: 'width 0.05s linear', borderRadius: '10px' }}></div>
                </div>

                {/* Live Logs */}
                <div style={{
                    height: '200px',
                    overflowY: 'hidden',
                    background: '#f8fafc',
                    borderRadius: 'var(--radius-md)',
                    padding: '1.5rem',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '0.75rem',
                    border: '1px solid var(--color-bg-tertiary)',
                    fontFamily: 'monospace'
                }}>
                    {log.map((item, i) => (
                        <div key={i} style={{
                            fontSize: '0.85rem',
                            color: item.type === 'event' ? '#ef4444' : '#64748b',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.75rem',
                            animation: 'fadeIn 0.3s ease-out',
                            fontWeight: '500'
                        }}>
                            {item.type === 'event' ? <AlertCircle size={14} /> : <TrendingUp size={14} color="var(--color-accent)" />}
                            {item.text}
                        </div>
                    ))}
                    {log.length === 0 && <div style={{ color: '#94a3b8', textAlign: 'center', marginTop: '4rem', fontStyle: 'italic' }}>Bağlantı kuruluyor...</div>}
                </div>

                {isFinished && (
                    <div style={{ marginTop: '1.5rem', textAlign: 'center', color: 'var(--color-success)', fontWeight: '700', animation: 'scaleIn 0.5s ease-out' }}>
                        GÜN TAMAMLANDI
                    </div>
                )}
            </div>
        </div>
    )
}

const StatCard = ({ label, value, icon: Icon, color }) => (
    <div style={{
        background: 'white',
        padding: '1.25rem',
        borderRadius: 'var(--radius-md)',
        border: '1px solid var(--color-bg-tertiary)',
        boxShadow: 'var(--shadow-sm)'
    }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--color-text-secondary)', fontSize: '0.7rem', fontWeight: '700', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
            <div style={{ padding: '4px', borderRadius: '4px', background: `${color}20` }}>
                <Icon size={12} color={color} />
            </div>
            {label}
        </div>
        <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--color-text-primary)' }}>{value}</div>
    </div>
)
