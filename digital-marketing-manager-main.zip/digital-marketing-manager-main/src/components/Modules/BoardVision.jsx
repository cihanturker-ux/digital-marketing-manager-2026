import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Target, TrendingUp, Shield, Award, Briefcase, CheckCircle, Circle } from 'lucide-react'

const VisionItem = ({ title, status, type }) => (
    <div className="glass-card" style={{
        padding: '1rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '1rem',
        borderLeft: status === 'REQUIRED' ? '4px solid var(--color-accent)' : '4px solid transparent'
    }}>
        <div style={{
            width: '32px', height: '32px', borderRadius: '50%',
            background: status === 'COMPLETED' ? 'var(--color-success)' : 'var(--color-bg-tertiary)',
            color: status === 'COMPLETED' ? 'white' : 'var(--color-text-secondary)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
            {status === 'COMPLETED' ? <CheckCircle size={18} /> : <Circle size={18} />}
        </div>
        <div style={{ flex: 1 }}>
            <div style={{ fontWeight: '600', fontSize: '0.95rem' }}>{title}</div>
            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>
                {type === 'CULTURE' ? 'Şirket Kültürü' : 'Hedef'} • {status === 'REQUIRED' ? 'Zorunlu' : 'Tercihen'}
            </div>
        </div>
        <div style={{
            padding: '0.25rem 0.75rem', borderRadius: '1rem', fontSize: '0.75rem', fontWeight: '600',
            background: status === 'COMPLETED' ? 'rgba(16, 185, 129, 0.1)' : 'rgba(0,0,0,0.05)',
            color: status === 'COMPLETED' ? 'var(--color-success)' : 'var(--color-text-secondary)'
        }}>
            {status === 'COMPLETED' ? 'TAMAMLANDI' : status === 'REQUIRED' ? 'GEREKLİ' : status === 'PLANNED' ? 'PLANLANDI' : 'VİZYON'}
        </div>
    </div>
)

const PlanYear = ({ year, objectives }) => (
    <div style={{ marginBottom: '2rem' }}>
        <h3 style={{ fontSize: '1rem', color: 'var(--color-text-secondary)', marginBottom: '1rem', borderBottom: '1px solid rgba(0,0,0,0.1)', paddingBottom: '0.5rem' }}>
            {year}
        </h3>
        <div>
            {objectives.map((obj, i) => (
                <VisionItem key={i} {...obj} />
            ))}
        </div>
    </div>
)

export const BoardVision = () => {
    const company = useGameStore(state => state.company)
    const difficulty = useGameStore(state => state.difficulty)

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Board Vizyonu</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Stratejik hedefler ve şirket kültürü beklentileri.</p>
                </div>
                <div className="glass-card" style={{ padding: '0.75rem 1.5rem', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Kurul Güveni</div>
                    <div style={{ fontSize: '1.2rem', fontWeight: '700', color: 'var(--color-success)' }}>B+</div>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem', flex: 1 }}>

                {/* Left Column: The Plan */}
                <div style={{ overflowY: 'auto', paddingRight: '0.5rem' }}>
                    <PlanYear
                        year="Mevcut Sezon (2025)"
                        objectives={[
                            { title: "$1M Yıllık Gelire Ulaş", status: "REQUIRED", type: "OBJECTIVE" },
                            { title: "Sosyal Medya Takipçilerini %20 Artır", status: "ONGOING", type: "OBJECTIVE" },
                            { title: "Yüksek Personel Moralini Koru", status: "ONGOING", type: "CULTURE" }
                        ]}
                    />
                    <PlanYear
                        year="Gelecek Sezon (2026)"
                        objectives={[
                            { title: "Asya Pazarına Açıl", status: "PLANNED", type: "OBJECTIVE" },
                            { title: "İç Otomasyon Araçları Geliştir", status: "PLANNED", type: "CULTURE" }
                        ]}
                    />
                    <PlanYear
                        year="Uzun Vadeli (2027-2029)"
                        objectives={[
                            { title: "Teknoloji Sektöründe Pazar Lideri Ol", status: "VISION", type: "OBJECTIVE" },
                            { title: "Halka Arz (IPO)", status: "VISION", type: "OBJECTIVE" }
                        ]}
                    />
                </div>

                {/* Right Column: Culture & Expectations */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    <div className="glass-card" style={{ padding: '1.5rem' }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Shield size={18} /> Şirket Kültürü
                        </h3>
                        <p style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)', lineHeight: '1.5', marginBottom: '1.5rem' }}>
                            Yönetim kurulu, ajansı yönetirken aşağıdaki kültürel ilkelere uymanızı bekler.
                        </p>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                            <div style={{ display: 'flex', gap: '0.75rem', fontSize: '0.9rem' }}>
                                <TrendingUp size={18} color="var(--color-accent)" />
                                <span>"Saldırgan" Pazarlama Oyna (Yüksek Harcama/Yüksek Ödül)</span>
                            </div>
                            <div style={{ display: 'flex', gap: '0.75rem', fontSize: '0.9rem' }}>
                                <Briefcase size={18} color="var(--color-accent)" />
                                <span>Genelciler yerine Uzmanları İşe Al</span>
                            </div>
                            <div style={{ display: 'flex', gap: '0.75rem', fontSize: '0.9rem' }}>
                                <Award size={18} color="var(--color-accent)" />
                                <span>Genç Yetenekleri Geliştir</span>
                            </div>
                        </div>
                    </div>

                    <div className="glass-card" style={{ padding: '1.5rem', flex: 1, background: 'linear-gradient(to bottom right, var(--color-bg-secondary), var(--color-bg-primary))' }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Target size={18} /> Performans İncelemesi
                        </h3>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                                    <span>Pazarlama Performansı</span>
                                    <span style={{ fontWeight: '600', color: 'var(--color-success)' }}>A-</span>
                                </div>
                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                    <div style={{ width: '90%', height: '100%', background: 'var(--color-success)', borderRadius: '3px' }}></div>
                                </div>
                            </div>
                            <div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                                    <span>Finansal Yönetim</span>
                                    <span style={{ fontWeight: '600', color: 'var(--color-warning)' }}>C+</span>
                                </div>
                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                    <div style={{ width: '65%', height: '100%', background: 'var(--color-warning)', borderRadius: '3px' }}></div>
                                </div>
                            </div>
                            <div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                                    <span>Personel Uyumu</span>
                                    <span style={{ fontWeight: '600', color: 'var(--color-accent)' }}>B</span>
                                </div>
                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                    <div style={{ width: '80%', height: '100%', background: 'var(--color-accent)', borderRadius: '3px' }}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}
