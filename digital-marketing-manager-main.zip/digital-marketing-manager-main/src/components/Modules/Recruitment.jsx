import React, { useState } from 'react'
import { Search, UserPlus, Star, Briefcase, Filter, Smile, Zap, Clock } from 'lucide-react'
import { useGameStore } from '../../store/gameStore'

const CandidateCard = ({ candidate, onHire }) => (
    <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <div style={{
                width: '50px', height: '50px', borderRadius: '50%',
                background: 'var(--color-bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '1.2rem', fontWeight: '700', color: 'var(--color-text-secondary)'
            }}>
                {candidate.name.charAt(0)}
            </div>
            <div>
                <h4 style={{ fontSize: '1.1rem', fontWeight: '600' }}>{candidate.name}</h4>
                <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>{candidate.role}</div>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.25rem' }}>
                    {candidate.traits.map(t => (
                        <span key={t} style={{ fontSize: '0.7rem', padding: '0.1rem 0.4rem', background: '#f3f4f6', borderRadius: '4px', color: '#666' }}>
                            {t}
                        </span>
                    ))}
                </div>
            </div>
        </div>

        <div style={{ display: 'flex', gap: '2rem', alignItems: 'center' }}>
            <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Yaratıcılık</div>
                <div style={{ fontWeight: '600', color: candidate.attributes.creativity > 15 ? 'var(--color-success)' : 'inherit' }}>
                    {candidate.attributes.creativity}
                </div>
            </div>
            <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Teknik</div>
                <div style={{ fontWeight: '600', color: candidate.attributes.technical > 15 ? 'var(--color-success)' : 'inherit' }}>
                    {candidate.attributes.technical}
                </div>
            </div>
            <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Maaş Beklentisi</div>
                <div style={{ fontWeight: '600' }}>${candidate.salary.toLocaleString()}/yıl</div>
            </div>

            <button
                onClick={() => onHire(candidate)}
                style={{
                    padding: '0.5rem 1rem', background: 'var(--color-accent)', color: 'white',
                    border: 'none', borderRadius: 'var(--radius-md)', cursor: 'pointer', fontWeight: '600',
                    display: 'flex', alignItems: 'center', gap: '0.5rem'
                }}
            >
                <UserPlus size={16} /> İşe Al
            </button>
        </div>
    </div>
)

export const Recruitment = () => {
    // Simulated candidates with Traits
    const [candidates, setCandidates] = useState([
        {
            id: 1, name: "Selin Yılmaz", role: "İçerik Uzmanı", salary: 45000,
            attributes: { creativity: 16, technical: 8, management: 10 },
            traits: ["Yaratıcı", "Disiplinli"]
        },
        {
            id: 2, name: "Mert Demir", role: "SEO Uzmanı", salary: 52000,
            attributes: { creativity: 9, technical: 17, management: 7 },
            traits: ["Analitik", "Detaycı"]
        },
        {
            id: 3, name: "Ayşe Kaya", role: "Pazarlama Direktörü", salary: 85000,
            attributes: { creativity: 14, technical: 14, management: 18 },
            traits: ["Lider", "Stratejik"]
        },
        {
            id: 4, name: "Can Öztürk", role: "PPC Yöneticisi", salary: 55000,
            attributes: { creativity: 11, technical: 16, management: 12 },
            traits: ["Hırslı", "Veri Odaklı"]
        },
    ])

    const handleHire = (candidate) => {
        // Here we would integrate with the store's "hireStaff" action
        alert(`${candidate.name} için teklif gönderildi!`)
    }

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>İşe Alım Merkezi</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Ajansınız için en iyi yetenekleri keşfedin.</p>
                </div>
                <div style={{ display: 'flex', gap: '1rem' }}>
                    <button className="glass-card" style={{ padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                        <Filter size={18} /> Filtrele
                    </button>
                    <div className="glass-card" style={{ padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Search size={18} />
                        <input type="text" placeholder="Aday ara..." style={{ border: 'none', background: 'transparent', outline: 'none' }} />
                    </div>
                </div>
            </div>

            <div style={{ display: 'grid', gap: '1rem', overflowY: 'auto' }}>
                {candidates.map(c => (
                    <CandidateCard key={c.id} candidate={c} onHire={handleHire} />
                ))}
            </div>
        </div>
    )
}
