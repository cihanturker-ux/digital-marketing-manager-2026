import React from 'react'
import { Smile, Frown, Meh, Users, ThumbsUp, Activity, Layers } from 'lucide-react'
import { useGameStore } from '../../store/gameStore'

const HierarchyLevel = ({ title, staff, color }) => (
    <div style={{ marginBottom: '1.5rem', textAlign: 'center' }}>
        <h4 style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '1px' }}>{title}</h4>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            {staff.map((member, i) => (
                <div key={i} className="glass-card" style={{
                    padding: '0.75rem 1.5rem', background: color, color: 'white',
                    display: 'flex', alignItems: 'center', gap: '0.5rem',
                    boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                }}>
                    <div style={{ fontWeight: '600' }}>{member}</div>
                </div>
            ))}
        </div>
    </div>
)

const CohesionCard = ({ label, value, description, icon: Icon, color }) => (
    <div className="glass-card" style={{ padding: '1.5rem', flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
            <div style={{ padding: '0.5rem', borderRadius: '8px', background: 'var(--color-bg-tertiary)' }}>
                <Icon size={20} color={color} />
            </div>
            <h3 style={{ fontSize: '1rem', fontWeight: '600' }}>{label}</h3>
        </div>
        <div style={{ marginBottom: '0.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem', fontSize: '0.9rem', fontWeight: '700' }}>
                <span style={{ color: color }}>{value}</span>
            </div>
            <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px' }}>
                <div style={{ width: '100%', height: '100%', background: `linear-gradient(90deg, transparent 0%, ${color} ${value === 'Mükemmel' ? '100%' : value === 'İyi' ? '75%' : '40%'})`, borderRadius: '4px' }}></div>
            </div>
        </div>
        <p style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', lineHeight: '1.4' }}>
            {description}
        </p>
    </div>
)



export const Dynamics = () => {
    const dynamics = useGameStore(state => state.dynamics)
    const staff = useGameStore(state => state.staff) || []

    if (!dynamics) return <div>Yükleniyor...</div>

    const getStatus = (val) => {
        if (val >= 80) return "Mükemmel";
        if (val >= 60) return "İyi";
        return "Geliştirilmeli";
    }

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Takım Dinamikleri</h2>
                <p style={{ color: 'var(--color-text-secondary)' }}>Takım uyumunu, atmosferi ve hiyerarşiyi izleyin.</p>
            </div>

            {/* Overview Row */}
            <div style={{ display: 'flex', gap: '1.5rem' }}>
                <CohesionCard
                    label="Proje Sinerjisi"
                    value={getStatus(dynamics.cohesion)}
                    description="Takım projelerde birlikte çalışma konusunda giderek uzmanlaşıyor."
                    icon={Activity}
                    color="var(--color-success)"
                />
                <CohesionCard
                    label="Ofis Atmosferi"
                    value={getStatus(dynamics.atmosphere)}
                    description="Genel moral ve çalışma ortamı verimliliği etkiliyor."
                    icon={Smile}
                    color="var(--color-accent)"
                />
                <CohesionCard
                    label="Yönetici Desteği"
                    value={getStatus(dynamics.leadershipSupport)}
                    description="Ekibin yönetime olan güveni ve bağlılığı."
                    icon={ThumbsUp}
                    color="var(--color-warning)"
                />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem', flex: 1 }}>

                {/* Hierarchy Pyramid */}
                <div className="glass-card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(to bottom, rgba(255,255,255,0.8), rgba(255,255,255,0.4))' }}>
                    <h3 style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Layers size={20} /> Hiyerarşi
                    </h3>

                    <div style={{ width: '100%', maxWidth: '600px' }}>
                        <HierarchyLevel
                            title="Liderler"
                            staff={staff.slice(0, 1).map(s => s.name)}
                            color="var(--color-accent)"
                        />
                        <HierarchyLevel
                            title="Kıdemli Üyeler"
                            staff={staff.slice(1, 3).map(s => s.name)}
                            color="#8b5cf6"
                        />
                        <HierarchyLevel
                            title="Operasyonel Ekip"
                            staff={staff.slice(3).map(s => s.name)}
                            color="#10b981"
                        />
                    </div>
                </div>

                {/* Social Groups */}
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Users size={20} /> Sosyal Gruplar
                    </h3>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        <div style={{ padding: '1rem', background: 'rgba(59, 130, 246, 0.1)', borderRadius: 'var(--radius-md)', border: '1px solid rgba(59, 130, 246, 0.2)' }}>
                            <div style={{ fontWeight: '600', marginBottom: '0.25rem', color: 'var(--color-accent)' }}>Çekirdek Grup</div>
                            <p style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.75rem' }}>
                                Kültürü belirleyen uzun süreli çalışanlar.
                            </p>
                            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                                {staff.slice(0, 2).map(s => (
                                    <span key={s.id} style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', background: 'white', borderRadius: '4px' }}>{s.name}</span>
                                ))}
                            </div>
                        </div>

                        <div style={{ padding: '1rem', background: 'rgba(16, 185, 129, 0.1)', borderRadius: 'var(--radius-md)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                            <div style={{ fontWeight: '600', marginBottom: '0.25rem', color: '#059669' }}>Yaratıcı Birim</div>
                            <p style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.75rem' }}>
                                İnovasyon ve tasarıma odaklı.
                            </p>
                            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                                {staff.slice(2).map(s => (
                                    <span key={s.id} style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', background: 'white', borderRadius: '4px' }}>{s.name}</span>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}
