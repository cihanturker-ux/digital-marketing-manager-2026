import React from 'react'
import { Mail, Star, Trash2, AlertCircle } from 'lucide-react'
import { useGameStore } from '../../store/gameStore'

const EmailItem = ({ sender, subject, date, isRead, type }) => (
    <div className="glass-card" style={{
        padding: '1rem',
        marginBottom: '0.75rem',
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
        borderLeft: !isRead ? '4px solid var(--color-accent)' : '4px solid transparent',
        cursor: 'pointer',
        opacity: isRead ? 0.7 : 1
    }}>
        <div style={{
            width: '40px', height: '40px', borderRadius: '50%',
            background: type === 'URGENT' ? '#fee2e2' : 'var(--color-bg-tertiary)',
            color: type === 'URGENT' ? '#ef4444' : 'var(--color-text-secondary)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
            {type === 'URGENT' ? <AlertCircle size={20} /> : <Mail size={20} />}
        </div>
        <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                <span style={{ fontWeight: '600' }}>{sender}</span>
                <span style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>{date}</span>
            </div>
            <div style={{ fontSize: '0.9rem', fontWeight: !isRead ? '600' : '400' }}>{subject}</div>
        </div>
    </div>
)

export const Inbox = () => {
    const company = useGameStore(state => state.company)

    const inbox = useGameStore(state => state.inbox)
    const markMessageRead = useGameStore(state => state.markMessageRead)

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Gelen Kutusu</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>{inbox.filter(e => !e.read).length} okunmamış mesaj</p>
                </div>
            </div>

            <div style={{ flex: 1, overflowY: 'auto' }}>
                {inbox.length === 0 ? (
                    <div style={{ textAlign: 'center', marginTop: '3rem', color: 'var(--color-text-secondary)' }}>Mesaj yok.</div>
                ) : (
                    inbox.map(email => (
                        <div key={email.id} onClick={() => markMessageRead(email.id)}>
                            <EmailItem
                                sender={email.sender}
                                subject={email.subject}
                                date={new Date(email.date).toLocaleDateString()}
                                isRead={email.read}
                                type={email.type}
                            />
                        </div>
                    ))
                )}
            </div>
        </div>
    )
}
