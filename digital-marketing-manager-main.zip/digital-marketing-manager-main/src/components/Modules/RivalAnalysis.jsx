import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Target, TrendingUp, TrendingDown, Eye, Zap, Award, DollarSign, Users, BarChart2 } from 'lucide-react'

const RivalCard = ({ rival, isExpanded, onToggle }) => {
    const performanceDiff = rival.performance - 50 // Compare to baseline 50

    return (
        <div
            className="glass-card"
            style={{
                padding: '1.5rem',
                cursor: 'pointer',
                border: isExpanded ? '2px solid var(--color-accent)' : 'none',
                transition: 'all 0.3s ease'
            }}
            onClick={onToggle}
        >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                    <div style={{
                        width: '60px',
                        height: '60px',
                        borderRadius: '12px',
                        background: `linear-gradient(135deg, ${rival.color}40, ${rival.color}20)`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1.5rem'
                    }}>
                        {rival.icon}
                    </div>
                    <div>
                        <h3 style={{ fontSize: '1.2rem', fontWeight: '700', marginBottom: '0.25rem' }}>{rival.name}</h3>
                        <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{rival.industry}</div>
                    </div>
                </div>

                <div style={{
                    padding: '0.5rem 1rem',
                    borderRadius: '2rem',
                    background: rival.threat === 'Yüksek' ? 'rgba(239, 68, 68, 0.1)' :
                        rival.threat === 'Orta' ? 'rgba(251, 191, 36, 0.1)' : 'rgba(16, 185, 129, 0.1)',
                    color: rival.threat === 'Yüksek' ? '#ef4444' :
                        rival.threat === 'Orta' ? '#fbbf24' : 'var(--color-success)',
                    fontWeight: '700',
                    fontSize: '0.85rem'
                }}>
                    {rival.threat} Tehdit
                </div>
            </div>

            {/* Quick Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '1rem' }}>
                <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Pazar Payı</div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700' }}>%{rival.marketShare}</div>
                </div>
                <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Bütçe</div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700' }}>${(rival.budget / 1000).toFixed(0)}K</div>
                </div>
                <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Performans</div>
                    <div style={{
                        fontSize: '1.1rem',
                        fontWeight: '700',
                        color: performanceDiff > 0 ? '#ef4444' : 'var(--color-success)'
                    }}>
                        {performanceDiff > 0 ? '+' : ''}{performanceDiff}
                    </div>
                </div>
                <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Trend</div>
                    <div>
                        {rival.trend === 'up' && <TrendingUp size={20} color="#ef4444" />}
                        {rival.trend === 'down' && <TrendingDown size={20} color="var(--color-success)" />}
                        {rival.trend === 'stable' && <div style={{ fontSize: '1.1rem', fontWeight: '700' }}>—</div>}
                    </div>
                </div>
            </div>

            {/* Expanded Details */}
            {isExpanded && (
                <div style={{
                    marginTop: '1.5rem',
                    paddingTop: '1.5rem',
                    borderTop: '1px solid var(--color-bg-tertiary)',
                    animation: 'fadeIn 0.3s ease'
                }}>
                    <h4 style={{ fontWeight: '700', marginBottom: '1rem' }}>İstihbarat Raporu</h4>

                    {/* Strengths */}
                    <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Zap size={16} color="var(--color-warning)" />
                            Güçlü Yönler
                        </div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                            {rival.strengths.map((strength, idx) => (
                                <span key={idx} style={{
                                    padding: '0.25rem 0.75rem',
                                    background: 'rgba(251, 191, 36, 0.1)',
                                    borderRadius: '1rem',
                                    fontSize: '0.85rem',
                                    color: 'var(--color-warning)'
                                }}>
                                    {strength}
                                </span>
                            ))}
                        </div>
                    </div>

                    {/* Weaknesses */}
                    <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Target size={16} color="var(--color-success)" />
                            Zayıflıklar (Fırsatlar)
                        </div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                            {rival.weaknesses.map((weakness, idx) => (
                                <span key={idx} style={{
                                    padding: '0.25rem 0.75rem',
                                    background: 'rgba(16, 185, 129, 0.1)',
                                    borderRadius: '1rem',
                                    fontSize: '0.85rem',
                                    color: 'var(--color-success)'
                                }}>
                                    {weakness}
                                </span>
                            ))}
                        </div>
                    </div>

                    {/* Recent Activity */}
                    <div>
                        <div style={{ fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Eye size={16} color="var(--color-accent)" />
                            Son Faaliyetler
                        </div>
                        <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)', lineHeight: '1.6' }}>
                            {rival.recentActivity}
                        </div>
                    </div>

                    {/* Strategic Recommendation */}
                    <div style={{
                        marginTop: '1.5rem',
                        padding: '1rem',
                        background: 'rgba(59, 130, 246, 0.05)',
                        borderRadius: 'var(--radius-md)',
                        borderLeft: '4px solid var(--color-accent)'
                    }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: '700', marginBottom: '0.5rem', color: 'var(--color-accent)' }}>
                            ⚡ Stratejik Öneri
                        </div>
                        <div style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>
                            {rival.recommendation}
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

export const RivalAnalysis = () => {
    const company = useGameStore(state => state.company)
    const campaigns = useGameStore(state => state.campaigns)
    const level = useGameStore(state => state.level)
    const [expandedRival, setExpandedRival] = useState(null)

    // Generate rival companies based on player's industry and level
    const rivals = [
        {
            name: "GrowthHackers Inc",
            industry: "SaaS Pazarlama",
            icon: "🚀",
            color: "#ef4444",
            threat: "Yüksek",
            marketShare: 32,
            budget: 120000,
            performance: 72,
            trend: "up",
            strengths: ["Güçlü SEO", "Viral İçerik", "Geniş Takipçi Kitlesi"],
            weaknesses: ["Yüksek Müşteri Edinme Maliyeti", "Düşük Tutundurma", "Sınırlı Kişiselleştirme"],
            recentActivity: "Küçük işletmeleri hedefleyen 3 büyük kampanya başlattı. TikTok reklamlarına yoğun yatırım yapıyor.",
            recommendation: "Farklılaşmak için müşteri tutundurma ve yaşam boyu değere odaklanın. Yüksek maliyetleri sürdürülemez."
        },
        {
            name: "DataDriven Marketing",
            industry: "Analitik & İçgörü",
            icon: "📊",
            color: "#3b82f6",
            threat: "Orta",
            marketShare: 24,
            budget: 95000,
            performance: 58,
            trend: "stable",
            strengths: ["Gelişmiş Analitik", "Teknoloji Yığını", "Endüstri İtibarı"],
            weaknesses: ["İnovasyonda Yavaş", "Zayıf Sosyal Medya Varlığı", "Yüksek Fiyatlandırma"],
            recentActivity: "Yapay zeka destekli analitik araçlarına yatırım yapıldı. Yakın zamanda 2 kıdemli veri bilimcisi işe alındı.",
            recommendation: "Çeviklik ve modern sosyal pazarlama ile rekabet edin. Yeni platformlara uyum sağlamakta yavaşlar."
        },
        {
            name: "CreativeMinds Studio",
            industry: "İçerik & Kreatif",
            icon: "🎨",
            color: "#8b5cf6",
            threat: "Düşük",
            marketShare: 18,
            budget: 75000,
            performance: 45,
            trend: "down",
            strengths: ["Ödüllü Kreatifler", "Marka Ortaklıkları", "Video Prodüksiyonu"],
            weaknesses: ["Zayıf Veri Stratejisi", "Yüksek Maliyetler", "Sınırlı Ölçek"],
            recentActivity: "Geçen çeyrek büyük bir müşteriyi kaybettiler. Fiyatlandırma modellerini yeniden yapılandırıyorlar.",
            recommendation: "Savunmasız durumdalar. Yaratıcı + veri odaklı bir yaklaşımla müşterilerini kazanma fırsatı var."
        },
        {
            name: "AutomateIt Marketing",
            industry: "Pazarlama Otomasyonu",
            icon: "⚙️",
            color: "#10b981",
            threat: "Orta",
            marketShare: 21,
            budget: 88000,
            performance: 65,
            trend: "up",
            strengths: ["Otomasyon Araçları", "Verimlilik", "Ölçeklenebilirlik"],
            weaknesses: ["İnsani Dokunuş Eksikliği", "Jenerik Mesajlaşma", "Düşük Etkileşim"],
            recentActivity: "Yeni yapay zeka otomasyon özellikleri geliştiriyorlar. Avrupa pazarlarına açılıyorlar.",
            recommendation: "Rekabet avantajınız olarak kişiselleştirmeyi ve otantik etkileşimi vurgulayın."
        }
    ]

    // Calculate player's market position
    const playerMarketShare = Math.max(5, Math.min(30, level * 2 + campaigns.length))
    const totalMarketShare = rivals.reduce((sum, r) => sum + r.marketShare, 0) + playerMarketShare
    const marketCoverage = ((playerMarketShare / totalMarketShare) * 100).toFixed(1)

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Target size={28} />
                        Rekabet İstihbaratı
                    </h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>
                        Rakip faaliyetlerini izleyin ve stratejik fırsatları belirleyin.
                    </p>
                </div>
                <div className="glass-card" style={{ padding: '1rem 1.5rem' }}>
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>
                        Pazar Konumunuz
                    </div>
                    <div style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--color-accent)' }}>
                        #{rivals.filter(r => r.marketShare > playerMarketShare).length + 1}
                    </div>
                </div>
            </div>

            {/* Market Overview */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem' }}>
                <div className="glass-card" style={{ padding: '1.5rem', textAlign: 'center' }}>
                    <BarChart2 size={24} color="var(--color-accent)" style={{ marginBottom: '0.5rem' }} />
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>Pazar Payı</div>
                    <div style={{ fontSize: '1.8rem', fontWeight: '700' }}>%{playerMarketShare}</div>
                </div>
                <div className="glass-card" style={{ padding: '1.5rem', textAlign: 'center' }}>
                    <Users size={24} color="var(--color-success)" style={{ marginBottom: '0.5rem' }} />
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>Pazar Kapsamı</div>
                    <div style={{ fontSize: '1.8rem', fontWeight: '700' }}>%{marketCoverage}</div>
                </div>
                <div className="glass-card" style={{ padding: '1.5rem', textAlign: 'center' }}>
                    <Target size={24} color="var(--color-warning)" style={{ marginBottom: '0.5rem' }} />
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>Büyük Rakipler</div>
                    <div style={{ fontSize: '1.8rem', fontWeight: '700' }}>{rivals.length}</div>
                </div>
                <div className="glass-card" style={{ padding: '1.5rem', textAlign: 'center' }}>
                    <Award size={24} color="#ef4444" style={{ marginBottom: '0.5rem' }} />
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>Tehdit Seviyesi</div>
                    <div style={{ fontSize: '1.8rem', fontWeight: '700', color: '#ef4444' }}>
                        {rivals.filter(r => r.threat === 'Yüksek').length}
                    </div>
                </div>
            </div>

            {/* Rivals List */}
            <div style={{ flex: 1, overflowY: 'auto' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '1rem' }}>Rakip Analizi</h3>
                <div style={{ display: 'grid', gap: '1rem' }}>
                    {rivals.map((rival, idx) => (
                        <RivalCard
                            key={idx}
                            rival={rival}
                            isExpanded={expandedRival === idx}
                            onToggle={() => setExpandedRival(expandedRival === idx ? null : idx)}
                        />
                    ))}
                </div>
            </div>
        </div>
    )
}
