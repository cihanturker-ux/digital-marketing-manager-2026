import React, { useState } from 'react'
import { TrendingUp, BookOpen, Zap, Users, ArrowUpCircle } from 'lucide-react'

const StaffTrainingCard = ({ staff, onUpdateFocus }) => (
    <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <div style={{
                    width: '48px', height: '48px', borderRadius: '50%',
                    background: 'var(--color-bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontWeight: '700', color: 'var(--color-text-secondary)'
                }}>
                    {staff.name.charAt(0)}
                </div>
                <div>
                    <h4 style={{ fontSize: '1.1rem', fontWeight: '600' }}>{staff.name}</h4>
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{staff.role}</div>
                </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.9rem', color: 'var(--color-success)' }}>
                <ArrowUpCircle size={16} />
                <span>Gelişiyor</span>
            </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            <div>
                <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>Eğitim Odağı</label>
                <select
                    style={{ width: '100%', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid rgba(0,0,0,0.1)', background: 'rgba(255,255,255,0.5)' }}
                    defaultValue={staff.focus}
                >
                    <option>Genel Pazarlama</option>
                    <option>Teknik SEO</option>
                    <option>Yaratıcı Yazarlık</option>
                    <option>Veri Analizi</option>
                    <option>Liderlik</option>
                </select>
            </div>
            <div>
                <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>Yoğunluk</label>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                    {['Hafif', 'Orta', 'Ağır'].map(level => (
                        <div
                            key={level}
                            style={{
                                flex: 1, padding: '0.5rem', textAlign: 'center', fontSize: '0.8rem',
                                borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                                background: staff.intensity === level ? 'var(--color-accent)' : 'var(--color-bg-tertiary)',
                                color: staff.intensity === level ? 'white' : 'inherit'
                            }}
                        >
                            {level}
                        </div>
                    ))}
                </div>
            </div>
        </div>

        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.25rem' }}>
                <span>Beceri İlerlemesi</span>
                <span>{staff.progress}%</span>
            </div>
            <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                <div style={{ width: `${staff.progress}%`, height: '100%', background: 'var(--color-success)', borderRadius: '3px' }}></div>
            </div>
        </div>
    </div>
)

export const StaffDevelopment = () => {
    const [staffList] = useState([
        { id: 1, name: "Selin Yılmaz", role: "Kıdemli Metin Yazarı", focus: "Yaratıcı Yazarlık", intensity: "Orta", progress: 75 },
        { id: 2, name: "Mert Demir", role: "PPC Uzmanı", focus: "Veri Analizi", intensity: "Ağır", progress: 45 },
        { id: 3, name: "Ayşe Kaya", role: "Grafik Tasarımcı", focus: "Genel Pazarlama", intensity: "Hafif", progress: 90 },
    ])

    return (
        <div style={{ height: '100%', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Personel Gelişimi</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Eğitim programlarını ve beceri ilerlemesini yönetin.</p>
                </div>

                <div style={{ display: 'grid', gap: '1rem' }}>
                    {staffList.map(staff => (
                        <StaffTrainingCard key={staff.id} staff={staff} />
                    ))}
                </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                {/* Mentoring Groups */}
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Users size={18} /> Mentor Grupları
                    </h3>
                    <div style={{ padding: '1rem', background: 'var(--color-bg-tertiary)', borderRadius: 'var(--radius-sm)', marginBottom: '1rem' }}>
                        <div style={{ fontWeight: '600', fontSize: '0.9rem', marginBottom: '0.5rem' }}>Yaratıcı Grup</div>
                        <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                            Mentor: <span style={{ color: 'var(--color-text-primary)' }}>Ayşe Kaya</span>
                        </div>
                        <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                            Öğrenci: Selin Yılmaz
                        </div>
                    </div>
                    <button style={{ width: '100%', padding: '0.75rem', border: '1px dashed var(--color-text-secondary)', background: 'transparent', borderRadius: 'var(--radius-sm)', color: 'var(--color-text-secondary)' }}>
                        + Yeni Grup Oluştur
                    </button>
                </div>

                {/* Overall Training Effectiveness */}
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Zap size={18} /> Eğitim Etkisi
                    </h3>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                        <div style={{ fontSize: '2rem', fontWeight: '700', color: 'var(--color-accent)' }}>A-</div>
                        <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                            Personel geri bildirimi ve gelişimine dayalı genel etkinlik derecesi.
                        </div>
                    </div>
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                        <span style={{ color: 'var(--color-success)' }}>+12%</span> Üretkenlik
                    </div>
                </div>
            </div>
        </div>
    )
}
