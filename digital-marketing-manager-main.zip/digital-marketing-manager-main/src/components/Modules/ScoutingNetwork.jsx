import React, { useState } from 'react'
import { Globe, Search, Map, Target, FileText, ArrowRight } from 'lucide-react'

const AssignmentCard = ({ region, focus, status, analyst }) => (
    <div className="glass-card" style={{ padding: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{
                width: '40px', height: '40px', borderRadius: '50%',
                background: 'var(--color-bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center'
            }}>
                <Globe size={20} color="var(--color-accent)" />
            </div>
            <div>
                <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>{region}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Odak: {focus}</div>
            </div>
        </div>
        <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Analist</div>
            <div style={{ fontSize: '0.85rem', fontWeight: '600' }}>{analyst}</div>
        </div>
        <div style={{
            padding: '0.25rem 0.75rem', borderRadius: '1rem', fontSize: '0.75rem', fontWeight: '600',
            background: status === 'Active' ? 'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)',
            color: status === 'Active' ? 'var(--color-success)' : 'var(--color-warning)'
        }}>
            {status === 'Active' ? 'Aktif' : 'Beklemede'}
        </div>
    </div>
)

const ReportCard = ({ title, type, rating, summary }) => (
    <div className="glass-card" style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div style={{
                padding: '0.25rem 0.5rem', borderRadius: '4px', fontSize: '0.7rem', fontWeight: '700', textTransform: 'uppercase',
                background: 'var(--color-bg-tertiary)', color: 'var(--color-text-secondary)'
            }}>
                {type}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontWeight: '700', color: 'var(--color-accent)' }}>
                {rating} <span style={{ fontSize: '0.7rem', fontWeight: '400', color: 'var(--color-text-secondary)' }}>/ 100</span>
            </div>
        </div>

        <h4 style={{ fontSize: '1rem', fontWeight: '600' }}>{title}</h4>
        <p style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', lineHeight: '1.4' }}>
            {summary}
        </p>

        <button style={{
            marginTop: 'auto', padding: '0.5rem', width: '100%',
            border: '1px solid rgba(0,0,0,0.1)', background: 'transparent', borderRadius: 'var(--radius-sm)',
            fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem'
        }}>
            Tam Analizi Görüntüle <ArrowRight size={14} />
        </button>
    </div>
)

export const ScoutingNetwork = () => {
    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>İzci Ağı</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Pazar istihbaratı ve rakip analizi.</p>
                </div>
                <div style={{ display: 'flex', gap: '1rem' }}>
                    <button className="glass-card" style={{ padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                        <Map size={18} /> Bilgi Haritası
                    </button>
                    <button className="glass-card" style={{ padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'var(--color-accent)', color: 'white', border: 'none' }}>
                        <Target size={18} /> Yeni Görev
                    </button>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem', flex: 1 }}>

                {/* Left Column: Assignments & Coverage */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    <div className="glass-card" style={{ padding: '1.5rem' }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Globe size={18} /> Aktif Görevler
                        </h3>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <AssignmentCard region="Kuzey Amerika" focus="SaaS Trendleri" status="Active" analyst="J. Pearson" />
                            <AssignmentCard region="Sosyal Medya" focus="TikTok Viral" status="Active" analyst="M. Ross" />
                            <AssignmentCard region="Rakipler" focus="Fiyatlandırma Stratejileri" status="Pending" analyst="L. Litt" />
                        </div>
                    </div>

                    <div className="glass-card" style={{ padding: '1.5rem', flex: 1 }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Pazar Bilgisi</h3>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                                    <span>B2B Teknoloji Sektörü</span>
                                    <span style={{ fontWeight: '600' }}>Yüksek</span>
                                </div>
                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                    <div style={{ width: '85%', height: '100%', background: 'var(--color-accent)', borderRadius: '3px' }}></div>
                                </div>
                            </div>
                            <div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                                    <span>E-ticaret</span>
                                    <span style={{ fontWeight: '600' }}>Orta</span>
                                </div>
                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                    <div style={{ width: '55%', height: '100%', background: 'var(--color-warning)', borderRadius: '3px' }}></div>
                                </div>
                            </div>
                            <div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                                    <span>Influencer Pazarı</span>
                                    <span style={{ fontWeight: '600' }}>Düşük</span>
                                </div>
                                <div style={{ height: '6px', background: 'var(--color-bg-tertiary)', borderRadius: '3px' }}>
                                    <div style={{ width: '25%', height: '100%', background: 'var(--color-text-secondary)', borderRadius: '3px' }}></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Column: Reports Feed */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h3 style={{ fontSize: '1.1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <FileText size={18} /> Son İstihbaratlar
                        </h3>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                            <Search size={14} />
                            <input type="text" placeholder="Raporları filtrele..." style={{ background: 'transparent', border: 'none', outline: 'none' }} />
                        </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', overflowY: 'auto' }}>
                        <ReportCard
                            type="Rakip"
                            title="Rakip Ajans Yeniden Markalama"
                            rating="88"
                            summary="'BlueSky Digital' yapay zeka odaklı hizmetlerle yeniden markalaştı. Bu, teknoloji sektöründeki benzersiz satış teklifimizi etkileyebilir."
                        />
                        <ReportCard
                            type="Trend"
                            title="Kısa Video Artışı"
                            rating="92"
                            summary="Reels ve Shorts etkileşimi B2B sektöründe bu çeyrek %40 arttı. Önerilen eylem: İçerik stratejisini değiştirin."
                        />
                        <ReportCard
                            type="Fırsat"
                            title="Hizmet Verilmeyen Niş: Yeşil Teknoloji"
                            rating="76"
                            summary="Analizler, 'Sürdürülebilir Pazarlama Hizmetleri' için yüksek arama hacmi ancak düşük rekabet gösteriyor. Yeni hizmet hattı potansiyeli."
                        />
                        <ReportCard
                            type="Teknoloji"
                            title="Yeni Otomasyon Aracı"
                            rating="65"
                            summary="Yeni CRM aracı 'AutoFlow' ilgi görüyor. Benimsenirse iç verimliliğimizi %15 artırabilir."
                        />
                    </div>
                </div>

            </div>
        </div>
    )
}
