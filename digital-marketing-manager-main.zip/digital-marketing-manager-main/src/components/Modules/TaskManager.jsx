import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { CheckCircle, XCircle, Clock, Target, AlertTriangle } from 'lucide-react'

const TaskCard = ({ task }) => {
    const date = useGameStore(state => state.date)
    const completeTask = useGameStore(state => state.completeTask)

    const deadline = new Date(task.deadline)
    const currentDate = date instanceof Date ? date : new Date(date)
    const daysLeft = Math.ceil((deadline - currentDate) / (1000 * 60 * 60 * 24))

    const getStatusColor = () => {
        if (task.status === 'COMPLETED') return 'var(--color-success)';
        if (task.status === 'FAILED') return '#ef4444';
        if (daysLeft <= 1) return '#ef4444';
        if (daysLeft <= 3) return 'var(--color-warning)';
        return 'var(--color-accent)';
    };

    const getStatusIcon = () => {
        if (task.status === 'COMPLETED') return <CheckCircle size={20} />;
        if (task.status === 'FAILED') return <XCircle size={20} />;
        if (daysLeft <= 1) return <AlertTriangle size={20} />;
        return <Clock size={20} />;
    };

    const getStatusText = () => {
        if (task.status === 'COMPLETED') return 'Tamamlandı';
        if (task.status === 'FAILED') return 'Başarısız';
        if (daysLeft < 0) return 'Süresi Doldu';
        return `${daysLeft} ${daysLeft === 1 ? 'gün' : 'gün'} kaldı`;
    };

    return (
        <div className="glass-card" style={{
            padding: '1.5rem',
            borderLeft: `4px solid ${getStatusColor()}`,
            opacity: task.status !== 'ACTIVE' ? 0.6 : 1
        }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                        <div style={{ color: getStatusColor() }}>
                            {getStatusIcon()}
                        </div>
                        <h4 style={{ fontSize: '1.1rem', fontWeight: '700' }}>{task.title}</h4>
                    </div>
                    <p style={{ fontSize: '0.9rem', color: 'var(--color-text-secondary)', marginBottom: '0.75rem' }}>
                        {task.description}
                    </p>
                    <div style={{
                        padding: '0.5rem 0.75rem',
                        background: 'var(--color-bg-tertiary)',
                        borderRadius: 'var(--radius-sm)',
                        fontSize: '0.85rem',
                        fontWeight: '600'
                    }}>
                        {task.requirement}
                    </div>
                </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', gap: '1.5rem' }}>
                    <div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Durum</div>
                        <div style={{ fontSize: '0.9rem', fontWeight: '600', color: getStatusColor() }}>{getStatusText()}</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Ödül</div>
                        <div style={{ fontSize: '0.9rem', fontWeight: '600', color: 'var(--color-success)' }}>+{task.trustReward} Güven</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Ceza</div>
                        <div style={{ fontSize: '0.9rem', fontWeight: '600', color: '#ef4444' }}>-{task.trustPenalty} Güven</div>
                    </div>
                </div>

                {task.status === 'ACTIVE' && (
                    <button
                        onClick={() => completeTask(task.id)}
                        style={{
                            padding: '0.5rem 1rem',
                            background: 'var(--color-success)',
                            color: 'white',
                            border: 'none',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '0.85rem',
                            fontWeight: '600',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem'
                        }}
                    >
                        <CheckCircle size={16} />
                        Tamamlandı İşaretle
                    </button>
                )}
            </div>
        </div>
    )
}

export const TaskManager = () => {
    const tasks = useGameStore(state => state.tasks)
    const boardTrust = useGameStore(state => state.boardTrust)

    const activeTasks = tasks.filter(t => t.status === 'ACTIVE')
    const completedTasks = tasks.filter(t => t.status === 'COMPLETED')
    const failedTasks = tasks.filter(t => t.status === 'FAILED')

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Yönetim Kurulu Görevleri</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Güveni korumak için görevleri tamamla</p>
                </div>
                <div className="glass-card" style={{ padding: '1rem 1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Aktif Görevler</div>
                        <div style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--color-accent)' }}>{activeTasks.length}</div>
                    </div>
                    <div style={{ width: '1px', height: '40px', background: 'rgba(0,0,0,0.1)' }}></div>
                    <div style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>Kurul Güveni</div>
                        <div style={{ fontSize: '1.5rem', fontWeight: '700', color: boardTrust >= 60 ? 'var(--color-success)' : '#ef4444' }}>{boardTrust}%</div>
                    </div>
                </div>
            </div>

            {/* Active Tasks */}
            {activeTasks.length > 0 && (
                <div>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Target size={20} />
                        Aktif Görevler
                    </h3>
                    <div style={{ display: 'grid', gap: '1rem' }}>
                        {activeTasks.map(task => (
                            <TaskCard key={task.id} task={task} />
                        ))}
                    </div>
                </div>
            )}

            {/* Empty State */}
            {activeTasks.length === 0 && (
                <div className="glass-card" style={{
                    padding: '3rem',
                    textAlign: 'center',
                    color: 'var(--color-text-secondary)'
                }}>
                    <Target size={48} style={{ opacity: 0.3, marginBottom: '1rem' }} />
                    <h3 style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>Aktif Görev Yok</h3>
                    <p>İlerledikçe yönetim kurulu yeni görevler atayacak. Yeni direktifler almak için zamanı ilerletin.</p>
                </div>
            )}

            {/* Completed & Failed Tasks */}
            {(completedTasks.length > 0 || failedTasks.length > 0) && (
                <div>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '1rem' }}>Görev Geçmişi</h3>
                    <div style={{ display: 'grid', gap: '1rem', maxHeight: '400px', overflowY: 'auto' }}>
                        {[...completedTasks, ...failedTasks].slice(-5).reverse().map(task => (
                            <TaskCard key={task.id} task={task} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    )
}
