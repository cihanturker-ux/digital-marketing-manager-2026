import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Building2, DollarSign, TrendingUp, CheckCircle, ArrowRight } from 'lucide-react'

export const Opportunities = () => {
    const contractOffers = useGameStore(state => state.contractOffers)
    const setCompany = useGameStore(state => state.setCompany)
    const setGamePhase = useGameStore(state => state.setGamePhase)
    const clearOffers = useGameStore(state => state.clearContractOffers)

    const handleAccept = (offer) => {
        setCompany(offer)
        setGamePhase('GAMEPLAY')
        clearOffers()
    }

    if (contractOffers.length === 0) {
        return (
            <div className="glass-card" style={{ padding: '2rem', textAlign: 'center' }}>
                <h3>Şu anda yeni fırsat yok.</h3>
            </div>
        )
    }

    return (
        <div className="glass-card" style={{ padding: '2rem' }}>
            <h2 style={{ marginBottom: '1rem' }}>Mevcut Sözleşmeler</h2>
            <div style={{ display: 'grid', gap: '1.5rem' }}>
                {contractOffers.map((offer, idx) => (
                    <div key={idx} style={{ border: '1px solid var(--color-bg-tertiary)', borderRadius: 'var(--radius-md)', padding: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                            <Building2 size={20} />
                            <strong>{offer.name}</strong> – {offer.industry}
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
                            <div>
                                <span style={{ color: 'var(--color-text-secondary)' }}>Bütçe</span>
                                <div style={{ fontWeight: '600' }}>${offer.budget.toLocaleString()}</div>
                            </div>
                            <div>
                                <span style={{ color: 'var(--color-text-secondary)' }}>Maaş</span>
                                <div style={{ fontWeight: '600' }}>${offer.salary.toLocaleString()}/ay</div>
                            </div>
                        </div>
                        <button
                            onClick={() => handleAccept(offer)}
                            style={{
                                marginTop: '0.5rem',
                                padding: '0.5rem 1rem',
                                background: 'var(--color-success)',
                                color: 'white',
                                border: 'none',
                                borderRadius: 'var(--radius-sm)',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.25rem'
                            }}
                        >
                            <ArrowRight size={14} /> Görevi Kabul Et
                        </button>
                    </div>
                ))}
            </div>
        </div>
    )
}
