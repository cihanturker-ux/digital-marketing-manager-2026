import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Heart, TrendingUp, TrendingDown, Coffee, Star, Briefcase, Users, Award } from 'lucide-react'

const MoraleBar = ({ label, value, color, icon: Icon }) => (
    <div className="glass-card" style={{ padding: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    background: `${color}20`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
                    <Icon size={20} color={color} />
                </div>
                <span style={{ fontWeight: '600' }}>{label}</span>
            </div>
            <span style={{ fontSize: '1.5rem', fontWeight: '700', color }}>{value}%</span>
        </div>
        <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px' }}>
            <div style={{
                width: `${value}%`,
                height: '100%',
                background: color,
                borderRadius: '4px',
                transition: 'width 0.5s ease'
            }}></div>
        </div>
        <div style={{ marginTop: '0.75rem', fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
            {value >= 80 && "Mükemmel - Takım çok motive"}
            {value >= 60 && value < 80 && "İyi - Takım morali stabil"}
            {value >= 40 && value < 60 && "Orta - Bazı endişeler var"}
            {value < 40 && "Düşük - Acil müdahale gerekli"}
        </div>
    </div>
)

const StaffMemberCard = ({ member }) => (
    <div className="glass-card" style={{
        padding: '1.5rem',
        display: 'flex',
        alignItems: 'center',
        gap: '1.5rem'
    }}>
        <div style={{
            width: '60px',
            height: '60px',
            borderRadius: '50%',
            background: `linear-gradient(135deg, ${member.color}40, ${member.color}20)`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '1.5rem'
        }}>
            {member.avatar}
        </div>
        <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <div>
                    <div style={{ fontWeight: '700', fontSize: '1.1rem' }}>{member.name}</div>
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{member.role}</div>
                </div>
                <div style={{
                    padding: '0.5rem 1rem',
                    borderRadius: '2rem',
                    background: member.happiness >= 75 ? 'rgba(16, 185, 129, 0.1)' : member.happiness >= 50 ? 'rgba(59, 130, 246, 0.1)' : 'rgba(239, 68, 68, 0.1)',
                    color: member.happiness >= 75 ? 'var(--color-success)' : member.happiness >= 50 ? 'var(--color-accent)' : '#ef4444',
                    fontWeight: '700',
                    fontSize: '0.9rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                }}>
                    <Heart size={16} fill={member.happiness >= 75 ? 'var(--color-success)' : 'none'} />
                    {member.happiness}%
                </div>
            </div>
            <div style={{ display: 'flex', gap: '1rem', fontSize: '0.85rem' }}>
                <div>
                    <span style={{ color: 'var(--color-text-secondary)' }}>Üretkenlik: </span>
                    <span style={{ fontWeight: '600' }}>{member.productivity}%</span>
                </div>
                <div>
                    <span style={{ color: 'var(--color-text-secondary)' }}>Deneyim: </span>
                    <span style={{ fontWeight: '600' }}>{member.experience} yıl</span>
                </div>
            </div>
        </div>
    </div>
)

const MoraleFactorCard = ({ icon: Icon, title, description, impact, isPositive }) => (
    <div style={{
        padding: '1rem 1.25rem',
        background: isPositive ? 'rgba(16, 185, 129, 0.05)' : 'rgba(239, 68, 68, 0.05)',
        border: `1px solid ${isPositive ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)'}`,
        borderRadius: 'var(--radius-md)',
        display: 'flex',
        alignItems: 'center',
        gap: '1rem'
    }}>
        <Icon size={20} color={isPositive ? 'var(--color-success)' : '#ef4444'} />
        <div style={{ flex: 1 }}>
            <div style={{ fontWeight: '600', marginBottom: '0.25rem' }}>{title}</div>
            <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{description}</div>
        </div>
        <div style={{
            fontWeight: '700',
            color: isPositive ? 'var(--color-success)' : '#ef4444'
        }}>
            {isPositive ? '+' : ''}{impact}%
        </div>
    </div>
)

export const StaffMorale = () => {
    const boardTrust = useGameStore(state => state.boardTrust)
    const company = useGameStore(state => state.company)
    const campaigns = useGameStore(state => state.campaigns)
    const level = useGameStore(state => state.level)

    const staff = useGameStore(state => state.staff) || []
    const dynamics = useGameStore(state => state.dynamics)
    const boostMorale = useGameStore(state => state.boostMorale)

    // Calculate overall team morale based on game state
    const calculateMorale = () => {
        if (!dynamics) return 60;
        return Math.round((dynamics.cohesion + dynamics.atmosphere + dynamics.leadershipSupport) / 3);
    }

    const calculateProductivity = () => {
        const morale = calculateMorale()
        // Productivity is influenced by morale
        return Math.min(100, Math.round(morale * 0.9 + 10))
    }

    const overallMorale = calculateMorale()
    const productivity = calculateProductivity()
    const workLifeBalance = 70 + (level * 2) // Improves with progression
    const jobSecurity = Math.round((company.budget / 1000) + (boardTrust * 0.5))

    const moraleFactors = [
        { icon: Star, title: "Son Zaferler", description: "Kampanya başarıları takım moralini artırdı", impact: 12, isPositive: true },
        { icon: Coffee, title: "Çalışma Ortamı", description: "Rahat ofis ve iyi kahve", impact: 8, isPositive: true },
        { icon: Briefcase, title: "Kariyer Gelişimi", description: "Net yükselme fırsatları", impact: 10, isPositive: true },
        ...(boardTrust < 50 ? [{ icon: TrendingDown, title: "İş Güvencesizliği", description: "Düşük yönetim güveni endişe yaratıyor", impact: -15, isPositive: false }] : []),
        ...(company.budget < 30000 ? [{ icon: TrendingDown, title: "Bütçe Endişeleri", description: "Düşük bütçe kaynakları etkiliyor", impact: -10, isPositive: false }] : [])
    ]

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header */}
            <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Users size={28} />
                    Personel Morali & Mutluluk
                </h2>
                <p style={{ color: 'var(--color-text-secondary)' }}>
                    Takım mutluluğu ve üretkenlik seviyelerini izleyin
                </p>
            </div>

            {/* Morale Metrics */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem' }}>
                <MoraleBar
                    label="Genel Moral"
                    value={overallMorale}
                    color={overallMorale >= 70 ? 'var(--color-success)' : overallMorale >= 50 ? 'var(--color-accent)' : '#ef4444'}
                    icon={Heart}
                />
                <MoraleBar
                    label="Üretkenlik"
                    value={productivity}
                    color="var(--color-accent)"
                    icon={TrendingUp}
                />
                <MoraleBar
                    label="İş-Yaşam Dengesi"
                    value={workLifeBalance}
                    color="var(--color-warning)"
                    icon={Coffee}
                />
            </div>

            {/* Main Content */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem', flex: 1 }}>
                {/* Team Members */}
                <div>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '1rem' }}>Takım Üyeleri</h3>
                    <div style={{ display: 'grid', gap: '1rem', overflowY: 'auto', maxHeight: '500px' }}>
                        {staff.map((member, idx) => (
                            <StaffMemberCard key={idx} member={{ ...member, color: '#3b82f6' }} />
                        ))}
                    </div>
                </div>

                {/* Morale Factors */}
                <div>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '1rem' }}>Moral Faktörleri</h3>
                    <div style={{ display: 'grid', gap: '1rem' }}>
                        {moraleFactors.map((factor, idx) => (
                            <MoraleFactorCard key={idx} {...factor} />
                        ))}
                    </div>

                    {/* Action card */}
                    <div className="glass-card" style={{ padding: '1.5rem', marginTop: '1.5rem' }}>
                        <h4 style={{ fontWeight: '700', marginBottom: '1rem' }}>Morali Yükselt</h4>
                        <button onClick={() => boostMorale(5)} style={{
                            width: '100%',
                            padding: '0.75rem',
                            background: 'var(--color-accent)',
                            color: 'white',
                            border: 'none',
                            borderRadius: 'var(--radius-md)',
                            fontWeight: '600',
                            cursor: 'pointer',
                            marginBottom: '0.5rem'
                        }}>
                            Takım Etkinliği ($500)
                        </button>
                        <button onClick={() => boostMorale(10)} style={{
                            width: '100%',
                            padding: '0.75rem',
                            background: 'var(--color-success)',
                            color: 'white',
                            border: 'none',
                            borderRadius: 'var(--radius-md)',
                            fontWeight: '600',
                            cursor: 'pointer'
                        }}>
                            Performans Bonusları ($1,000)
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}
