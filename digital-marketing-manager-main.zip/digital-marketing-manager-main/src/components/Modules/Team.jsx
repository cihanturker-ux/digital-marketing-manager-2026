import React from 'react'
import { User, TrendingUp, Award } from 'lucide-react'

const StaffCard = ({ name, role, rating, salary }) => (
    <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
        <div style={{
            width: '60px', height: '60px', borderRadius: '50%',
            background: 'var(--color-bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
            <User size={30} color="var(--color-text-secondary)" />
        </div>

        <div style={{ flex: 1 }}>
            <h4 style={{ fontSize: '1.1rem', marginBottom: '0.25rem' }}>{name}</h4>
            <div style={{ color: 'var(--color-text-secondary)', fontSize: '0.9rem' }}>{role}</div>
        </div>

        <div style={{ textAlign: 'right' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.25rem', justifyContent: 'flex-end' }}>
                <Award size={16} color="var(--color-warning)" />
                <span style={{ fontWeight: '700' }}>{rating}/20</span>
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>${salary.toLocaleString()}/y</div>
        </div>
    </div>
)

export const Team = () => {
    const staff = [
        { id: 1, name: "Selin Yılmaz", role: "Kıdemli Metin Yazarı", rating: 16, salary: 65000 },
        { id: 2, name: "Mert Demir", role: "PPC Uzmanı", rating: 14, salary: 58000 },
        { id: 3, name: "Ayşe Kaya", role: "Grafik Tasarımcı", rating: 18, salary: 72000 },
    ]

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700' }}>Ekibim</h2>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Departman personelinizi yönetin.</p>
                </div>
                <div className="glass-card" style={{ padding: '0.5rem 1rem', fontSize: '0.9rem' }}>
                    Toplam Maaş: <span style={{ fontWeight: '600' }}>$195,000/yıl</span>
                </div>
            </div>

            <div style={{ display: 'grid', gap: '1rem' }}>
                {staff.map(member => (
                    <StaffCard key={member.id} {...member} />
                ))}
            </div>
        </div>
    )
}
