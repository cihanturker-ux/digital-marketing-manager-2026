import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Building2, DollarSign, TrendingUp, CheckCircle } from 'lucide-react'

export const ContractOffer = () => {
    const setGamePhase = useGameStore(state => state.setGamePhase)
    const setCompany = useGameStore(state => state.setCompany)
    const manager = useGameStore(state => state.manager)

    // Mock Company Data
    const offer = {
        name: "TechFlow Solutions",
        industry: "SaaS",
        budget: 50000,
        expectations: "Increase organic traffic by 20% in Q1",
        salary: 4500
    }

    const handleSign = () => {
        setCompany(offer)
        setGamePhase('GAMEPLAY')
    }

    return (
        <div className="full-screen flex-center" style={{
            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
            padding: '2rem'
        }}>
            <div className="glass-card" style={{
                width: '100%',
                maxWidth: '600px',
                padding: '0',
                overflow: 'hidden',
                animation: 'slideUp 0.5s ease-out'
            }}>
                <div style={{
                    background: 'var(--color-text-primary)',
                    color: 'white',
                    padding: '2rem',
                    textAlign: 'center'
                }}>
                    <Building2 size={48} style={{ marginBottom: '1rem', opacity: 0.8 }} />
                    <h1 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>Job Offer Received</h1>
                    <p style={{ opacity: 0.8 }}>{offer.name} wants you as their Head of Growth.</p>
                </div>

                <div style={{ padding: '2.5rem' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', marginBottom: '2rem' }}>
                        <div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem', color: 'var(--color-text-secondary)' }}>
                                <DollarSign size={18} />
                                <span>Marketing Budget</span>
                            </div>
                            <div style={{ fontSize: '1.25rem', fontWeight: '600' }}>${offer.budget.toLocaleString()} / mo</div>
                        </div>
                        <div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem', color: 'var(--color-text-secondary)' }}>
                                <TrendingUp size={18} />
                                <span>Primary Goal</span>
                            </div>
                            <div style={{ fontSize: '1.1rem', fontWeight: '600' }}>{offer.expectations}</div>
                        </div>
                    </div>

                    <div style={{
                        background: 'var(--color-bg-tertiary)',
                        padding: '1.5rem',
                        borderRadius: 'var(--radius-md)',
                        marginBottom: '2rem'
                    }}>
                        <h4 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <CheckCircle size={18} color="var(--color-success)" />
                            Contract Terms
                        </h4>
                        <ul style={{ listStyle: 'none', padding: 0, opacity: 0.8 }}>
                            <li style={{ marginBottom: '0.5rem' }}>• Full control over Ad Spend & SEO Strategy</li>
                            <li style={{ marginBottom: '0.5rem' }}>• Monthly performance reviews with the Board</li>
                            <li>• Base Salary: ${offer.salary.toLocaleString()} / mo</li>
                        </ul>
                    </div>

                    <div style={{ display: 'flex', gap: '1rem' }}>
                        <button
                            style={{
                                flex: 1,
                                padding: '1rem',
                                background: 'transparent',
                                color: 'var(--color-text-secondary)',
                                border: '1px solid var(--color-text-secondary)',
                                borderRadius: 'var(--radius-md)',
                                fontSize: '1rem',
                                fontWeight: '600'
                            }}
                        >
                            Reject
                        </button>
                        <button
                            onClick={handleSign}
                            style={{
                                flex: 2,
                                padding: '1rem',
                                background: 'var(--color-success)',
                                color: 'white',
                                border: 'none',
                                borderRadius: 'var(--radius-md)',
                                fontSize: '1rem',
                                fontWeight: '600',
                                boxShadow: 'var(--shadow-md)'
                            }}
                        >
                            Sign Contract
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}
