import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { User, Briefcase, TrendingUp, Zap, Users } from 'lucide-react'

const AttributeSlider = ({ label, icon: Icon, value, onChange, remainingPoints }) => (
    <div style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', fontSize: '0.9rem', color: 'var(--color-text-secondary)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Icon size={16} />
                <span>{label}</span>
            </div>
            <span style={{ fontWeight: '600', color: 'var(--color-text-primary)' }}>{value}</span>
        </div>
        <input
            type="range"
            min="1"
            max="20"
            value={value}
            onChange={(e) => {
                const newValue = parseInt(e.target.value)
                const diff = newValue - value
                if (remainingPoints - diff >= 0) {
                    onChange(newValue)
                }
            }}
            style={{ width: '100%', accentColor: 'var(--color-accent)' }}
        />
    </div>
)

export const ManagerCreation = () => {
    const setManagerName = useGameStore(state => state.setManagerName)
    const setGamePhase = useGameStore(state => state.setGamePhase)

    const [name, setName] = useState('')
    const [attributes, setAttributes] = useState({
        strategy: 10,
        creativity: 10,
        technical: 10,
        leadership: 10
    })

    const totalPoints = 50
    const usedPoints = Object.values(attributes).reduce((a, b) => a + b, 0)
    const remainingPoints = totalPoints - usedPoints

    const handleAttributeChange = (key, value) => {
        setAttributes(prev => ({ ...prev, [key]: value }))
    }

    const handleStart = () => {
        if (name.trim() && remainingPoints === 0) {
            setManagerName(name)
            // In a real app, we'd save attributes too
            setGamePhase('CONTRACT')
        }
    }

    return (
        <div className="full-screen flex-center" style={{
            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
            padding: '2rem'
        }}>
            <div className="glass-card" style={{
                width: '100%',
                maxWidth: '500px',
                padding: '2.5rem',
                animation: 'fadeIn 0.5s ease-out'
            }}>
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <div style={{
                        width: '80px',
                        height: '80px',
                        background: 'var(--color-accent)',
                        borderRadius: '50%',
                        margin: '0 auto 1rem',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        boxShadow: 'var(--shadow-md)'
                    }}>
                        <User size={40} />
                    </div>
                    <h1 style={{ fontSize: '1.75rem', marginBottom: '0.5rem' }}>New Manager Profile</h1>
                    <p style={{ color: 'var(--color-text-secondary)' }}>Define your management style.</p>
                </div>

                <div style={{ marginBottom: '2rem' }}>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Full Name</label>
                    <input
                        type="text"
                        placeholder="e.g. Alex Ferguson"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        style={{
                            width: '100%',
                            padding: '0.75rem',
                            borderRadius: 'var(--radius-md)',
                            border: '1px solid #dee2e6',
                            fontSize: '1rem',
                            outline: 'none',
                            transition: 'border-color 0.2s'
                        }}
                    />
                </div>

                <div style={{ marginBottom: '2rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                        <span style={{ fontWeight: '600' }}>Attributes</span>
                        <span style={{
                            color: remainingPoints === 0 ? 'var(--color-success)' : 'var(--color-warning)',
                            fontWeight: 'bold'
                        }}>
                            Points Left: {remainingPoints}
                        </span>
                    </div>

                    <AttributeSlider
                        label="Strategic Planning"
                        icon={Briefcase}
                        value={attributes.strategy}
                        onChange={(v) => handleAttributeChange('strategy', v)}
                        remainingPoints={remainingPoints}
                    />
                    <AttributeSlider
                        label="Creative Vision"
                        icon={Zap}
                        value={attributes.creativity}
                        onChange={(v) => handleAttributeChange('creativity', v)}
                        remainingPoints={remainingPoints}
                    />
                    <AttributeSlider
                        label="Technical SEO/Data"
                        icon={TrendingUp}
                        value={attributes.technical}
                        onChange={(v) => handleAttributeChange('technical', v)}
                        remainingPoints={remainingPoints}
                    />
                    <AttributeSlider
                        label="Leadership & Man Management"
                        icon={Users}
                        value={attributes.leadership}
                        onChange={(v) => handleAttributeChange('leadership', v)}
                        remainingPoints={remainingPoints}
                    />
                </div>

                <button
                    onClick={handleStart}
                    disabled={!name.trim() || remainingPoints !== 0}
                    style={{
                        width: '100%',
                        padding: '1rem',
                        background: (!name.trim() || remainingPoints !== 0) ? 'var(--color-text-secondary)' : 'var(--color-accent)',
                        color: 'white',
                        border: 'none',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '1rem',
                        fontWeight: '600',
                        opacity: (!name.trim() || remainingPoints !== 0) ? 0.7 : 1,
                        cursor: (!name.trim() || remainingPoints !== 0) ? 'not-allowed' : 'pointer',
                        transition: 'background 0.2s'
                    }}
                >
                    Sign Contract
                </button>
            </div>
        </div>
    )
}
