import React from 'react'
import { useGameStore } from '../store/gameStore'
import { TrendingUp, Users, Eye, MousePointer, Activity, ThumbsUp } from 'lucide-react'

const StatCard = ({ label, value, change, icon: Icon, color }) => (
    <div className="glass-card" style={{ padding: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
            <div style={{
                padding: '0.5rem',
                borderRadius: 'var(--radius-md)',
                background: `${color}20`,
                color: color
            }}>
                <Icon size={20} />
            </div>
            <span style={{
                fontSize: '0.85rem',
                fontWeight: '600',
                color: change >= 0 ? 'var(--color-success)' : 'var(--color-danger)'
            }}>
                {change > 0 ? '+' : ''}{change}%
            </span>
        </div>
        <div style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '0.25rem' }}>{value}</div>
        <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>{label}</div>
    </div>
)

export const Dashboard = () => {
    const company = useGameStore(state => state.company)
    const manager = useGameStore(state => state.manager)
    const history = useGameStore(state => state.history)
    const boardTrust = useGameStore(state => state.boardTrust)
    const campaigns = useGameStore(state => state.campaigns)
    const posts = useGameStore(state => state.posts)
    const keywords = useGameStore(state => state.keywords)

    const lastResult = (history && history.length > 0) ? history[history.length - 1] : { revenue: 0, traffic: 0 }

    // Calculate real metrics from campaigns
    const totalImpressions = campaigns.reduce((sum, c) => sum + (c.results?.impressions || 0), 0)
    const totalClicks = campaigns.reduce((sum, c) => sum + (c.results?.clicks || 0), 0)
    const avgCTR = totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(2) : 0

    // Calculate trends from history
    const revenueChange = history.length >= 2
        ? ((lastResult.revenue - history[history.length - 2].revenue) / (history[history.length - 2].revenue || 1) * 100).toFixed(1)
        : 12

    const trafficChange = history.length >= 2
        ? ((lastResult.traffic - history[history.length - 2].traffic) / (history[history.length - 2].traffic || 1) * 100).toFixed(1)
        : 5

    // Calculate trust status
    const getTrustStatus = (trust) => {
        if (trust >= 80) return { label: 'Güvende', color: 'var(--color-success)' };
        if (trust >= 60) return { label: 'İyi', color: 'var(--color-accent)' };
        if (trust >= 40) return { label: 'Endişeli', color: 'var(--color-warning)' };
        return { label: 'Kritik', color: '#ef4444' };
    };

    const trustStatus = getTrustStatus(boardTrust);

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Stats Row */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem' }}>
                <StatCard label="Toplam Gelir" value={`$${(lastResult.revenue || 0).toLocaleString()}`} change={parseFloat(revenueChange)} icon={TrendingUp} color="var(--color-success)" />
                <StatCard label="Aktif Kullanıcı" value={(lastResult.traffic || 0).toLocaleString()} change={parseFloat(trafficChange)} icon={Users} color="var(--color-accent)" />
                <StatCard label="Gösterim" value={totalImpressions > 0 ? `${(totalImpressions / 1000).toFixed(1)}K` : '0'} change={campaigns.length > 0 ? 8 : 0} icon={Eye} color="var(--color-warning)" />
                <StatCard label="Ort. TO" value={`${avgCTR}%`} change={0.5} icon={MousePointer} color="var(--color-text-primary)" />
            </div>

            {/* Main Content Split */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem', flex: 1 }}>

                {/* Performance Analytics (Real Data) */}
                <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                        <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Activity size={20} /> Performans Eğrisi (Son 7 Gün)
                        </h3>
                    </div>

                    {/* Dynamic Graph from History */}
                    <div style={{ flex: 1, display: 'flex', alignItems: 'flex-end', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid rgba(0,0,0,0.1)' }}>
                        {history.slice(-7).length > 0 ? history.slice(-7).map((h, i) => {
                            const maxRev = Math.max(...history.slice(-7).map(x => x.revenue || 0), 100);
                            const heightPercent = Math.min(100, Math.max(10, ((h.revenue || 0) / maxRev) * 100));
                            return (
                                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', gap: '0.5rem' }}>
                                    <div style={{
                                        height: `${heightPercent}%`,
                                        background: 'linear-gradient(to top, var(--color-accent), #60a5fa)',
                                        borderRadius: '4px 4px 0 0',
                                        opacity: 0.8
                                    }}></div>
                                    <div style={{ fontSize: '0.75rem', textAlign: 'center', color: 'var(--color-text-secondary)' }}>
                                        {new Date(h.date).getDate()}
                                    </div>
                                </div>
                            )
                        }) : (
                            <div style={{ width: '100%', textAlign: 'center', color: 'var(--color-text-secondary)' }}>Henüz veri yok.</div>
                        )}
                    </div>
                </div>

                {/* Board Confidence / Job Status */}
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <ThumbsUp size={20} /> Yönetim Güveni
                    </h3>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                                <span>İş Güvenliği</span>
                                <span style={{ color: trustStatus.color, fontWeight: '600' }}>{trustStatus.label}</span>
                            </div>
                            <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px' }}>
                                <div style={{ width: `${boardTrust}%`, height: '100%', background: trustStatus.color, borderRadius: '4px' }}></div>
                            </div>
                        </div>

                        <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                                <span>Finansal Kontrol</span>
                                <span style={{ color: 'var(--color-accent)', fontWeight: '600' }}>İyi</span>
                            </div>
                            <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px' }}>
                                <div style={{ width: '70%', height: '100%', background: 'var(--color-accent)', borderRadius: '4px' }}></div>
                            </div>
                        </div>

                        <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                                <span>Marka Büyümesi</span>
                                <span style={{ color: 'var(--color-warning)', fontWeight: '600' }}>Endişe</span>
                            </div>
                            <div style={{ height: '8px', background: 'var(--color-bg-tertiary)', borderRadius: '4px' }}>
                                <div style={{ width: '45%', height: '100%', background: 'var(--color-warning)', borderRadius: '4px' }}></div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Notifications / Feed */}
                <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column' }}>
                    <h3 style={{ marginBottom: '1rem' }}>Yönetim Akışı</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', overflowY: 'auto' }}>
                        <div style={{ padding: '1rem', background: 'var(--color-bg-primary)', borderRadius: 'var(--radius-md)' }}>
                            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Bugün</div>
                            <div style={{ fontSize: '0.9rem' }}><strong>{company?.name} Sahibi:</strong> "Aramıza hoş geldin, {manager.name}. Hızlı sonuçlar bekliyoruz."</div>
                        </div>
                        <div style={{ padding: '1rem', background: 'var(--color-bg-primary)', borderRadius: 'var(--radius-md)' }}>
                            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', marginBottom: '0.25rem' }}>Dün</div>
                            <div style={{ fontSize: '0.9rem' }}><strong>Sistem:</strong> Ç1 Bütçesi onaylandı: ${company?.budget?.toLocaleString()}.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
