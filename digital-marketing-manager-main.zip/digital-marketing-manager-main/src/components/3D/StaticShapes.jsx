import React, { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, PerspectiveCamera, Environment, ContactShadows } from '@react-three/drei'
import * as THREE from 'three'

// Reusable Premium Material
const GlassMaterial = ({ color }) => (
    <meshPhysicalMaterial
        color={color}
        roughness={0.1}
        metalness={0.1}
        transmission={0.6} // Glass-like
        thickness={1.5}
        clearcoat={1}
        clearcoatRoughness={0.1}
    />
)

const MatteMaterial = ({ color }) => (
    <meshStandardMaterial
        color={color}
        roughness={0.4}
        metalness={0.3}
    />
)

const RocketModel = () => {
    return (
        <group rotation={[0, 0, Math.PI / 6]}>
            {/* Body */}
            <mesh position={[0, 0, 0]}>
                <cylinderGeometry args={[0.3, 0.5, 2, 32]} />
                <MatteMaterial color="#3b82f6" />
            </mesh>
            {/* Nose */}
            <mesh position={[0, 1.25, 0]}>
                <coneGeometry args={[0.3, 0.5, 32]} />
                <GlassMaterial color="#60a5fa" />
            </mesh>
            {/* Fins */}
            <mesh position={[0, -0.8, 0]} rotation={[0, 0, 0]}>
                <boxGeometry args={[1.2, 0.1, 0.1]} />
                <MatteMaterial color="#1d4ed8" />
            </mesh>
            <mesh position={[0, -0.8, 0]} rotation={[0, Math.PI / 2, 0]}>
                <boxGeometry args={[1.2, 0.1, 0.1]} />
                <MatteMaterial color="#1d4ed8" />
            </mesh>
        </group>
    )
}

const GraphModel = () => {
    return (
        <group position={[-0.5, -0.5, 0]}>
            <mesh position={[0, 0.5, 0]}>
                <boxGeometry args={[0.4, 1, 0.4]} />
                <MatteMaterial color="#3b82f6" />
            </mesh>
            <mesh position={[0.6, 0.8, 0]}>
                <boxGeometry args={[0.4, 1.6, 0.4]} />
                <GlassMaterial color="#60a5fa" />
            </mesh>
            <mesh position={[1.2, 1.2, 0]}>
                <boxGeometry args={[0.4, 2.4, 0.4]} />
                <MatteMaterial color="#2563eb" />
            </mesh>
        </group>
    )
}

const SocialModel = () => {
    return (
        <group>
            {/* Main Bubble */}
            <mesh position={[0, 0, 0]}>
                <sphereGeometry args={[0.8, 32, 32]} />
                <GlassMaterial color="#3b82f6" />
            </mesh>
            {/* Small Bubble */}
            <mesh position={[0.8, 0.8, 0.5]}>
                <sphereGeometry args={[0.4, 32, 32]} />
                <MatteMaterial color="#60a5fa" />
            </mesh>
        </group>
    )
}

const ToolsModel = () => {
    return (
        <group>
            {/* Gear */}
            <mesh rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[0.8, 0.2, 16, 32]} />
                <MatteMaterial color="#3b82f6" />
            </mesh>
            {/* Wrench handle implication */}
            <mesh position={[0.8, 0.8, -0.5]} rotation={[0, 0, Math.PI / 4]}>
                <cylinderGeometry args={[0.15, 0.15, 2, 16]} />
                <GlassMaterial color="#60a5fa" />
            </mesh>
        </group>
    )
}

const SceneContainer = ({ children }) => {
    return (
        <Canvas dpr={[1, 2]}>
            <PerspectiveCamera makeDefault position={[0, 0, 5]} fov={40} />
            <Environment preset="city" />
            <ambientLight intensity={0.5} />
            <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} />
            <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
                {children}
            </Float>
            <ContactShadows position={[0, -2, 0]} opacity={0.4} scale={10} blur={2.5} far={4} />
        </Canvas>
    )
}

export const StaticShape = ({ type }) => {
    return (
        <SceneContainer>
            {type === 'ROCKET' && <RocketModel />}
            {type === 'GRAPH' && <GraphModel />}
            {type === 'MEDIA' && <SocialModel />}
            {type === 'TOOLS' && <ToolsModel />}
        </SceneContainer>
    )
}
