import React, { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, Sphere, MeshDistortMaterial } from '@react-three/drei'

const FloatingBubble = ({ position, color, speed }) => {
    const mesh = useRef()
    const [hovered, setHover] = React.useState(false)

    useFrame((state) => {
        const t = state.clock.getElapsedTime()
        mesh.current.scale.setScalar(hovered ? 1.2 : 1 + Math.sin(t * speed) * 0.1)
    })

    return (
        <Float speed={speed} rotationIntensity={1} floatIntensity={2} position={position}>
            <Sphere ref={mesh} args={[0.4, 32, 32]} onPointerOver={() => setHover(true)} onPointerOut={() => setHover(false)}>
                <MeshDistortMaterial color={color} speed={2} distort={0.4} radius={1} />
            </Sphere>
        </Float>
    )
}

export const AdsScene = () => {
    return (
        <Canvas camera={{ position: [0, 0, 5] }} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} />

            <FloatingBubble position={[-2, 1, 0]} color="#3b82f6" speed={2} />
            <FloatingBubble position={[2, -1, 0]} color="#ef4444" speed={1.5} />
            <FloatingBubble position={[0, 0, -2]} color="#10b981" speed={1} />
        </Canvas>
    )
}
