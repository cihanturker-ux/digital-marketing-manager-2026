import React, { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Line, Sphere } from '@react-three/drei'
import * as THREE from 'three'

const Node = ({ position }) => {
    const [hovered, setHover] = React.useState(false)

    return (
        <Sphere args={[0.1, 16, 16]} position={position} onPointerOver={() => setHover(true)} onPointerOut={() => setHover(false)}>
            <meshStandardMaterial color={hovered ? "#10b981" : "#cbd5e1"} />
        </Sphere>
    )
}

const Network = () => {
    const group = useRef()

    // Create random nodes
    const nodes = useMemo(() => {
        return new Array(15).fill(0).map(() => [
            (Math.random() - 0.5) * 8,
            (Math.random() - 0.5) * 4,
            (Math.random() - 0.5) * 2
        ])
    }, [])

    useFrame((state) => {
        group.current.rotation.y = state.clock.getElapsedTime() * 0.05
    })

    return (
        <group ref={group}>
            {nodes.map((pos, i) => (
                <Node key={i} position={pos} />
            ))}
            {nodes.map((pos, i) => {
                // Connect to next node
                const next = nodes[(i + 1) % nodes.length]
                return <Line key={i} points={[pos, next]} color="#e2e8f0" lineWidth={1} transparent opacity={0.3} />
            })}
        </group>
    )
}

export const SeoScene = () => {
    return (
        <Canvas camera={{ position: [0, 0, 5] }} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: -1 }}>
            <ambientLight intensity={0.8} />
            <Network />
        </Canvas>
    )
}
