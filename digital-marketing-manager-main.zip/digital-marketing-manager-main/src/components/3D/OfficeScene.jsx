import React, { useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, useGLTF, Float, Text, Environment, ContactShadows } from '@react-three/drei'
import * as THREE from 'three'

// Placeholder for a 3D Laptop Model (using basic shapes for now to avoid external dependency errors)
const Laptop = (props) => {
    const group = useRef()

    useFrame((state) => {
        const t = state.clock.getElapsedTime()
        group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, Math.cos(t / 2) / 10 + 0.25, 0.1)
        group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, Math.sin(t / 4) / 10, 0.1)
        group.current.rotation.z = THREE.MathUtils.lerp(group.current.rotation.z, Math.sin(t / 4) / 20, 0.1)
        group.current.position.y = THREE.MathUtils.lerp(group.current.position.y, (-2 + Math.sin(t)) / 3, 0.1)
    })

    return (
        <group ref={group} {...props} dispose={null}>
            <group rotation-x={-0.425} position={[0, -0.04, 0.41]}>
                <group position={[0, 2.96, -0.13]} rotation={[Math.PI / 2, 0, 0]}>
                    <mesh material={new THREE.MeshStandardMaterial({ color: '#e0e0e0' })} geometry={new THREE.BoxGeometry(3, 2, 0.1)} />
                    <mesh material={new THREE.MeshStandardMaterial({ color: 'black' })} geometry={new THREE.BoxGeometry(2.8, 1.8, 0.05)} position={[0, 0, 0.05]} />
                </group>
            </group>
            <mesh material={new THREE.MeshStandardMaterial({ color: '#e0e0e0' })} geometry={new THREE.BoxGeometry(3, 0.2, 2)} position={[0, -0.1, 0]} />
        </group>
    )
}

const FloatingStats = ({ label, value, position, color }) => {
    return (
        <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5} position={position}>
            <group>
                <mesh>
                    <boxGeometry args={[1.8, 0.8, 0.1]} />
                    <meshStandardMaterial color="white" transparent opacity={0.9} />
                </mesh>
                <Text position={[0, 0.15, 0.06]} fontSize={0.2} color="#666" anchorX="center" anchorY="middle">
                    {label}
                </Text>
                <Text position={[0, -0.15, 0.06]} fontSize={0.3} color={color} fontWeight="bold" anchorX="center" anchorY="middle">
                    {value}
                </Text>
            </group>
        </Float>
    )
}

export const OfficeScene = ({ stats }) => {
    return (
        <Canvas camera={{ position: [0, 0, 6], fov: 45 }}>
            <ambientLight intensity={0.7} />
            <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} shadow-mapSize={2048} castShadow />
            <Environment preset="city" />

            <group position={[0, -1, 0]}>
                <Laptop />
                <ContactShadows position={[0, -1.5, 0]} opacity={0.4} scale={10} blur={2.5} far={4} />
            </group>

            <FloatingStats label="Revenue" value={`$${stats?.revenue?.toLocaleString() || 0}`} position={[-2.5, 1, 0]} color="#10b981" />
            <FloatingStats label="Traffic" value={stats?.traffic?.toLocaleString() || 0} position={[2.5, 0.5, 0]} color="#3b82f6" />

            <OrbitControls enableZoom={false} enablePan={false} minPolarAngle={Math.PI / 2.5} maxPolarAngle={Math.PI / 2.5} />
        </Canvas>
    )
}
