import React, { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, Text3D, Center, Text } from '@react-three/drei'

const FloatingIcon = ({ char, position, color, speed }) => {
    const [hovered, setHover] = React.useState(false)

    return (
        <Float speed={speed} rotationIntensity={1} floatIntensity={1} position={position}>
            <Text
                fontSize={0.5}
                color={hovered ? color : "#94a3b8"}
                anchorX="center"
                anchorY="middle"
                onPointerOver={() => setHover(true)}
                onPointerOut={() => setHover(false)}
            >
                {char}
            </Text>
        </Float>
    )
}

export const SocialScene = () => {
    return (
        <Canvas camera={{ position: [0, 0, 5] }} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: -1 }}>
            <ambientLight intensity={1} />
            <FloatingIcon char="♥" position={[-2, 1, 0]} color="#ef4444" speed={2} />
            <FloatingIcon char="@" position={[2, -1, 0]} color="#3b82f6" speed={1.5} />
            <FloatingIcon char="#" position={[0, 0, -1]} color="#8b5cf6" speed={1} />
            <FloatingIcon char="★" position={[1.5, 1.5, -1]} color="#f59e0b" speed={1.2} />
        </Canvas>
    )
}
