import React, { useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import * as THREE from 'three'
import { generateShape } from '../../utils/shapeGenerator'

const Particles = ({ shapeType }) => {
    const pointsRef = useRef()
    const hoverRef = useRef(new THREE.Vector3(9999, 9999, 9999))

    // Store initial positions
    const { initialPositions, colors, randoms } = useMemo(() => {
        const points = generateShape(shapeType, 5000) // Good density
        const initialPositions = new Float32Array(points.length * 3)
        const colors = new Float32Array(points.length * 3)
        const randoms = new Float32Array(points.length)

        points.forEach((p, i) => {
            initialPositions[i * 3] = p.x
            initialPositions[i * 3 + 1] = p.y
            initialPositions[i * 3 + 2] = p.z

            // Reference Blue (#3b82f6)
            colors[i * 3] = 0.23
            colors[i * 3 + 1] = 0.51
            colors[i * 3 + 2] = 0.96

            randoms[i] = Math.random() * Math.PI * 2 // Random phase
        })

        return { initialPositions, colors, randoms }
    }, [shapeType])

    useFrame((state) => {
        const { pointer, camera } = state
        const time = state.clock.getElapsedTime()

        // Raycasting
        const vector = new THREE.Vector3(pointer.x, pointer.y, 0.5)
        vector.unproject(camera)
        const dir = vector.sub(camera.position).normalize()
        const distance = -camera.position.z / dir.z
        const pos = camera.position.clone().add(dir.multiplyScalar(distance))
        hoverRef.current.copy(pos)

        const geometry = pointsRef.current.geometry
        const positionAttribute = geometry.attributes.position
        const colorAttribute = geometry.attributes.color

        for (let i = 0; i < positionAttribute.count; i++) {
            const ix = initialPositions[i * 3]
            const iy = initialPositions[i * 3 + 1]
            const iz = initialPositions[i * 3 + 2]

            // STRICTLY LOCAL VIBRATION
            // No traveling waves. Just random oscillation in place.
            // Amplitude is very small (0.005) to ensure they stay "in place".
            const vibrationX = Math.sin(time * 3 + randoms[i]) * 0.005
            const vibrationY = Math.cos(time * 2 + randoms[i]) * 0.005

            positionAttribute.setXYZ(i, ix + vibrationX, iy + vibrationY, iz)

            // Mouse Interaction
            const dx = (ix + vibrationX) - hoverRef.current.x
            const dy = (iy + vibrationY) - hoverRef.current.y
            const dist = Math.sqrt(dx * dx + dy * dy)

            if (dist < 0.6) {
                // Colorful on hover
                colorAttribute.setXYZ(i,
                    0.5 + 0.5 * Math.sin(i * 0.1 + time * 5),
                    0.5 + 0.5 * Math.sin(i * 0.2 + time * 5),
                    0.5 + 0.5 * Math.sin(i * 0.3 + time * 5)
                )
            } else {
                // Revert to Blue
                colorAttribute.setXYZ(i, 0.23, 0.51, 0.96)
            }
        }

        positionAttribute.needsUpdate = true
        colorAttribute.needsUpdate = true
    })

    return (
        <points ref={pointsRef}>
            <bufferGeometry>
                <bufferAttribute
                    attach="attributes-position"
                    count={initialPositions.length / 3}
                    array={initialPositions} // Initialize with static array, update in loop
                    itemSize={3}
                />
                <bufferAttribute
                    attach="attributes-color"
                    count={colors.length / 3}
                    array={colors}
                    itemSize={3}
                />
            </bufferGeometry>
            <pointsMaterial
                size={0.04} // Slightly larger points
                vertexColors
                transparent
                opacity={0.9}
                sizeAttenuation={true}
            />
        </points>
    )
}

export const InteractiveParticles = ({ shapeType }) => {
    return (
        <Canvas camera={{ position: [0, 0, 4], fov: 45 }} style={{ background: 'white' }}>
            <Particles shapeType={shapeType} />
            <OrbitControls enableZoom={false} enablePan={false} enableRotate={false} /> {/* Locked view */}
        </Canvas>
    )
}
