import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { AlertTriangle, RotateCcw } from 'lucide-react'

export const GameOverModal = () => {
    const resetGame = useGameStore(state => state.resetGame)

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
        }}>
            <div className="glass-card" style={{ width: '500px', padding: '3rem', textAlign: 'center', background: 'white' }}>
                <div style={{
                    width: '80px', height: '80px', background: 'var(--color-danger)', borderRadius: '50%',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem auto',
                    boxShadow: '0 10px 25px rgba(239, 68, 68, 0.4)'
                }}>
                    <AlertTriangle size={40} color="white" />
                </div>

                <h1 style={{ fontSize: '2.5rem', fontWeight: '800', marginBottom: '1rem', color: 'var(--color-text-primary)' }}>Bankrupt!</h1>
                <p style={{ fontSize: '1.1rem', color: 'var(--color-text-secondary)', marginBottom: '2rem', lineHeight: '1.6' }}>
                    Your company has run out of funds. The board has terminated your contract effective immediately.
                </p>

                <button
                    onClick={() => { resetGame(); window.location.reload(); }}
                    style={{
                        width: '100%',
                        padding: '1rem 2rem', background: 'var(--color-accent)', color: 'white',
                        border: 'none', borderRadius: 'var(--radius-md)', fontWeight: '600', cursor: 'pointer',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem'
                    }}
                >
                    <RotateCcw size={18} /> Start New Career
                </button>
            </div>
        </div>
    )
}
