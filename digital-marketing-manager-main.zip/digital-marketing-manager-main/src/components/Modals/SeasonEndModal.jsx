import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { Trophy, TrendingUp, Target, DollarSign, Briefcase, Award, ChevronRight, Sparkles } from 'lucide-react'

export const SeasonEndModal = () => {
    const currentSeason = useGameStore(state => state.currentSeason)
    const seasonStats = useGameStore(state => state.seasonStats)
    const boardTrust = useGameStore(state => state.boardTrust)
    const company = useGameStore(state => state.company)
    const seasonPlayTime = useGameStore(state => state.seasonPlayTime)
    const completeSeasonAndStartNew = useGameStore(state => state.completeSeasonAndStartNew)

    // Calculate performance grade
    const getPerformanceGrade = () => {
        const score = (
            (seasonStats.tasksCompleted * 10) +
            (seasonStats.totalRevenue / 1000) +
            (boardTrust * 2) -
            (seasonStats.tasksFailed * 15)
        );

        if (score >= 800) return { grade: 'S', color: '#fbbf24', label: 'Outstanding' };
        if (score >= 600) return { grade: 'A', color: '#10b981', label: 'Excellent' };
        if (score >= 400) return { grade: 'B', color: '#3b82f6', label: 'Good' };
        if (score >= 200) return { grade: 'C', color: '#f97316', label: 'Fair' };
        return { grade: 'D', color: '#ef4444', label: 'Poor' };
    };

    const performance = getPerformanceGrade();
    const playTimeHours = Math.floor(seasonPlayTime / (1000 * 60 * 60));
    const playTimeMins = Math.floor((seasonPlayTime % (1000 * 60 * 60)) / (1000 * 60));

    // Calculate rewards
    const bonusBudget = 50000;
    const bonusXP = 2000;
    const contractExtension = boardTrust >= 60;

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            background: 'linear-gradient(135deg, rgba(0,0,0,0.95), rgba(30,30,60,0.95))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 300,
            backdropFilter: 'blur(10px)',
            animation: 'fadeIn 0.5s ease'
        }}>
            <div style={{
                width: '900px',
                maxHeight: '90vh',
                overflowY: 'auto',
                background: 'linear-gradient(135deg, #1e1e2e, #2a2a3e)',
                borderRadius: '20px',
                boxShadow: '0 30px 90px rgba(0,0,0,0.5)',
                animation: 'slideUp 0.5s ease'
            }}>
                {/* Header */}
                <div style={{
                    background: `linear-gradient(135deg, ${performance.color}, ${performance.color}dd)`,
                    padding: '3rem 2rem',
                    textAlign: 'center',
                    borderRadius: '20px 20px 0 0',
                    position: 'relative',
                    overflow: 'hidden'
                }}>
                    <div style={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        fontSize: '20rem',
                        fontWeight: '900',
                        color: 'rgba(255,255,255,0.05)',
                        zIndex: 0
                    }}>
                        {performance.grade}
                    </div>

                    <div style={{ position: 'relative', zIndex: 1 }}>
                        <Trophy size={64} color="white" style={{ marginBottom: '1rem' }} />
                        <h1 style={{ fontSize: '2.5rem', fontWeight: '900', color: 'white', marginBottom: '0.5rem' }}>
                            Season {currentSeason} Complete!
                        </h1>
                        <p style={{ fontSize: '1.2rem', color: 'rgba(255,255,255,0.9)', fontWeight: '600' }}>
                            {performance.label} Performance - Grade {performance.grade}
                        </p>
                        <div style={{ marginTop: '1rem', fontSize: '0.9rem', color: 'rgba(255,255,255,0.8)' }}>
                            Play Time: {playTimeHours}h {playTimeMins}m
                        </div>
                    </div>
                </div>

                {/* Stats Grid */}
                <div style={{ padding: '2rem' }}>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'white', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Award size={24} />
                        Season Summary
                    </h2>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1.5rem', marginBottom: '2rem' }}>
                        <StatCard
                            icon={Target}
                            label="Tasks Completed"
                            value={seasonStats.tasksCompleted}
                            color="#10b981"
                        />
                        <StatCard
                            icon={Target}
                            label="Tasks Failed"
                            value={seasonStats.tasksFailed}
                            color="#ef4444"
                        />
                        <StatCard
                            icon={Briefcase}
                            label="Campaigns Launched"
                            value={seasonStats.campaignsLaunched}
                            color="#3b82f6"
                        />
                        <StatCard
                            icon={DollarSign}
                            label="Total Revenue"
                            value={`$${seasonStats.totalRevenue.toLocaleString()}`}
                            color="#fbbf24"
                        />
                        <StatCard
                            icon={TrendingUp}
                            label="Peak Board Trust"
                            value={`${seasonStats.peakBoardTrust}%`}
                            color="#10b981"
                        />
                        <StatCard
                            icon={TrendingUp}
                            label="Final Board Trust"
                            value={`${boardTrust}%`}
                            color={boardTrust >= 70 ? '#10b981' : '#ef4444'}
                        />
                    </div>

                    {/* Board Review */}
                    <div style={{
                        background: 'rgba(255,255,255,0.05)',
                        borderRadius: '12px',
                        padding: '2rem',
                        marginBottom: '2rem',
                        border: '1px solid rgba(255,255,255,0.1)'
                    }}>
                        <h3 style={{ fontSize: '1.2rem', fontWeight: '700', color: 'white', marginBottom: '1rem' }}>
                            Board of Directors Review
                        </h3>
                        <p style={{ fontSize: '1rem', color: 'rgba(255,255,255,0.8)', lineHeight: '1.8', marginBottom: '1.5rem' }}>
                            {getboardMessage(performance.grade, boardTrust, contractExtension)}
                        </p>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '1rem', background: contractExtension ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)', borderRadius: '8px', border: `1px solid ${contractExtension ? '#10b981' : '#ef4444'}` }}>
                            <div style={{ fontSize: '1.5rem' }}>{contractExtension ? '✅' : '⚠️'}</div>
                            <div>
                                <div style={{ fontWeight: '700', color: 'white', marginBottom: '0.25rem' }}>
                                    {contractExtension ? 'Contract Extended' : 'Contract Under Review'}
                                </div>
                                <div style={{ fontSize: '0.9rem', color: 'rgba(255,255,255,0.7)' }}>
                                    {contractExtension
                                        ? 'Your contract has been automatically renewed for another season.'
                                        : 'Improve performance next season to secure your position.'}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Rewards */}
                    <div style={{
                        background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(147, 51, 234, 0.2))',
                        borderRadius: '12px',
                        padding: '2rem',
                        marginBottom: '2rem',
                        border: '1px solid rgba(59, 130, 246, 0.3)'
                    }}>
                        <h3 style={{ fontSize: '1.2rem', fontWeight: '700', color: 'white', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Sparkles size={24} />
                            Season Completion Rewards
                        </h3>

                        <div style={{ display: 'grid', gap: '1rem' }}>
                            <RewardItem label="Bonus Budget" value={`+$${bonusBudget.toLocaleString()}`} />
                            <RewardItem label="Experience Points" value={`+${bonusXP} XP`} />
                            <RewardItem label="Season Progression" value={`Season ${currentSeason} → Season ${currentSeason + 1}`} />
                        </div>
                    </div>

                    {/* Continue Button */}
                    <button
                        onClick={completeSeasonAndStartNew}
                        style={{
                            width: '100%',
                            padding: '1.25rem',
                            background: 'linear-gradient(135deg, var(--color-accent), #3b82f6)',
                            color: 'white',
                            border: 'none',
                            borderRadius: '12px',
                            fontSize: '1.1rem',
                            fontWeight: '700',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '0.5rem',
                            boxShadow: '0 8px 24px rgba(59, 130, 246, 0.4)',
                            transition: 'transform 0.2s ease'
                        }}
                        onMouseEnter={e => e.target.style.transform = 'translateY(-2px)'}
                        onMouseLeave={e => e.target.style.transform = 'translateY(0)'}
                    >
                        Continue to Season {currentSeason + 1}
                        <ChevronRight size={24} />
                    </button>
                </div>
            </div>

            <style>{`
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideUp {
                    from { transform: translateY(30px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
            `}</style>
        </div>
    )
}

const StatCard = ({ icon: Icon, label, value, color }) => (
    <div style={{
        background: 'rgba(255,255,255,0.05)',
        borderRadius: '12px',
        padding: '1.5rem',
        border: '1px solid rgba(255,255,255,0.1)',
        textAlign: 'center'
    }}>
        <Icon size={32} color={color} style={{ marginBottom: '0.75rem' }} />
        <div style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '1px' }}>
            {label}
        </div>
        <div style={{ fontSize: '2rem', fontWeight: '900', color: 'white' }}>
            {value}
        </div>
    </div>
)

const RewardItem = ({ label, value }) => (
    <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '1rem',
        background: 'rgba(255,255,255,0.05)',
        borderRadius: '8px',
        border: '1px solid rgba(255,255,255,0.1)'
    }}>
        <span style={{ color: 'rgba(255,255,255,0.8)', fontWeight: '600' }}>{label}</span>
        <span style={{ color: 'white', fontWeight: '700', fontSize: '1.1rem' }}>{value}</span>
    </div>
)

function getboardMessage(grade, trust, extended) {
    if (grade === 'S') {
        return "Outstanding work! Your exceptional performance this season has exceeded all expectations. The board is thrilled with your leadership and strategic vision. We're honored to have you leading our marketing department.";
    }
    if (grade === 'A') {
        return "Excellent performance this season. You've consistently delivered strong results and demonstrated great leadership. The board has full confidence in your abilities and looks forward to continued success.";
    }
    if (grade === 'B') {
        return "Good work this season. While there's room for improvement, you've shown solid performance overall. The board appreciates your efforts and expects to see continued progress.";
    }
    if (trust < 60) {
        return "The board has serious concerns about this season's performance. Significant improvement is required in the coming season. We need to see better results in task completion and revenue generation.";
    }
    return "Your performance this season has been below expectations. The board expects significant improvements in the upcoming season. Focus on completing assigned tasks and improving overall results.";
}
