import React from 'react'
import { useGameStore } from '../../store/gameStore'
import { AlertCircle, CheckCircle, Clock, Target, TrendingUp, TrendingDown } from 'lucide-react'

export const TaskNotification = ({ task, onClose }) => {
    const date = useGameStore(state => state.date)

    const deadline = new Date(task.deadline)
    const currentDate = date instanceof Date ? date : new Date(date)
    const daysLeft = Math.ceil((deadline - currentDate) / (1000 * 60 * 60 * 24))

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200,
            backdropFilter: 'blur(6px)', animation: 'fadeIn 0.3s ease'
        }}>
            <div className="glass-card" style={{
                width: '500px', padding: '2rem', background: 'white',
                boxShadow: '0 20px 60px rgba(0,0,0,0.3)', animation: 'slideUp 0.3s ease'
            }}>
                {/* Header */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '1rem',
                    marginBottom: '1.5rem',
                    padding: '1rem',
                    background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1))',
                    borderRadius: 'var(--radius-md)',
                    border: '2px solid var(--color-accent)'
                }}>
                    <div style={{
                        width: '50px', height: '50px', borderRadius: '50%',
                        background: 'var(--color-accent)', color: 'white',
                        display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}>
                        <Target size={24} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--color-accent)', textTransform: 'uppercase', letterSpacing: '1px' }}>
                            New Board Directive
                        </div>
                        <h2 style={{ fontSize: '1.3rem', fontWeight: '700', margin: '0.25rem 0' }}>{task.title}</h2>
                    </div>
                </div>

                {/* Task Description */}
                <div style={{ marginBottom: '2rem' }}>
                    <p style={{ fontSize: '1rem', color: 'var(--color-text-primary)', marginBottom: '1rem', lineHeight: '1.6' }}>
                        {task.description}
                    </p>

                    {/* Requirement Box */}
                    <div style={{
                        padding: '1rem',
                        background: 'var(--color-bg-tertiary)',
                        borderRadius: 'var(--radius-md)',
                        borderLeft: '4px solid var(--color-accent)'
                    }}>
                        <div style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--color-text-secondary)', marginBottom: '0.5rem', textTransform: 'uppercase' }}>
                            Requirement
                        </div>
                        <div style={{ fontSize: '0.95rem', fontWeight: '600', color: 'var(--color-text-primary)' }}>
                            {task.requirement}
                        </div>
                    </div>
                </div>

                {/* Deadline & Stats */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '2rem' }}>
                    <div style={{
                        padding: '1rem',
                        background: daysLeft <= 2 ? 'rgba(239, 68, 68, 0.1)' : 'rgba(59, 130, 246, 0.1)',
                        borderRadius: 'var(--radius-md)',
                        border: `1px solid ${daysLeft <= 2 ? '#ef4444' : 'var(--color-accent)'}`
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                            <Clock size={16} color={daysLeft <= 2 ? '#ef4444' : 'var(--color-accent)'} />
                            <span style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--color-text-secondary)' }}>Deadline</span>
                        </div>
                        <div style={{ fontSize: '1.2rem', fontWeight: '700', color: daysLeft <= 2 ? '#ef4444' : 'var(--color-accent)' }}>
                            {daysLeft} {daysLeft === 1 ? 'day' : 'days'}
                        </div>
                    </div>

                    <div style={{
                        padding: '1rem',
                        background: 'rgba(16, 185, 129, 0.1)',
                        borderRadius: 'var(--radius-md)',
                        border: '1px solid var(--color-success)'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                            <CheckCircle size={16} color="var(--color-success)" />
                            <span style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--color-text-secondary)' }}>Reward</span>
                        </div>
                        <div style={{ fontSize: '1.2rem', fontWeight: '700', color: 'var(--color-success)' }}>
                            +{task.trustReward} Trust
                        </div>
                    </div>
                </div>

                {/* Warning */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '1rem',
                    background: 'rgba(239, 68, 68, 0.05)',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid rgba(239, 68, 68, 0.2)',
                    marginBottom: '2rem'
                }}>
                    <AlertCircle size={20} color="#ef4444" />
                    <div style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                        <strong style={{ color: '#ef4444' }}>Warning:</strong> Failure to complete this task will result in <strong>-{task.trustPenalty} Board Trust</strong>
                    </div>
                </div>

                {/* Action Button */}
                <button
                    onClick={onClose}
                    style={{
                        width: '100%',
                        padding: '1rem',
                        background: 'linear-gradient(135deg, var(--color-accent), #3b82f6)',
                        color: 'white',
                        border: 'none',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '1rem',
                        fontWeight: '700',
                        cursor: 'pointer',
                        boxShadow: '0 4px 12px rgba(59, 130, 246, 0.3)',
                        transition: 'transform 0.2s ease, box-shadow 0.2s ease'
                    }}
                    onMouseEnter={e => {
                        e.target.style.transform = 'translateY(-2px)';
                        e.target.style.boxShadow = '0 6px 16px rgba(59, 130, 246, 0.4)';
                    }}
                    onMouseLeave={e => {
                        e.target.style.transform = 'translateY(0)';
                        e.target.style.boxShadow = '0 4px 12px rgba(59, 130, 246, 0.3)';
                    }}
                >
                    I Understand - Get to Work!
                </button>
            </div>

            <style>{`
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideUp {
                    from { transform: translateY(20px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
            `}</style>
        </div>
    )
}
