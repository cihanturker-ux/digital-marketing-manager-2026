import React, { useState } from 'react'
import { useGameStore } from '../../store/gameStore'
import { Calendar, DollarSign, Play, Star, TrendingUp, Trophy, Clock } from 'lucide-react'
import { CampaignLiveMatch } from '../Modules/CampaignLiveMatch'

export const Header = () => {
    const [showMatch, setShowMatch] = useState(false)
    const date = useGameStore(state => state.date)
    const currentSeason = useGameStore(state => state.currentSeason)
    const seasonPlayTime = useGameStore(state => state.seasonPlayTime)
    const seasonDuration = useGameStore(state => state.seasonDuration)

    // Game Controls
    const isPlaying = useGameStore(state => state.isPlaying)
    const gameSpeed = useGameStore(state => state.gameSpeed)
    const setIsPlaying = useGameStore(state => state.setIsPlaying)
    const setGameSpeed = useGameStore(state => state.setGameSpeed)

    const togglePlay = () => setIsPlaying(!isPlaying)

    const formatDate = (dateObj) => {
        const d = dateObj instanceof Date ? dateObj : new Date(dateObj);
        return d.toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' })
    }

    const seasonProgress = (seasonPlayTime / seasonDuration) * 100;
    const timeLeftHours = Math.floor((seasonDuration - seasonPlayTime) / (1000 * 60 * 60));
    const timeLeftMins = Math.floor(((seasonDuration - seasonPlayTime) % (1000 * 60 * 60)) / (1000 * 60));

    return (
        <header style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '1rem',
            marginBottom: '2rem',
            padding: '0.5rem 0'
        }}>
            {showMatch && <CampaignLiveMatch onClose={() => setShowMatch(false)} />}

            {/* Top Row */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div className="glass-card" style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Calendar size={18} color="var(--color-text-secondary)" />
                        <span style={{ fontWeight: '600' }}>{formatDate(date)}</span>
                    </div>
                    <div className="glass-card" style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Trophy size={18} color="#fbbf24" />
                        <span style={{ fontWeight: '600' }}>Sezon {currentSeason}</span>
                    </div>
                    <div className="glass-card" style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Star size={18} color="var(--color-accent)" />
                        <span style={{ fontWeight: '600' }}>Seviye: {useGameStore(state => state.level)}</span>
                    </div>
                    <div className="glass-card" style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <TrendingUp size={18} color="var(--color-warning)" />
                        <span style={{ fontWeight: '600' }}>Zorluk: {useGameStore(state => state.difficulty)}</span>
                    </div>
                    {useGameStore(state => state.monthlyGoal) && (
                        <div className="glass-card" style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <DollarSign size={18} color="var(--color-success)" />
                            <span style={{ fontWeight: '600' }}>Aylık Hedef: ${useGameStore(state => state.monthlyGoal).toLocaleString()}</span>
                        </div>
                    )}
                </div>

                {/* Time Controls */}
                {/* Time Controls - Next Day */}
                <button
                    onClick={() => useGameStore.getState().advanceTime(1)}
                    className="glass-card"
                    style={{
                        padding: '0.75rem 1.5rem',
                        display: 'flex', alignItems: 'center', gap: '0.75rem',
                        background: 'var(--color-accent)', color: 'white',
                        border: 'none', cursor: 'pointer',
                        boxShadow: '0 4px 12px rgba(139, 92, 246, 0.3)',
                        height: 'fit-content'
                    }}
                >
                    <span style={{ fontWeight: '700', fontSize: '1rem' }}>Sonraki Gün</span>
                    <div style={{ background: 'rgba(255,255,255,0.2)', borderRadius: '50%', padding: '4px' }}>
                        <Play size={16} fill="white" />
                    </div>
                </button>
            </div>


            {/* Season Progress Bar */}
            <div className="glass-card" style={{ padding: '1rem 1.5rem', border: 'none', background: 'rgba(255,255,255,0.5)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Clock size={16} color="var(--color-accent)" />
                        <span style={{ fontSize: '0.9rem', fontWeight: '600', color: 'var(--color-text-primary)' }}>
                            Sezon {currentSeason} İlerlemesi
                        </span>
                    </div>
                    <span style={{ fontSize: '0.85rem', color: 'var(--color-text-secondary)', fontWeight: '500' }}>
                        {timeLeftHours}s {timeLeftMins}d kaldı
                    </span>
                </div>
                <div style={{
                    width: '100%',
                    height: '8px',
                    background: 'var(--color-bg-tertiary)',
                    borderRadius: '10px',
                    overflow: 'hidden',
                }}>
                    <div style={{
                        width: `${Math.min(seasonProgress, 100)}%`,
                        height: '100%',
                        background: 'linear-gradient(90deg, var(--color-accent), #d8b4fe)',
                        borderRadius: '10px',
                        transition: 'width 0.3s ease',
                        boxShadow: '0 0 15px rgba(139, 92, 246, 0.4)'
                    }} />
                </div>
                <div style={{
                    marginTop: '0.5rem',
                    fontSize: '0.8rem',
                    color: 'var(--color-text-secondary)',
                    textAlign: 'center',
                    fontWeight: '500'
                }}>
                    %{seasonProgress.toFixed(1)} Tamamlandı
                </div>
            </div>
        </header>
    )
}

