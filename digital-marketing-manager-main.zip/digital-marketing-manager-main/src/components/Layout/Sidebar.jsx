import React from 'react'
import { LayoutDashboard, Inbox, Users, TrendingUp, Search, Share2, LogOut, Newspaper, Mail, Settings, Megaphone, DollarSign, Crosshair, UserPlus, BookOpen, PieChart, Smile, Globe, ArrowRight, Target, CheckSquare, Mic, Heart } from 'lucide-react'
import { useGameStore } from '../../store/gameStore'

const NavItem = ({ icon: Icon, label, active, onClick }) => (
    <div
        onClick={onClick}
        style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            padding: '0.75rem 1rem',
            borderRadius: 'var(--radius-md)',
            cursor: 'pointer',
            background: active ? 'rgba(139, 92, 246, 0.08)' : 'transparent',
            color: active ? 'var(--color-accent)' : 'var(--color-text-secondary)',
            fontWeight: active ? '600' : '500',
            transition: 'all 0.2s ease',
            marginBottom: '0.25rem',
            position: 'relative',
            overflow: 'hidden'
        }}
    >
        {active && (
            <div style={{
                position: 'absolute',
                left: 0,
                top: '50%',
                transform: 'translateY(-50%)',
                width: '3px',
                height: '60%',
                background: 'var(--color-accent)',
                borderRadius: '0 4px 4px 0'
            }} />
        )}
        <Icon size={20} strokeWidth={active ? 2.5 : 2} />
        <span>{label}</span>
    </div>
)

export const Sidebar = ({ currentView, onViewChange }) => {
    const tasks = useGameStore(state => state.tasks)
    const activeTasks = tasks.filter(t => t.status === 'ACTIVE')

    return (
        <div className="glass-panel" style={{
            width: '260px',
            height: '100vh',
            padding: '1.5rem',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 10
        }}>
            <div style={{ marginBottom: '2.5rem', paddingLeft: '0.5rem' }}>
                <h2 className="text-gradient" style={{ fontSize: '1.5rem', fontWeight: '900', letterSpacing: '-0.5px' }}>DMM 26</h2>
                <p style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', fontWeight: '500' }}>Digital Marketing Manager</p>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', paddingRight: '0.5rem' }}>
                <div style={{ marginBottom: '1.5rem' }}>
                    <p style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--color-text-secondary)', marginBottom: '0.5rem', paddingLeft: '1rem' }}>YÖNETİM</p>
                    <NavItem icon={LayoutDashboard} label="Kontrol Paneli" active={currentView === 'DASHBOARD'} onClick={() => onViewChange('DASHBOARD')} />
                    <NavItem icon={Target} label="Yönetim Vizyonu" active={currentView === 'BOARD_VISION'} onClick={() => onViewChange('BOARD_VISION')} />
                    <div style={{ position: 'relative' }}>
                        <NavItem icon={CheckSquare} label="Görevler" active={currentView === 'TASKS'} onClick={() => onViewChange('TASKS')} />
                        {activeTasks.length > 0 && (
                            <div style={{
                                position: 'absolute',
                                right: '1rem',
                                top: '50%',
                                transform: 'translateY(-50%)',
                                background: '#ef4444',
                                color: 'white',
                                borderRadius: '50%',
                                width: '20px',
                                height: '20px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '0.7rem',
                                fontWeight: '700'
                            }}>
                                {activeTasks.length}
                            </div>
                        )}
                    </div>
                    <NavItem icon={Mail} label="Gelen Kutusu" active={currentView === 'INBOX'} onClick={() => onViewChange('INBOX')} />
                    <NavItem icon={Mic} label="Basın Toplantısı" active={currentView === 'PRESS'} onClick={() => onViewChange('PRESS')} />
                    <NavItem icon={Users} label="Ekip" active={currentView === 'TEAM'} onClick={() => onViewChange('TEAM')} />
                    <NavItem icon={Heart} label="Personel Morali" active={currentView === 'MORALE'} onClick={() => onViewChange('MORALE')} />
                    <NavItem icon={Smile} label="Dinamikler" active={currentView === 'DYNAMICS'} onClick={() => onViewChange('DYNAMICS')} />
                    <NavItem icon={Globe} label="Gözlemcilik" active={currentView === 'SCOUTING'} onClick={() => onViewChange('SCOUTING')} />
                    <NavItem icon={BookOpen} label="Gelişim" active={currentView === 'DEVELOPMENT'} onClick={() => onViewChange('DEVELOPMENT')} />
                    <NavItem icon={UserPlus} label="İşe Alım" active={currentView === 'RECRUITMENT'} onClick={() => onViewChange('RECRUITMENT')} />
                    <NavItem icon={PieChart} label="Veri Merkezi" active={currentView === 'DATA_HUB'} onClick={() => onViewChange('DATA_HUB')} />
                    <NavItem icon={DollarSign} label="Finans" active={currentView === 'FINANCES'} onClick={() => onViewChange('FINANCES')} />
                    <NavItem icon={Crosshair} label="Strateji" active={currentView === 'STRATEGY'} onClick={() => onViewChange('STRATEGY')} />
                    <NavItem icon={Target} label="Rakip Analizi" active={currentView === 'RIVALS'} onClick={() => onViewChange('RIVALS')} />
                    <NavItem icon={ArrowRight} label="Fırsatlar" active={currentView === 'OPPORTUNITIES'} onClick={() => onViewChange('OPPORTUNITIES')} />
                </div>

                <div>
                    <p style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--color-text-secondary)', marginBottom: '0.5rem', paddingLeft: '1rem' }}>STRATEJİ</p>
                    <NavItem icon={Megaphone} label="Reklam Yöneticisi" active={currentView === 'ADS'} onClick={() => onViewChange('ADS')} />
                    <NavItem icon={Search} label="SEO Merkezi" active={currentView === 'SEO'} onClick={() => onViewChange('SEO')} />
                    <NavItem icon={Share2} label="Sosyal Stüdyo" active={currentView === 'SOCIAL'} onClick={() => onViewChange('SOCIAL')} />
                </div>
            </div>

            <div style={{ borderTop: '1px solid rgba(0,0,0,0.05)', paddingTop: '1rem' }}>
                <NavItem icon={Settings} label="Ayarlar" active={currentView === 'SETTINGS'} onClick={() => onViewChange('SETTINGS')} />
            </div>
        </div>
    )
}
