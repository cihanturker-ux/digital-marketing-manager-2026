
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { calculateDailyResults } from '../utils/simulationEngine'

const DEFAULT_STATE = {
    gamePhase: 'ONBOARDING',
    manager: {
        name: '',
        avatar: null,
        attributes: { strategy: 10, creativity: 10, technical: 10, leadership: 10 },
        reputation: 0,
    },
    company: { name: 'Demo Corp', industry: 'Demo', budget: 50000 },
    campaigns: [],
    posts: [],
    history: [],
    date: new Date(2025, 0, 1),
    level: 1,
    xp: 0,
    xpThreshold: 1000,
    difficulty: 1,
    monthlyGoal: null,
    contractOffers: [],
    keywords: [],
    siteHealth: { technical: 50, content: 50, backlinks: 10 },
    followers: { instagram: 100, linkedin: 50, twitter: 20 },
    gameOver: false,
    victory: false,
    boardTrust: 70, // Board confidence (0-100)
    tasks: [], // Active tasks from board
    pendingNotifications: [], // New tasks to show in modal

    // ============ SEASON SYSTEM ============
    currentSeason: 1,
    seasonStartTime: Date.now(),
    totalPlayTime: 0,
    seasonPlayTime: 0,
    seasonDuration: 30 * 60 * 60 * 1000,
    seasonStats: {
        tasksCompleted: 0,
        tasksFailed: 0,
        campaignsLaunched: 0,
        totalRevenue: 0,
        peakBoardTrust: 70,
        lowestBoardTrust: 70,
    },
    seasonHistory: [],
    showSeasonEnd: false,

    // ============ NEW: MARKETING ENGINE ============
    activeEvents: [],
    lastMatchResults: null,
    isPlaying: false,
    gameSpeed: 1, // 1x, 2x, 3x
    currentTrends: ['Yapay Zeka', 'Sürdürülebilirlik', 'Kripto', 'Uzaktan Çalışma', 'Wellness'],
    marketEvents: [
        {
            name: 'Google Çekirdek Güncellemesi',
            description: 'Google sıralama algoritmasını güncelledi. Organik görünürlük dalgalı.',
            effects: { seo: 0.5, traffic: 0.8 },
            probability: 0.05
        },
        {
            name: 'iOS Gizlilik Krizi',
            description: 'Meta Reklamlarında takip doğruluğu önemli ölçüde düştü.',
            effects: { conversion: 0.6, traffic: 0.9 },
            probability: 0.03
        },
        {
            name: 'Viral Akım',
            description: 'Sektörünüzle ilgili bir trend viral oluyor!',
            effects: { social: 2.0, traffic: 1.5 },
            probability: 0.04
        },
        {
            name: 'Efsane Cuma / Siber Pazartesi',
            description: 'E-ticaret aktivitesi zirve yapıyor!',
            effects: { conversion: 2.0, traffic: 3.0 },
            probability: 0.02
        }
    ],
    // ============ NEW: INBOX & STAFF SYSTEM ============
    inbox: [
        { id: 1, sender: "Yönetim Kurulu", subject: "Yeni Sezon Hedefleri", body: "Bu sezon agresif büyüme bekliyoruz. Bütçeyi verimli kullanın.", date: new Date(2025, 0, 1).toISOString(), read: false, type: "URGENT" },
        { id: 2, sender: "İK Departmanı", subject: "Ekip Durumu", body: "Personel morali stabil görünüyor. Düzenli toplantıları unutmayın.", date: new Date(2025, 0, 1).toISOString(), read: false, type: "NORMAL" }
    ],
    staff: [
        { id: 's1', name: "Selin Çelik", role: "Kıdemli İçerik Stratejisti", avatar: "👩‍💼", happiness: 75, energy: 80, salary: 4500, skills: { strategy: 8, creativity: 9 } },
        { id: 's2', name: "Mert Yılmaz", role: "SEO Uzmanı", avatar: "👨‍💻", happiness: 65, energy: 70, salary: 4000, skills: { technical: 9, strategy: 6 } },
        { id: 's3', name: "Elif Demir", role: "Sosyal Medya Yöneticisi", avatar: "👩‍🎨", happiness: 80, energy: 90, salary: 3800, skills: { creativity: 9, communication: 8 } },
        { id: 's4', name: "Can Park", role: "Veri Analisti", avatar: "👨‍🔬", happiness: 70, energy: 75, salary: 4200, skills: { technical: 8, strategy: 7 } },
    ],
    dynamics: {
        cohesion: 75, // Team chemistry (0-100)
        atmosphere: 80, // Office vibe
        leadershipSupport: 60 // Trust in manager
    },
};

export const useGameStore = create(persist((set, get) => ({
    ...DEFAULT_STATE,

    // ------------------- Actions -------------------
    setManagerName: (name) => set((state) => ({ manager: { ...state.manager, name } })),
    setGamePhase: (phase) => set({ gamePhase: phase }),
    setCompany: (companyData) => set({ company: companyData }),
    addCampaign: (campaign) => set((state) => {
        // Assign creative quality (1-10) and targeting accuracy (0.1-1.0)
        const creativeQuality = Math.floor(Math.random() * 6) + 4; // Starts 4-10
        // Update targeting check for Turkish strings
        const targetingAccuracy = campaign.targeting.includes('Geniş') ? 0.6 :
            campaign.targeting.includes('İlgi') ? 0.8 : 0.95;

        const newCampaigns = [...state.campaigns, {
            ...campaign,
            id: Math.random().toString(36).substr(2, 9),
            status: 'ACTIVE',
            creativeQuality,
            targetingAccuracy,
            competitorPressure: 1.0, // Initial AI pressure
            results: { impressions: 0, clicks: 0, conversions: 0 }
        }];

        // Auto-complete CAMPAIGN tasks
        const campaignTask = state.tasks.find(t => t.type === 'CAMPAIGN' && t.status === 'ACTIVE');
        if (campaignTask) {
            setTimeout(() => get().completeTask(campaignTask.id), 100);
        }

        return {
            campaigns: newCampaigns,
            seasonStats: {
                ...state.seasonStats,
                campaignsLaunched: state.seasonStats.campaignsLaunched + 1
            }
        };
    }),
    addPost: (post) => set((state) => {
        const newPosts = [{ ...post, id: Math.random().toString(36).substr(2, 9), likes: 0, comments: 0, date: state.date }, ...state.posts];

        // Auto-complete SOCIAL tasks if criteria met
        const socialTask = state.tasks.find(t => t.type === 'SOCIAL' && t.status === 'ACTIVE');
        if (socialTask) {
            const postsSinceTaskCreated = newPosts.filter(p => new Date(p.date) >= new Date(socialTask.createdAt)).length;
            if (postsSinceTaskCreated >= 3) {
                setTimeout(() => get().completeTask(socialTask.id), 100);
            }
        }

        return { posts: newPosts };
    }),
    addKeyword: (keyword) => set((state) => {
        const newKeywords = [...state.keywords, { ...keyword, id: Math.random().toString(36).substr(2, 9), rank: 100, history: [] }];

        // Auto-complete KEYWORD tasks if criteria met
        const keywordTask = state.tasks.find(t => t.type === 'KEYWORD' && t.status === 'ACTIVE');
        if (keywordTask) {
            const keywordsSinceTaskCreated = newKeywords.filter(k => {
                const taskCreated = new Date(keywordTask.createdAt);
                return !keywordTask.initialCount || newKeywords.indexOf(k) >= (state.keywords.length);
            }).length;
            if (keywordsSinceTaskCreated >= 5) {
                setTimeout(() => get().completeTask(keywordTask.id), 100);
            }
        }

        return { keywords: newKeywords };
    }),
    fixSiteIssue: (type) => set((state) => {
        const costs = { technical: 50, content: 30, backlink: 100 };
        const cost = costs[type] || 50;

        if (state.company.budget < cost) return {};

        // Calculate improvement (diminishing returns could be added but keep simple +5 for now)
        // Note: UI used "backlink" singular in card type but "backlinks" in state.
        // Let's normalize type input.
        const stateKey = type === 'backlink' ? 'backlinks' : type;

        const newHealth = { ...state.siteHealth, [stateKey]: Math.min(100, state.siteHealth[stateKey] + 5) };

        // Auto-complete SEO tasks if technical health reaches 70
        if (stateKey === 'technical' && newHealth.technical >= 70) {
            const seoTask = state.tasks.find(t => t.type === 'SEO' && t.status === 'ACTIVE');
            if (seoTask) {
                setTimeout(() => get().completeTask(seoTask.id), 100);
            }
        }

        return {
            siteHealth: newHealth,
            company: { ...state.company, budget: state.company.budget - cost }
        };
    }),
    clearContractOffers: () => set({ contractOffers: [] }),
    completeTask: (taskId) => set((state) => {
        const task = state.tasks.find(t => t.id === taskId);
        if (!task || task.status !== 'ACTIVE') return {};
        const newTrust = Math.min(100, state.boardTrust + task.trustReward);
        return {
            tasks: state.tasks.map(t => t.id === taskId ? { ...t, status: 'COMPLETED' } : t),
            boardTrust: newTrust,
            xp: state.xp + task.xpReward,
            seasonStats: {
                ...state.seasonStats,
                tasksCompleted: state.seasonStats.tasksCompleted + 1,
                peakBoardTrust: Math.max(state.seasonStats.peakBoardTrust, newTrust)
            }
        };
    }),
    failTask: (taskId) => set((state) => {
        const task = state.tasks.find(t => t.id === taskId);
        if (!task || task.status !== 'ACTIVE') return {};
        const newTrust = Math.max(0, state.boardTrust - task.trustPenalty);
        return {
            tasks: state.tasks.map(t => t.id === taskId ? { ...t, status: 'FAILED' } : t),
            boardTrust: newTrust,
            seasonStats: {
                ...state.seasonStats,
                tasksFailed: state.seasonStats.tasksFailed + 1,
                lowestBoardTrust: Math.min(state.seasonStats.lowestBoardTrust, newTrust)
            }
        };
    }),
    addTask: (task) => set((state) => ({
        tasks: [...state.tasks, { ...task, id: Math.random().toString(36).substr(2, 9), status: 'ACTIVE', createdAt: state.date }],
        pendingNotifications: [...state.pendingNotifications, { ...task, id: Math.random().toString(36).substr(2, 9) }]
    })),
    clearPendingNotifications: () => set({ pendingNotifications: [] }),

    // ============ INBOX ACTIONS ============
    markMessageRead: (id) => set((state) => ({
        inbox: state.inbox.map(msg => msg.id === id ? { ...msg, read: true } : msg)
    })),
    deleteMessage: (id) => set((state) => ({
        inbox: state.inbox.filter(msg => msg.id !== id)
    })),
    addInboxMessage: (msg) => set((state) => ({
        inbox: [{
            ...msg,
            id: Math.random().toString(36).substr(2, 9),
            date: state.date.toISOString(),
            read: false
        }, ...state.inbox]
    })),

    // ============ STAFF ACTIONS ============
    trainStaff: (staffId) => set((state) => {
        const cost = 2000;
        if (state.company.budget < cost) return {};
        return {
            company: { ...state.company, budget: state.company.budget - cost },
            staff: state.staff.map(s => s.id === staffId ? {
                ...s,
                happiness: Math.min(100, s.happiness + 10),
                skills: { ...s.skills, strategy: (s.skills.strategy || 0) + 1 }
            } : s)
        };
    }),
    boostMorale: (amount) => set((state) => {
        const cost = amount * 100; // $100 per point
        if (state.company.budget < cost) return {};
        return {
            company: { ...state.company, budget: state.company.budget - cost },
            staff: state.staff.map(s => ({ ...s, happiness: Math.min(100, s.happiness + 5) })),
            dynamics: { ...state.dynamics, atmosphere: Math.min(100, state.dynamics.atmosphere + 5) }
        };
    }),
    // ============ GAME CONTROLS ============
    setIsPlaying: (isPlaying) => set({ isPlaying }),
    setGameSpeed: (speed) => set({ gameSpeed: speed }),

    // ============ SEASON MANAGEMENT ============
    updatePlayTime: (deltaTime) => set((state) => {
        const newSeasonPlayTime = state.seasonPlayTime + deltaTime;
        const newTotalPlayTime = state.totalPlayTime + deltaTime;

        // Check if season is complete
        if (newSeasonPlayTime >= state.seasonDuration) {
            return {
                seasonPlayTime: newSeasonPlayTime,
                totalPlayTime: newTotalPlayTime,
                showSeasonEnd: true
            };
        }

        return {
            seasonPlayTime: newSeasonPlayTime,
            totalPlayTime: newTotalPlayTime
        };
    }),

    completeSeasonAndStartNew: () => set((state) => {
        // Save current season to history
        const seasonSummary = {
            season: state.currentSeason,
            stats: { ...state.seasonStats },
            finalBoardTrust: state.boardTrust,
            finalBudget: state.company.budget,
            playTime: state.seasonPlayTime,
            endDate: new Date().toISOString()
        };

        return {
            currentSeason: state.currentSeason + 1,
            seasonStartTime: Date.now(),
            seasonPlayTime: 0,
            seasonHistory: [...state.seasonHistory, seasonSummary],
            seasonStats: {
                tasksCompleted: 0,
                tasksFailed: 0,
                campaignsLaunched: 0,
                totalRevenue: 0,
                peakBoardTrust: state.boardTrust,
                lowestBoardTrust: state.boardTrust,
            },
            showSeasonEnd: false,
            // Reset some stats for new season
            tasks: [],
            pendingNotifications: [],
            // Give season completion bonuses
            company: { ...state.company, budget: state.company.budget + 50000 },
            xp: state.xp + 2000
        };
    }),

    closeSeasonEndModal: () => set({ showSeasonEnd: false }),

    resetGame: () => set({ ...DEFAULT_STATE }),
    addXP: (amount) => set((state) => {
        const newXP = state.xp + amount;
        const newState = { xp: newXP };
        if (newXP >= state.xpThreshold) {
            newState.level = state.level + 1;
            newState.xp = newXP - state.xpThreshold;
            newState.xpThreshold = Math.round(state.xpThreshold * 1.2);
            newState.difficulty = state.difficulty + 1;
            newState.contractOffers = [...state.contractOffers, ...generateContractOffers(state.level + 1)];
        }
        return newState;
    }),
    generateMonthlyGoal: () => set((state) => {
        const base = 50000;
        const target = base * state.difficulty * (1 + Math.random() * 0.5);
        return { monthlyGoal: Math.round(target) };
    }),
    setGameOver: (val) => set({ gameOver: val }),
    setVictory: (val) => set({ victory: val }),
    advanceTime: (days) => set((state) => {
        const currentDate = state.date instanceof Date ? state.date : new Date(state.date);
        const newDate = new Date(currentDate);
        newDate.setDate(newDate.getDate() + days);

        // 1. Process MARKET EVENTS (The Algorithm Update)
        let activeEvents = [...(state.activeEvents || [])];
        // Expire old events (3 days max)
        activeEvents = activeEvents.filter(e => {
            const age = (newDate - new Date(e.startDate)) / (1000 * 60 * 60 * 24);
            return age < 3;
        });

        // Chance to trigger new event
        state.marketEvents.forEach(eventDef => {
            if (activeEvents.find(ae => ae.name === eventDef.name)) return;
            if (Math.random() < eventDef.probability * days) {
                activeEvents.push({
                    ...eventDef,
                    id: Math.random().toString(36).substr(2, 9),
                    startDate: newDate.toISOString()
                });
            }
        });

        // 2. Process AI COMPETITORS (The Real-Time Auction)
        const updatedCampaigns = (state.campaigns || []).map(c => {
            // Randomly fluctuate competitor pressure
            const pressureChange = (Math.random() * 0.2 - 0.1); // +/- 10%
            const newPressure = Math.max(0.5, Math.min(2.0, (c.competitorPressure || 1.0) + pressureChange));
            return { ...c, competitorPressure: newPressure };
        });

        // 3. Calculate Results
        const results = calculateDailyResults({ ...state, campaigns: updatedCampaigns, activeEvents });
        const newHistory = [...(state.history || []), { date: newDate.toISOString(), ...results }];

        // Update campaign results in state
        const fullyUpdatedCampaigns = updatedCampaigns.map(c => {
            const dayResult = results.campaignResults.find(cr => cr.id === c.id);
            if (dayResult) {
                return {
                    ...c,
                    results: {
                        impressions: c.results.impressions + dayResult.impressions,
                        clicks: c.results.clicks + dayResult.clicks,
                        conversions: c.results.conversions + dayResult.conversions
                    }
                };
            }
            return c;
        });

        const updatedPosts = (state.posts || []).map(p => {
            const ageInDays = (newDate - new Date(p.date)) / (1000 * 60 * 60 * 24);
            if (ageInDays < 3) {
                const multiplier = results.sources.social / 1000 + 1;
                return {
                    ...p,
                    likes: p.likes + Math.floor(Math.random() * 50 * multiplier),
                    comments: p.comments + Math.floor(Math.random() * 5 * multiplier)
                };
            }
            return p;
        });

        // Simulate SEO Ranking Updates
        const updatedKeywords = (state.keywords || []).map(k => {
            const change = Math.floor(Math.random() * 5) - 2;
            let newRank = k.rank - change;
            if (newRank < 1) newRank = 1;
            if (newRank > 100) newRank = 100;
            return { ...k, rank: newRank };
        });

        // Simulate Follower Growth
        const newFollowers = { ...state.followers };
        updatedPosts.forEach(p => {
            if ((newDate - new Date(p.date)) / (1000 * 60 * 60 * 24) < 1) {
                const platform = p.platform.toLowerCase();
                if (newFollowers[platform]) {
                    newFollowers[platform] += Math.floor(Math.random() * 10) + 1;
                }
            }
        });

        const xpGain = Math.round(results.revenue / 100);
        const monthChanged = newDate.getMonth() !== currentDate.getMonth();

        // Tasks logic
        const updatedTasks = (state.tasks || []).map(task => {
            if (task.status !== 'ACTIVE') return task;
            const deadline = new Date(task.deadline);
            if (newDate > deadline) {
                setTimeout(() => get().failTask(task.id), 0);
                return { ...task, status: 'FAILED' };
            }
            return task;
        });

        const revenueTask = updatedTasks.find(t => t.type === 'REVENUE' && t.status === 'ACTIVE');
        if (revenueTask) {
            const taskCreatedDate = new Date(revenueTask.createdAt);
            const relevantHistory = newHistory.filter(h => new Date(h.date) >= taskCreatedDate);
            const totalRevenue = relevantHistory.reduce((sum, h) => sum + (h.revenue || 0), 0);
            const targetRevenue = 5000 * (state.difficulty || 1);
            if (totalRevenue >= targetRevenue) {
                setTimeout(() => get().completeTask(revenueTask.id), 100);
            }
        }

        const newTasks = [];
        const pendingNotifs = [];
        if (Math.random() < 0.3 * days) {
            const generatedTask = generateRandomTask(newDate, state.difficulty);
            newTasks.push(generatedTask);
            pendingNotifs.push(generatedTask);
        }

        // 4. Generate Random Emails
        const newInbox = [...state.inbox];
        if (Math.random() < 0.4 * days) {
            const senders = ["Google Ads Team", "Meta Business", "Müşteri Hizmetleri", "Finans Ekibi", "Selin Çelik"];
            const subjects = ["Hesap Uyarısı", "Yeni Özellikler", "Müşteri Şikayeti", "Fatura Hatırlatması", "Proje Güncellemesi"];
            const selectedSender = senders[Math.floor(Math.random() * senders.length)];
            newInbox.unshift({
                id: Math.random().toString(36).substr(2, 9),
                sender: selectedSender,
                subject: subjects[Math.floor(Math.random() * subjects.length)],
                body: "Sayın Yönetici, bu otomatik bir bilgilendirme mesajıdır. Lütfen panele giderek detayları inceleyiniz.",
                date: newDate.toISOString(),
                read: false,
                type: Math.random() > 0.8 ? "URGENT" : "NORMAL"
            });
        }

        // 5. Update Staff & Dynamics
        const newStaff = (state.staff || []).map(s => {
            // Daily decay
            let newHappiness = s.happiness - (Math.random() * 2);
            // Boost if doing well
            if (results.revenue > 1000) newHappiness += 1;
            return {
                ...s,
                happiness: Math.max(0, Math.min(100, newHappiness)),
                energy: Math.min(100, s.energy + 5) // Recover energy overnight
            };
        });
        const avgHappiness = newStaff.reduce((acc, s) => acc + s.happiness, 0) / (newStaff.length || 1);
        const newDynamics = {
            ...state.dynamics,
            cohesion: Math.max(0, Math.min(100, state.dynamics.cohesion + (avgHappiness > 70 ? 0.5 : -0.5))),
            atmosphere: Math.max(0, Math.min(100, avgHappiness))
        };

        const currentCompany = state.company || { budget: 0 };
        const newBudget = (currentCompany.budget || 0) - (days * 100) + results.revenue;

        const newState = {
            date: newDate,
            activeEvents,
            lastMatchResults: results,
            campaigns: fullyUpdatedCampaigns,
            posts: updatedPosts,
            keywords: updatedKeywords,
            followers: newFollowers,
            history: newHistory,
            company: { ...currentCompany, budget: newBudget },
            tasks: [...updatedTasks, ...newTasks],
            tasks: [...updatedTasks, ...newTasks],
            pendingNotifications: [...(state.pendingNotifications || []), ...pendingNotifs],
            inbox: newInbox,
            staff: newStaff,
            dynamics: newDynamics,
            seasonStats: {
                ...state.seasonStats,
                totalRevenue: state.seasonStats.totalRevenue + results.revenue
            }
        };

        if (monthChanged) {
            newState.difficulty = (state.difficulty || 1) + 1;
            const base = 50000;
            const target = base * newState.difficulty * (1 + Math.random() * 0.5);
            newState.monthlyGoal = Math.round(target);
        }

        const totalXP = (state.xp || 0) + xpGain;
        const currentThreshold = state.xpThreshold || 1000;
        if (totalXP >= currentThreshold) {
            newState.level = (state.level || 1) + 1;
            newState.xp = totalXP - currentThreshold;
            newState.xpThreshold = Math.round(currentThreshold * 1.2);
            newState.contractOffers = [...(state.contractOffers || []), ...generateContractOffers(newState.level)];
        } else {
            newState.xp = totalXP;
        }

        if (newState.company.budget <= 0) newState.gameOver = true;
        if (newState.level >= 10) newState.victory = true;

        return { ...state, ...newState };
    })
}), { name: 'dmm-save-v1' }));

// Helper – generate dummy contract offers based on player level
function generateContractOffers(level) {
    const companies = [
        { name: 'TechFlow Çözümleri', industry: 'SaaS', budget: 80000 },
        { name: 'Piksel Nabız Stüdyo', industry: 'Yaratıcı', budget: 60000 },
        { name: 'VeriDemir Analitik', industry: 'Veri', budget: 90000 },
        { name: 'YeşilDalga Pazarlama', industry: 'Eko', budget: 70000 }
    ];
    const count = Math.min(level, companies.length);
    return companies.slice(0, count).map(c => ({ ...c, levelRequired: level, salary: 4000 + level * 500 }));
}

// Helper – generate random task based on current game state
function generateRandomTask(currentDate, difficulty = 1) {
    const taskTypes = [
        {
            type: 'CAMPAIGN',
            title: 'Yeni Kampanya Başlat',
            description: 'Yönetim kurulu yeni bir reklam kampanyası başlatmanızı istiyor.',
            requirement: 'En az 1 yeni kampanya oluştur ve başlat',
            checkCompletion: (campaigns, initialCount) => campaigns.length > initialCount,
            daysToComplete: 7,
            trustReward: 8,
            trustPenalty: 12,
            xpReward: 150
        },
        {
            type: 'REVENUE',
            title: 'Gelir Hedefi',
            description: `$${(5000 * difficulty).toLocaleString()} gelir hedefine ulaşın.`,
            requirement: `$${(5000 * difficulty).toLocaleString()} gelir elde et`,
            checkCompletion: (state) => {
                const recentRevenue = state.history.slice(-7).reduce((sum, h) => sum + (h.revenue || 0), 0);
                return recentRevenue >= 5000 * difficulty;
            },
            daysToComplete: 7,
            trustReward: 10,
            trustPenalty: 15,
            xpReward: 200
        },
        {
            type: 'SEO',
            title: 'SEO Sağlığını İyileştir',
            description: 'Web sitesinin teknik performansını optimize edin.',
            requirement: 'Teknik SEO puanını 70 üzerine çıkarın',
            checkCompletion: (state) => state.siteHealth.technical >= 70,
            daysToComplete: 5,
            trustReward: 6,
            trustPenalty: 8,
            xpReward: 100
        },
        {
            type: 'SOCIAL',
            title: 'Sosyal Medya Aktivitesi',
            description: 'Sosyal medya varlığımızı artırın.',
            requirement: 'En az 3 yeni sosyal medya gönderisi paylaşın',
            checkCompletion: (posts, initialCount) => posts.length >= initialCount + 3,
            daysToComplete: 5,
            trustReward: 5,
            trustPenalty: 7,
            xpReward: 80
        },
        {
            type: 'KEYWORD',
            title: 'Anahtar Kelime Araştırması',
            description: 'SEO anahtar kelime portföyümüzü genişletin.',
            requirement: 'En az 5 yeni anahtar kelime takip edin',
            checkCompletion: (keywords, initialCount) => keywords.length >= initialCount + 5,
            daysToComplete: 3,
            trustReward: 4,
            trustPenalty: 6,
            xpReward: 60
        }
    ];

    const selectedTask = taskTypes[Math.floor(Math.random() * taskTypes.length)];
    const deadline = new Date(currentDate);
    deadline.setDate(deadline.getDate() + selectedTask.daysToComplete);

    return {
        id: Math.random().toString(36).substr(2, 9),
        ...selectedTask,
        deadline: deadline.toISOString(),
        status: 'ACTIVE',
        createdAt: currentDate.toISOString()
    };
}

