# ✅ KONTROL LİSTESİ - FM25 GÜNCELLEMELER

## 📋 ÖNCELİKLİ TEST ADIMLARİ

### 1. Geliştirme Ortamı Kurulumu
- [ ] Node.js yüklü mü kontrol et: `node --version`
- [ ] npm yüklü mü kontrol et: `npm --version`
- [ ] Dependencies yüklü mü: `npm install`
- [ ] Dev server başlat: `npm run dev`

### 2. Temel Fonksiyonlar Testi
- [ ] Uygulama açılıyor mu?
- [ ] Manager creation çalışıyor mu?
- [ ] Contract offer kabul ediliyor mu?
- [ ] Dashboard yükleniyor mu?
- [ ] Sidebar menüsü görünüyor mu?

### 3. Mevcut Özellikler (Bozulmamış Olmalı)
- [ ] **Dashboard**: Metrikler görünüyor mu?
- [ ] **Ads Manager**: Campaign oluşturulabiliyor mu?
- [ ] **SEO Center**: Keyword eklenebiliyor mu?
- [ ] **Social Studio**: Post paylaşılabiliyor mu?
- [ ] **Task Manager**: Tasklar görünüyor mu?
- [ ] **Task Complete**: Task tamamlanabiliyor mu?
- [ ] **Finances**: Budget gösterimi doğru mu?
- [ ] **Team**: Takım üyeleri görünüyor mu?

### 4. Yeni Özellikler Testi ⭐

#### Press Conference 📰
- [ ] Sidebar'dan "Press Conference" görünüyor mu?
- [ ] Tıklanabiliyor mu?
- [ ] Sorular yükleniyor mu?
- [ ] Cevap seçenekleri görünüyor mu?
- [ ] Cevap tıklanabiliyor mu?
- [ ] Feedback mesajı gösteriliyor mu?
- [ ] Board trust değişiyor mu?
- [ ] Progress bar ilerliyor mu?
- [ ] 3 soru sonunda özet ekranı geliyor mu?
- [ ] XP kazanılıyor mu?

#### Staff Morale 😊
- [ ] Sidebar'dan "Staff Morale" görünüyor mu?
- [ ] Morale metrikleri hesaplanıyor mu?
- [ ] Overall Morale gösterimi doğru mu?
- [ ] 4 takım üyesi görünüyor mu?
- [ ] Her üyenin happiness değeri var mı?
- [ ] Morale factors listeleniyor mu?
- [ ] Positive/Negative factors ayrılıyor mu?
- [ ] Action butonları görünüyor mu?
- [ ] Morale değerleri dinamik mi? (board trust değişince)

#### Rival Analysis 🎯
- [ ] Sidebar'dan "Rival Analysis" görünüyor mu?
- [ ] 4 rakip şirket listeleniyor mu?
- [ ] Market position gösteriliyor mu?
- [ ] Her rival için stats görünüyor mu?
- [ ] Threat level gösterimi var mı?
- [ ] Rival kartına tıklanabiliyor mu?
- [ ] Detaylı bilgi açılıyor mu?
- [ ] Strengths/Weaknesses gösteriliyor mu?
- [ ] Strategic recommendation var mı?
- [ ] Market share hesaplamaları doğru mu?

### 5. İyileştirilmiş Sistemler

#### Simulation Engine
- [ ] Revenue hesaplaması gerçekçi mi?
- [ ] Campaign'ler revenue'ye katkı yapıyor mu?
- [ ] SEO keywords revenue'ye etki ediyor mu?
- [ ] Social posts engagement'a dönüşüyor mu?
- [ ] Traffic hesaplaması çalışıyor mu?

#### Dashboard Metrikleri
- [ ] Impressions gerçek değer mi? (hardcoded değil)
- [ ] CTR hesaplanıyor mu?
- [ ] Revenue change gösteriliyor mu?
- [ ] Traffic trend doğru mu?
- [ ] Kampanya olmadan "0" gösteriyor mu?

### 6. State Management
- [ ] Zustand persist çalışıyor mu?
- [ ] Sayfa yenilenince data kaybolmuyor mu?
- [ ] Tasks state'i güncel mi?
- [ ] Board trust şu anda kaç? _____
- [ ] Season progression devam ediyor mu?
- [ ] Campaign results kaydediliyor mu?

### 7. UI/UX Kontrolü
- [ ] Tüm butonlar hover effect'i var mı?
- [ ] Modal'lar düzgün açılıyor mu?
- [ ] Modal'lar düzgün kapanıyor mu?
- [ ] Animasyonlar smooth mu?
- [ ] Loading state'leri var mı?
- [ ] Responsive tasarım çalışıyor mu?

### 8. Console Kontrol
- [ ] Console'da error var mı?
- [ ] Warning mesajları var mı?
- [ ] 404 hatası var mı?
- [ ] Deprecated uyarısı var mı?

---

## 🐛 BULUNAN SORUNLAR

### Yüksek Öncelik
- [ ] ...

### Orta Öncelik  
- [ ] ...

### Düşük Öncelik
- [ ] ...

---

## ✅ DOĞRULANAN ÖZELLİKLER

### Çalışıyor ✓
- ...

### Test Edilmedi
- ...

---

## 📝 NOTLAR

### Gözlemler
- 

### İyileştirme Fikirleri
- 

### Bug'lar
-

---

## 🎯 FİNAL CHECK

### Deployment Öncesi
- [ ] Tüm testler geçti
- [ ] Console temiz
- [ ] Build başarılı: `npm run build`
- [ ] Production test edildi: `npm run preview`
- [ ] Dokümantasyon güncel
- [ ] README.md kontrol edildi

### Onay
- [ ] Tüm yeni özellikler çalışıyor
- [ ] Mevcut özellikler korunmuş
- [ ] Performans kabul edilebilir
- [ ] UX sorunsuz

---

**Test Tarihi**: _____________
**Test Eden**: _____________
**Sonuç**: ⭐⭐⭐⭐⭐ / 5

---

## 📞 DESTEK

Sorun bulursanız:
1. Console log'ları kaydedin
2. Hatayı adım adım tekrarlayın
3. Screenshot alın
4. GELISTIRME_RAPORU.md dosyasına bakın
5. FM25_UPDATES.md dokümantasyonunu inceleyin

---

**Not**: Bu checklist'i yazdırıp test ederken kullanabilirsiniz!
